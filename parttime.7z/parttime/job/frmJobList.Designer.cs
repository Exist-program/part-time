﻿namespace parttime.job
{
    partial class frmJobList
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmJobList));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnUdp = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.txtRegYmd1 = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnCalender1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtRegYmd2 = new System.Windows.Forms.TextBox();
            this.btnCalender2 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.axfpSpread1 = new AxFPUSpreadADO.AxfpSpread();
            this.lbCnt = new System.Windows.Forms.Label();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.groupBox3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axfpSpread1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.LemonChiffon;
            this.groupBox3.Controls.Add(this.btnUdp);
            this.groupBox3.Controls.Add(this.btnSearch);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.txtRegYmd1);
            this.groupBox3.Controls.Add(this.btnClose);
            this.groupBox3.Controls.Add(this.btnCalender1);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.btnClear);
            this.groupBox3.Controls.Add(this.txtRegYmd2);
            this.groupBox3.Controls.Add(this.btnCalender2);
            this.groupBox3.Location = new System.Drawing.Point(12, 7);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1138, 58);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            // 
            // btnUdp
            // 
            this.btnUdp.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnUdp.Location = new System.Drawing.Point(396, 14);
            this.btnUdp.Name = "btnUdp";
            this.btnUdp.Size = new System.Drawing.Size(75, 23);
            this.btnUdp.TabIndex = 254;
            this.btnUdp.Text = "更新";
            this.btnUdp.UseVisualStyleBackColor = true;
            this.btnUdp.Click += new System.EventHandler(this.btnUdp_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSearch.Location = new System.Drawing.Point(308, 14);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 3;
            this.btnSearch.Text = "検索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label19.Location = new System.Drawing.Point(24, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(41, 12);
            this.label19.TabIndex = 251;
            this.label19.Text = "登録日";
            // 
            // txtRegYmd1
            // 
            this.txtRegYmd1.Location = new System.Drawing.Point(67, 16);
            this.txtRegYmd1.Name = "txtRegYmd1";
            this.txtRegYmd1.Size = new System.Drawing.Size(75, 19);
            this.txtRegYmd1.TabIndex = 247;
            // 
            // btnClose
            // 
            this.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnClose.Location = new System.Drawing.Point(849, 13);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnCalender1
            // 
            this.btnCalender1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnCalender1.Location = new System.Drawing.Point(143, 15);
            this.btnCalender1.Name = "btnCalender1";
            this.btnCalender1.Size = new System.Drawing.Size(23, 21);
            this.btnCalender1.TabIndex = 248;
            this.btnCalender1.Text = "C";
            this.btnCalender1.UseVisualStyleBackColor = true;
            this.btnCalender1.Click += new System.EventHandler(this.btnCalender1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(171, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 252;
            this.label4.Text = "～";
            // 
            // btnClear
            // 
            this.btnClear.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnClear.Location = new System.Drawing.Point(484, 14);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtRegYmd2
            // 
            this.txtRegYmd2.Location = new System.Drawing.Point(190, 16);
            this.txtRegYmd2.Name = "txtRegYmd2";
            this.txtRegYmd2.Size = new System.Drawing.Size(75, 19);
            this.txtRegYmd2.TabIndex = 249;
            // 
            // btnCalender2
            // 
            this.btnCalender2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnCalender2.Location = new System.Drawing.Point(266, 15);
            this.btnCalender2.Name = "btnCalender2";
            this.btnCalender2.Size = new System.Drawing.Size(23, 21);
            this.btnCalender2.TabIndex = 250;
            this.btnCalender2.Text = "C";
            this.btnCalender2.UseVisualStyleBackColor = true;
            this.btnCalender2.Click += new System.EventHandler(this.btnCalender2_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.axfpSpread1);
            this.panel1.Location = new System.Drawing.Point(12, 87);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1138, 602);
            this.panel1.TabIndex = 4;
            // 
            // axfpSpread1
            // 
            this.axfpSpread1.DataSource = null;
            this.axfpSpread1.Location = new System.Drawing.Point(4, 4);
            this.axfpSpread1.Name = "axfpSpread1";
            this.axfpSpread1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axfpSpread1.OcxState")));
            this.axfpSpread1.Size = new System.Drawing.Size(1131, 595);
            this.axfpSpread1.TabIndex = 0;
            this.axfpSpread1.DblClick += new AxFPUSpreadADO._DSpreadEvents_DblClickEventHandler(this.axfpSpread1_DblClick);
            this.axfpSpread1.ClickEvent += new AxFPUSpreadADO._DSpreadEvents_ClickEventHandler(this.axfpSpread1_ClickEvent);
            // 
            // lbCnt
            // 
            this.lbCnt.AutoSize = true;
            this.lbCnt.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbCnt.ForeColor = System.Drawing.Color.Red;
            this.lbCnt.Location = new System.Drawing.Point(81, 69);
            this.lbCnt.Name = "lbCnt";
            this.lbCnt.Size = new System.Drawing.Size(41, 12);
            this.lbCnt.TabIndex = 5;
            this.lbCnt.Text = "label1";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(92, 48);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 255;
            this.monthCalendar1.Visible = false;
            this.monthCalendar1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateSelected);
            // 
            // frmJobList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LemonChiffon;
            this.ClientSize = new System.Drawing.Size(1162, 701);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.lbCnt);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox3);
            this.Name = "frmJobList";
            this.Text = "求人リスト";
            this.Load += new System.EventHandler(this.frmJobList_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axfpSpread1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnUdp;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtRegYmd1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnCalender1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtRegYmd2;
        private System.Windows.Forms.Button btnCalender2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbCnt;
        private AxFPUSpreadADO.AxfpSpread axfpSpread1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
    }
}