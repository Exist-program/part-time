﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using parttime.common;
using System.Collections;
using System.Net;
using System.IO;
using System.Web;


namespace parttime.job
{

    public partial class frmJobDetail : Form
    {
        static string[][] PUBLISH = new string[][]{
            new string[]{"KR_NV", "韓国_NAVER"}    
            ,new string[]{"JP_FB", "日本_FaceBook"}
                
        };

        public frmJobDetail()
        {
            InitializeComponent();
        }

        private void frmJobDetail_Load(object sender, EventArgs e)
        {
            setPage();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            frmClose();
        }

        private void frmClose()
        {

            frmJobDetail_FormClosing(null, null);
            this.Close();
        }

        private void frmJobDetail_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmMain pForm = (frmMain)this.MdiParent;
            CodeMaster.FormArray.Remove(this);
        }

        private void setPage()
        {
            Common.setComboBox(4, comboTodo);
            Common.setComboBox(3, comboBox_PUBLISHLANGFROM);
            Common.setComboBox(3, comboBox_PUBLISHLANGTO);
            Common.setComboBox(10, comboJobType);
            Common.setComboBox(12, comboSalType);
            
            getJobInfo();
            getJobMail();
        }




        /// <summary>
        /// 一斉メール送信用の文面作成
        /// </summary>
        private void getJobMail() 
        {
            string titleFormat = @"【あなたへの新しいアルバイト情報！/{JOB_NO}】無料外国人・留学生のパート・アルバイト情報サイト";
            string bodyFormat = @"
こんにちは！
日本にいる外国人/留学生のためのアルバイト求人サイト
http://www.parttime-jp.info
あなたに新しいアルバイトの募集情報！

【{KIGYOU_NAME}】
から新しい仕事【{JOB_NO}】【{JOB_INTRO}】のアルバイト募集をしています。

※このメールは、あなたへの最新情報のお知らせメールです。
アルバイトの内容を確認できましたら、ぜひ応募してみてください！

_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

■ ＝アルバイトの詳しい情報＝

1. アルバイトの内容：{JOB_INTRO}

2. 募集しているのは：{KIGYOU_NAME}　です。

3. 最寄駅：{JOB_STATION}

4. 場所：{JOB_LOCATION}

5. お仕事の詳しい内容：{JOB_CONTENTS}

6. 時間：{JOB_TIME}

7. お給料：{JOB_SAL}/{JOB_SAL_TANI}

8. このアルバイト、こういうところがいいです。

{JOB_APPEALPOINT_A}
{JOB_APPEALPOINT_B}

【コメント・PR】
{JOB_APPEAL}

9. 応募の方法：

①.【無料】外国人留学生向けのパート・アルバイト情報サイト
http://www.parttime-jp.info
アクセス、ログインして下さい。
※IDは、あなたの登録したこのメールアドレスです。

②.ログインして、マイページでこのアルバイトの内容を確認してください。
情報はすべてそこにあります。

③.詳細ページの「応募」ボタンからエントリーして下さい。

④.エントリーのあと、アルバイト先から結果（面接 or 不合格）と
面接をいつするのかの連絡が、あなたのマイページに来ますので、
マイページを確認して待ってください。

/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

あなたの応募をお待ちしています。

※このメールは、システムからのメールです。このアドレスに返信しても、
クェスチョンに答えられませんし、応募になりません。
";
            string signFormat = @"
---------------------------------
新卒の皆さんへの
正社員の仕事に関しては、下記のサイトをご利用ください。
http://staff.hiwork.jp/
※求人掲載数合計1,300件、毎年新卒求人情報が満載です！

国際交流イベントの検索は、下記のサイトをご利用ください。
http://www.internationalevent.jp/
---------------------------------
";
            //title            textBox_MailTitle.Text = ChangeTextFormat(titleFormat);
            //body
            textBox_MailBody.Text = ChangeTextFormat(bodyFormat + signFormat);
            
        }

        private string ChangeTextFormat(string format)
        {
            CheckBox[] job_timeList = new CheckBox[] { checkAsagata, checkAsa, checkHiru, checkYugata, checkSinya, checkWeek1, checkWeek2, checkWeek3 };

            //kigyou info
            format = format.Replace("{KIGYOU_NAME}", textBox_kigyouName.Text);
            //job info
            format = format.Replace("{JOB_NO}", textBox_job_no.Text);
            format = format.Replace("{JOB_INTRO}", txtJobIntro.Text);
            format = format.Replace("{JOB_STATION}", txtStation.Text);
            format = format.Replace("{JOB_LOCATION}", comboTodo.Text + txtArea.Text);
            format = format.Replace("{JOB_CONTENTS}", txtJobContents.Text);
            format = format.Replace("{JOB_TIME}", getTextFromCheckBoxList(job_timeList));
            format = format.Replace("{JOB_SAL}", comboSalTani.Text);
            format = format.Replace("{JOB_SAL_TANI}", comboSalType.Text);
            format = format.Replace("{JOB_APPEALPOINT_A}", textBox_appealPoint_A.Text);
            format = format.Replace("{JOB_APPEALPOINT_B}", textBox_appealPoint_B.Text);
            format = format.Replace("{JOB_APPEAL}", txtAppeal.Text);

            return format;
        }

        private string getTextFromCheckBoxList(CheckBox[] cbl)
        {
            string ret = string.Empty;
            foreach (CheckBox cb in cbl)
            {
                if (cb.Checked)
                {
                    ret += string.Format("{0},", cb.Text);
                }
            }
            return ret;
        }

        /// <summary>
        /// 仕事情報を画面に表示
        /// </summary>
        private void getJobInfo() {

            ArrayList colList = new ArrayList();
            ArrayList valList = new ArrayList();

            colList.Add("@job_no");
            valList.Add(CodeMaster.JOBNO);

            DataSet ds = DbCon.selectInfo(colList, valList, Sql.SEL_09);

            if (ds.Tables[0].Rows.Count > 0)
            {
                //案件NO
                textBox_job_no.Text = ds.Tables[0].Rows[0]["job_no"].ToString();
                //企業NO
                textBox_kigyouNo.Text = ds.Tables[0].Rows[0]["company_no"].ToString();
                //企業名
                textBox_kigyouName.Text = ds.Tables[0].Rows[0]["company_name"].ToString();

                comboJobType.SelectedValue = ds.Tables[0].Rows[0]["job_kind"].ToString();

                txtJobIntro.Text = ds.Tables[0].Rows[0]["job_intro"].ToString();

                txtJobContents.Text = ds.Tables[0].Rows[0]["job_contents"].ToString();

                comboSalType.SelectedValue = ds.Tables[0].Rows[0]["job_sal_type"].ToString();

                getSalTani(ds.Tables[0].Rows[0]["job_sal_tani"].ToString());

                comboTodo.SelectedValue = ds.Tables[0].Rows[0]["job_todo"].ToString();

                txtArea.Text = ds.Tables[0].Rows[0]["job_area"].ToString();

                txtStation.Text = ds.Tables[0].Rows[0]["job_traffic_1"].ToString()+" "+
                                  ds.Tables[0].Rows[0]["job_traffic_2"].ToString();

                if (ds.Tables[0].Rows[0]["JOB_TRA_MONEY_UMU"].ToString().Trim().Equals(CodeMaster.ChkBoxAri))
                {

                    radioAri.Checked = true;
                    radioNashi.Checked = false;
                    txtTranMoney.Text = Common.getMoneyType(ds.Tables[0].Rows[0]["job_tra_money"].ToString());
                } else {

                    radioAri.Checked = false;
                    radioNashi.Checked = true;
                }

                txtCloseYmd.Text = Common.getDateType(ds.Tables[0].Rows[0]["job_closing_ymd"].ToString());

                string picture = ds.Tables[0].Rows[0]["job_pho"].ToString();

                if (picture != null && picture != string.Empty)
                {
                    WebClient wc = new WebClient();

                    string url = "http://www.parttime-jp.info/" + picture.Substring(picture.IndexOf("img"));

                    Stream stream = wc.OpenRead(url);

                    System.Drawing.Image image = System.Drawing.Image.FromStream(stream);

                    picBox.Image = image;
                }
                else
                {

                    picBox.Image = null;
                }

                txtAppeal.Text = ds.Tables[0].Rows[0]["job_appeal"].ToString();

                // -----------------------------------------------------

                checkAsagata.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time1"].ToString());
                checkAsa.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time2"].ToString());
                checkHiru.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time3"].ToString());
                checkYugata.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time4"].ToString());
                checkSinya.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time5"].ToString());
                checkWeek1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time6"].ToString());
                checkWeek2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time7"].ToString());
                checkWeek3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time8"].ToString());

                checkSheeft.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_condition1"].ToString());
                checkWeekDay.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_condition2"].ToString());
                checkWeekEnd.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_condition3"].ToString());
                checkTanki.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_condition4"].ToString());
                checkConsul.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_condition5"].ToString());
                checkAtHome.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_condition6"].ToString());

                //KIMKU_150129 追加
                //アピールポイントA
                textBox_appealPoint_A.Text = AppealPoint.getTextListFromCodeList(ds.Tables[0].Rows[0]["APPEALPOINT_A"].ToString()).Replace(",", "\r\n");
                textBox_appealPoint_B.Text = AppealPoint.getTextListFromCodeList(ds.Tables[0].Rows[0]["APPEALPOINT_B"].ToString()).Replace(",", "\r\n");
                //他の掲示板に掲載
                for (int i = 0; i < checkedListBox_publish.Items.Count && i < PUBLISH.Length; i++)
                {
                    bool check = ds.Tables[0].Rows[0]["PUBLISH"].ToString().Contains(PUBLISH[i][0]);
                    checkedListBox_publish.SetItemChecked(i, check);
                }

                //元言語
                comboBox_PUBLISHLANGFROM.SelectedValue = ds.Tables[0].Rows[0]["PUBLISHLANGFROM"].ToString();
                //翻訳言語
                comboBox_PUBLISHLANGTO.SelectedValue = ds.Tables[0].Rows[0]["PUBLISHLANGTO"].ToString();
                //翻訳必要
                checkBox_Need_Translate.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["NEED_TRANSLATE"].ToString());

            }

        }

        private void getSalTani(string tani)
        {
            ArrayList list = new ArrayList();
            
            // time
            if (comboSalType.SelectedValue.ToString() == SalType.codeSalType1)
            {
                for (int i = 0; i < SalTani.nameSalTaniTimeList.Length; i++)
                {
                    list.Add(new System.Web.UI.WebControls.ListItem( SalTani.nameSalTaniTimeList[i], SalTani.codeSalTaniTimeList[i] ));
                }
            }

            // date
            if (comboSalType.SelectedValue.ToString() == SalType.codeSalType2)
            {
                for (int i = 0; i < SalTani.nameSalTaniDateList.Length; i++)
                {

                    list.Add(new System.Web.UI.WebControls.ListItem(SalTani.nameSalTaniDateList[i], SalTani.codeSalTaniDateList[i]));
                }
            }

            // month
            if (comboSalType.SelectedValue.ToString() == SalType.codeSalType3)
            {
                for (int i = 0; i < SalTani.nameSalTaniMonthList.Length; i++)
                {

                    list.Add(new System.Web.UI.WebControls.ListItem(SalTani.nameSalTaniMonthList[i], SalTani.codeSalTaniMonthList[i]));
                }
            }

            comboSalTani.DataSource = list;
            comboSalTani.DisplayMember = "TEXT";
            comboSalTani.ValueMember = "VALUE";

            comboSalTani.SelectedValue = tani;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            getJobMail();
        }
    }
}