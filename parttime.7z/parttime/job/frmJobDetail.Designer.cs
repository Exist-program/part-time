﻿namespace parttime.job
{
    partial class frmJobDetail
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox_kigyouName = new System.Windows.Forms.TextBox();
            this.textBox_kigyouNo = new System.Windows.Forms.TextBox();
            this.textBox_job_no = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox_PUBLISHLANGTO = new System.Windows.Forms.ComboBox();
            this.comboBox_PUBLISHLANGFROM = new System.Windows.Forms.ComboBox();
            this.checkBox_Need_Translate = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkedListBox_publish = new System.Windows.Forms.CheckedListBox();
            this.textBox_appealPoint_B = new System.Windows.Forms.TextBox();
            this.textBox_appealPoint_A = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button_mailRefresh = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox_MailBody = new System.Windows.Forms.TextBox();
            this.textBox_MailTitle = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textBox_mailBcc = new System.Windows.Forms.TextBox();
            this.textBox_mailCc = new System.Windows.Forms.TextBox();
            this.textBox_fromTo = new System.Windows.Forms.TextBox();
            this.textBox_mailFrom = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.picBox = new System.Windows.Forms.PictureBox();
            this.comboSalType = new System.Windows.Forms.ComboBox();
            this.txtAppeal = new System.Windows.Forms.TextBox();
            this.radioNashi = new System.Windows.Forms.RadioButton();
            this.radioAri = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkWeekEnd = new System.Windows.Forms.CheckBox();
            this.checkSheeft = new System.Windows.Forms.CheckBox();
            this.checkTanki = new System.Windows.Forms.CheckBox();
            this.checkWeekDay = new System.Windows.Forms.CheckBox();
            this.checkConsul = new System.Windows.Forms.CheckBox();
            this.checkAtHome = new System.Windows.Forms.CheckBox();
            this.txtCloseYmd = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkWeek3 = new System.Windows.Forms.CheckBox();
            this.checkWeek2 = new System.Windows.Forms.CheckBox();
            this.checkAsa = new System.Windows.Forms.CheckBox();
            this.checkHiru = new System.Windows.Forms.CheckBox();
            this.checkYugata = new System.Windows.Forms.CheckBox();
            this.checkAsagata = new System.Windows.Forms.CheckBox();
            this.checkSinya = new System.Windows.Forms.CheckBox();
            this.checkWeek1 = new System.Windows.Forms.CheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtJobContents = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comboTodo = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.comboSalTani = new System.Windows.Forms.ComboBox();
            this.comboJobType = new System.Windows.Forms.ComboBox();
            this.txtArea = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTranMoney = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtStation = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtJobIntro = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Wheat;
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1138, 677);
            this.panel1.TabIndex = 1;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.LemonChiffon;
            this.groupBox4.Controls.Add(this.btnClose);
            this.groupBox4.Location = new System.Drawing.Point(4, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1131, 40);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnClose.Location = new System.Drawing.Point(852, 11);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LemonChiffon;
            this.panel2.Controls.Add(this.textBox_kigyouName);
            this.panel2.Controls.Add(this.textBox_kigyouNo);
            this.panel2.Controls.Add(this.textBox_job_no);
            this.panel2.Controls.Add(this.groupBox5);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.textBox_appealPoint_B);
            this.panel2.Controls.Add(this.textBox_appealPoint_A);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.picBox);
            this.panel2.Controls.Add(this.comboSalType);
            this.panel2.Controls.Add(this.txtAppeal);
            this.panel2.Controls.Add(this.radioNashi);
            this.panel2.Controls.Add(this.radioAri);
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.txtCloseYmd);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.txtJobContents);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.comboTodo);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.comboSalTani);
            this.panel2.Controls.Add(this.comboJobType);
            this.panel2.Controls.Add(this.txtArea);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.txtTranMoney);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.txtStation);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtJobIntro);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(4, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1131, 623);
            this.panel2.TabIndex = 0;
            // 
            // textBox_kigyouName
            // 
            this.textBox_kigyouName.Location = new System.Drawing.Point(322, 6);
            this.textBox_kigyouName.Name = "textBox_kigyouName";
            this.textBox_kigyouName.Size = new System.Drawing.Size(178, 19);
            this.textBox_kigyouName.TabIndex = 54;
            // 
            // textBox_kigyouNo
            // 
            this.textBox_kigyouNo.Location = new System.Drawing.Point(234, 6);
            this.textBox_kigyouNo.Name = "textBox_kigyouNo";
            this.textBox_kigyouNo.Size = new System.Drawing.Size(82, 19);
            this.textBox_kigyouNo.TabIndex = 54;
            // 
            // textBox_job_no
            // 
            this.textBox_job_no.Location = new System.Drawing.Point(90, 6);
            this.textBox_job_no.Name = "textBox_job_no";
            this.textBox_job_no.Size = new System.Drawing.Size(82, 19);
            this.textBox_job_no.TabIndex = 54;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.comboBox_PUBLISHLANGTO);
            this.groupBox5.Controls.Add(this.comboBox_PUBLISHLANGFROM);
            this.groupBox5.Controls.Add(this.checkBox_Need_Translate);
            this.groupBox5.Location = new System.Drawing.Point(547, 534);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(204, 86);
            this.groupBox5.TabIndex = 53;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "案件翻訳";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(111, 43);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 12);
            this.label25.TabIndex = 55;
            this.label25.Text = "翻訳言語";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 43);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 12);
            this.label24.TabIndex = 55;
            this.label24.Text = "元言語";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(94, 61);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(17, 12);
            this.label23.TabIndex = 54;
            this.label23.Text = "⇒";
            // 
            // comboBox_PUBLISHLANGTO
            // 
            this.comboBox_PUBLISHLANGTO.FormattingEnabled = true;
            this.comboBox_PUBLISHLANGTO.Location = new System.Drawing.Point(111, 58);
            this.comboBox_PUBLISHLANGTO.Name = "comboBox_PUBLISHLANGTO";
            this.comboBox_PUBLISHLANGTO.Size = new System.Drawing.Size(88, 20);
            this.comboBox_PUBLISHLANGTO.TabIndex = 54;
            // 
            // comboBox_PUBLISHLANGFROM
            // 
            this.comboBox_PUBLISHLANGFROM.FormattingEnabled = true;
            this.comboBox_PUBLISHLANGFROM.Location = new System.Drawing.Point(6, 58);
            this.comboBox_PUBLISHLANGFROM.Name = "comboBox_PUBLISHLANGFROM";
            this.comboBox_PUBLISHLANGFROM.Size = new System.Drawing.Size(88, 20);
            this.comboBox_PUBLISHLANGFROM.TabIndex = 1;
            // 
            // checkBox_Need_Translate
            // 
            this.checkBox_Need_Translate.AutoSize = true;
            this.checkBox_Need_Translate.Location = new System.Drawing.Point(7, 18);
            this.checkBox_Need_Translate.Name = "checkBox_Need_Translate";
            this.checkBox_Need_Translate.Size = new System.Drawing.Size(72, 16);
            this.checkBox_Need_Translate.TabIndex = 0;
            this.checkBox_Need_Translate.Text = "翻訳必要";
            this.checkBox_Need_Translate.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkedListBox_publish);
            this.groupBox1.Location = new System.Drawing.Point(425, 534);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(116, 86);
            this.groupBox1.TabIndex = 52;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "他の掲示板掲示";
            // 
            // checkedListBox_publish
            // 
            this.checkedListBox_publish.CheckOnClick = true;
            this.checkedListBox_publish.FormattingEnabled = true;
            this.checkedListBox_publish.Items.AddRange(new object[] {
            "韓国_NAVER",
            "日本_FaceBook"});
            this.checkedListBox_publish.Location = new System.Drawing.Point(3, 18);
            this.checkedListBox_publish.Name = "checkedListBox_publish";
            this.checkedListBox_publish.Size = new System.Drawing.Size(107, 60);
            this.checkedListBox_publish.TabIndex = 0;
            // 
            // textBox_appealPoint_B
            // 
            this.textBox_appealPoint_B.Location = new System.Drawing.Point(100, 563);
            this.textBox_appealPoint_B.Multiline = true;
            this.textBox_appealPoint_B.Name = "textBox_appealPoint_B";
            this.textBox_appealPoint_B.Size = new System.Drawing.Size(280, 49);
            this.textBox_appealPoint_B.TabIndex = 51;
            // 
            // textBox_appealPoint_A
            // 
            this.textBox_appealPoint_A.Location = new System.Drawing.Point(100, 508);
            this.textBox_appealPoint_A.Multiline = true;
            this.textBox_appealPoint_A.Name = "textBox_appealPoint_A";
            this.textBox_appealPoint_A.Size = new System.Drawing.Size(280, 49);
            this.textBox_appealPoint_A.TabIndex = 51;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(13, 511);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(79, 12);
            this.label22.TabIndex = 50;
            this.label22.Text = "アピールポイント";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(754, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(377, 623);
            this.panel3.TabIndex = 49;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button_mailRefresh);
            this.panel5.Controls.Add(this.label21);
            this.panel5.Controls.Add(this.textBox_MailBody);
            this.panel5.Controls.Add(this.textBox_MailTitle);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 101);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(10, 15, 5, 5);
            this.panel5.Size = new System.Drawing.Size(377, 522);
            this.panel5.TabIndex = 1;
            // 
            // button_mailRefresh
            // 
            this.button_mailRefresh.Location = new System.Drawing.Point(275, 48);
            this.button_mailRefresh.Name = "button_mailRefresh";
            this.button_mailRefresh.Size = new System.Drawing.Size(94, 23);
            this.button_mailRefresh.TabIndex = 10;
            this.button_mailRefresh.Text = "テキスト更新";
            this.button_mailRefresh.UseVisualStyleBackColor = true;
            this.button_mailRefresh.Click += new System.EventHandler(this.button1_Click);
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(10, 53);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(29, 12);
            this.label21.TabIndex = 9;
            this.label21.Text = "本文";
            // 
            // textBox_MailBody
            // 
            this.textBox_MailBody.Location = new System.Drawing.Point(12, 71);
            this.textBox_MailBody.Multiline = true;
            this.textBox_MailBody.Name = "textBox_MailBody";
            this.textBox_MailBody.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox_MailBody.Size = new System.Drawing.Size(357, 448);
            this.textBox_MailBody.TabIndex = 8;
            // 
            // textBox_MailTitle
            // 
            this.textBox_MailTitle.Location = new System.Drawing.Point(56, 12);
            this.textBox_MailTitle.Name = "textBox_MailTitle";
            this.textBox_MailTitle.Size = new System.Drawing.Size(316, 19);
            this.textBox_MailTitle.TabIndex = 7;
            this.textBox_MailTitle.Text = "【あなたへの新しいアルバイト情報！/求人番号】無料外国人・留学生のパート・アルバイト情報サイト";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 15);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 12);
            this.label11.TabIndex = 1;
            this.label11.Text = "タイトル";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.textBox_mailBcc);
            this.panel4.Controls.Add(this.textBox_mailCc);
            this.panel4.Controls.Add(this.textBox_fromTo);
            this.panel4.Controls.Add(this.textBox_mailFrom);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Enabled = false;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(377, 101);
            this.panel4.TabIndex = 0;
            // 
            // textBox_mailBcc
            // 
            this.textBox_mailBcc.Location = new System.Drawing.Point(47, 70);
            this.textBox_mailBcc.Name = "textBox_mailBcc";
            this.textBox_mailBcc.Size = new System.Drawing.Size(188, 19);
            this.textBox_mailBcc.TabIndex = 6;
            // 
            // textBox_mailCc
            // 
            this.textBox_mailCc.Location = new System.Drawing.Point(47, 50);
            this.textBox_mailCc.Name = "textBox_mailCc";
            this.textBox_mailCc.Size = new System.Drawing.Size(188, 19);
            this.textBox_mailCc.TabIndex = 6;
            // 
            // textBox_fromTo
            // 
            this.textBox_fromTo.Location = new System.Drawing.Point(47, 30);
            this.textBox_fromTo.Name = "textBox_fromTo";
            this.textBox_fromTo.Size = new System.Drawing.Size(188, 19);
            this.textBox_fromTo.TabIndex = 6;
            // 
            // textBox_mailFrom
            // 
            this.textBox_mailFrom.Location = new System.Drawing.Point(47, 10);
            this.textBox_mailFrom.Name = "textBox_mailFrom";
            this.textBox_mailFrom.Size = new System.Drawing.Size(188, 19);
            this.textBox_mailFrom.TabIndex = 6;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(16, 73);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(25, 12);
            this.label20.TabIndex = 5;
            this.label20.Text = "Bcc";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(22, 53);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(19, 12);
            this.label19.TabIndex = 4;
            this.label19.Text = "Cc";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(23, 33);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(18, 12);
            this.label16.TabIndex = 3;
            this.label16.Text = "To";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(10, 13);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(31, 12);
            this.label15.TabIndex = 2;
            this.label15.Text = "From";
            // 
            // picBox
            // 
            this.picBox.Location = new System.Drawing.Point(478, 204);
            this.picBox.Name = "picBox";
            this.picBox.Size = new System.Drawing.Size(188, 132);
            this.picBox.TabIndex = 48;
            this.picBox.TabStop = false;
            // 
            // comboSalType
            // 
            this.comboSalType.FormattingEnabled = true;
            this.comboSalType.Location = new System.Drawing.Point(90, 223);
            this.comboSalType.Name = "comboSalType";
            this.comboSalType.Size = new System.Drawing.Size(109, 20);
            this.comboSalType.TabIndex = 47;
            // 
            // txtAppeal
            // 
            this.txtAppeal.Location = new System.Drawing.Point(478, 47);
            this.txtAppeal.Multiline = true;
            this.txtAppeal.Name = "txtAppeal";
            this.txtAppeal.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAppeal.Size = new System.Drawing.Size(270, 119);
            this.txtAppeal.TabIndex = 45;
            // 
            // radioNashi
            // 
            this.radioNashi.AutoSize = true;
            this.radioNashi.Location = new System.Drawing.Point(347, 457);
            this.radioNashi.Name = "radioNashi";
            this.radioNashi.Size = new System.Drawing.Size(42, 16);
            this.radioNashi.TabIndex = 44;
            this.radioNashi.TabStop = true;
            this.radioNashi.Text = "なし";
            this.radioNashi.UseVisualStyleBackColor = true;
            // 
            // radioAri
            // 
            this.radioAri.AutoSize = true;
            this.radioAri.Location = new System.Drawing.Point(90, 457);
            this.radioAri.Name = "radioAri";
            this.radioAri.Size = new System.Drawing.Size(47, 16);
            this.radioAri.TabIndex = 43;
            this.radioAri.TabStop = true;
            this.radioAri.Text = "実費";
            this.radioAri.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.LemonChiffon;
            this.groupBox3.Controls.Add(this.checkWeekEnd);
            this.groupBox3.Controls.Add(this.checkSheeft);
            this.groupBox3.Controls.Add(this.checkTanki);
            this.groupBox3.Controls.Add(this.checkWeekDay);
            this.groupBox3.Controls.Add(this.checkConsul);
            this.groupBox3.Controls.Add(this.checkAtHome);
            this.groupBox3.Location = new System.Drawing.Point(90, 359);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(368, 67);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            // 
            // checkWeekEnd
            // 
            this.checkWeekEnd.AutoSize = true;
            this.checkWeekEnd.Location = new System.Drawing.Point(192, 18);
            this.checkWeekEnd.Name = "checkWeekEnd";
            this.checkWeekEnd.Size = new System.Drawing.Size(69, 16);
            this.checkWeekEnd.TabIndex = 47;
            this.checkWeekEnd.Text = "土日のみ";
            this.checkWeekEnd.UseVisualStyleBackColor = true;
            // 
            // checkSheeft
            // 
            this.checkSheeft.AutoSize = true;
            this.checkSheeft.Location = new System.Drawing.Point(23, 19);
            this.checkSheeft.Name = "checkSheeft";
            this.checkSheeft.Size = new System.Drawing.Size(86, 16);
            this.checkSheeft.TabIndex = 46;
            this.checkSheeft.Text = "シフト制勤務";
            this.checkSheeft.UseVisualStyleBackColor = true;
            // 
            // checkTanki
            // 
            this.checkTanki.AutoSize = true;
            this.checkTanki.Location = new System.Drawing.Point(267, 19);
            this.checkTanki.Name = "checkTanki";
            this.checkTanki.Size = new System.Drawing.Size(84, 16);
            this.checkTanki.TabIndex = 48;
            this.checkTanki.Text = "短期間勤務";
            this.checkTanki.UseVisualStyleBackColor = true;
            // 
            // checkWeekDay
            // 
            this.checkWeekDay.AutoSize = true;
            this.checkWeekDay.Location = new System.Drawing.Point(117, 18);
            this.checkWeekDay.Name = "checkWeekDay";
            this.checkWeekDay.Size = new System.Drawing.Size(69, 16);
            this.checkWeekDay.TabIndex = 52;
            this.checkWeekDay.Text = "平日のみ";
            this.checkWeekDay.UseVisualStyleBackColor = true;
            // 
            // checkConsul
            // 
            this.checkConsul.AutoSize = true;
            this.checkConsul.Location = new System.Drawing.Point(23, 45);
            this.checkConsul.Name = "checkConsul";
            this.checkConsul.Size = new System.Drawing.Size(138, 16);
            this.checkConsul.TabIndex = 41;
            this.checkConsul.Text = "時間・曜日応相談勤務";
            this.checkConsul.UseVisualStyleBackColor = true;
            // 
            // checkAtHome
            // 
            this.checkAtHome.AutoSize = true;
            this.checkAtHome.Location = new System.Drawing.Point(192, 45);
            this.checkAtHome.Name = "checkAtHome";
            this.checkAtHome.Size = new System.Drawing.Size(48, 16);
            this.checkAtHome.TabIndex = 62;
            this.checkAtHome.Text = "在宅";
            this.checkAtHome.UseVisualStyleBackColor = true;
            // 
            // txtCloseYmd
            // 
            this.txtCloseYmd.Location = new System.Drawing.Point(90, 480);
            this.txtCloseYmd.Name = "txtCloseYmd";
            this.txtCloseYmd.Size = new System.Drawing.Size(151, 19);
            this.txtCloseYmd.TabIndex = 42;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.LemonChiffon;
            this.groupBox2.Controls.Add(this.checkWeek3);
            this.groupBox2.Controls.Add(this.checkWeek2);
            this.groupBox2.Controls.Add(this.checkAsa);
            this.groupBox2.Controls.Add(this.checkHiru);
            this.groupBox2.Controls.Add(this.checkYugata);
            this.groupBox2.Controls.Add(this.checkAsagata);
            this.groupBox2.Controls.Add(this.checkSinya);
            this.groupBox2.Controls.Add(this.checkWeek1);
            this.groupBox2.Location = new System.Drawing.Point(90, 291);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(368, 64);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            // 
            // checkWeek3
            // 
            this.checkWeek3.AutoSize = true;
            this.checkWeek3.Location = new System.Drawing.Point(197, 38);
            this.checkWeek3.Name = "checkWeek3";
            this.checkWeek3.Size = new System.Drawing.Size(78, 16);
            this.checkWeek3.TabIndex = 67;
            this.checkWeek3.Text = "週5日以上";
            this.checkWeek3.UseVisualStyleBackColor = true;
            // 
            // checkWeek2
            // 
            this.checkWeek2.AutoSize = true;
            this.checkWeek2.Location = new System.Drawing.Point(114, 38);
            this.checkWeek2.Name = "checkWeek2";
            this.checkWeek2.Size = new System.Drawing.Size(72, 16);
            this.checkWeek2.TabIndex = 66;
            this.checkWeek2.Text = "週3～4日";
            this.checkWeek2.UseVisualStyleBackColor = true;
            // 
            // checkAsa
            // 
            this.checkAsa.AutoSize = true;
            this.checkAsa.Location = new System.Drawing.Point(82, 16);
            this.checkAsa.Name = "checkAsa";
            this.checkAsa.Size = new System.Drawing.Size(36, 16);
            this.checkAsa.TabIndex = 50;
            this.checkAsa.Text = "朝";
            this.checkAsa.UseVisualStyleBackColor = true;
            // 
            // checkHiru
            // 
            this.checkHiru.AutoSize = true;
            this.checkHiru.Location = new System.Drawing.Point(137, 16);
            this.checkHiru.Name = "checkHiru";
            this.checkHiru.Size = new System.Drawing.Size(36, 16);
            this.checkHiru.TabIndex = 49;
            this.checkHiru.Text = "昼";
            this.checkHiru.UseVisualStyleBackColor = true;
            // 
            // checkYugata
            // 
            this.checkYugata.AutoSize = true;
            this.checkYugata.Location = new System.Drawing.Point(197, 16);
            this.checkYugata.Name = "checkYugata";
            this.checkYugata.Size = new System.Drawing.Size(48, 16);
            this.checkYugata.TabIndex = 51;
            this.checkYugata.Text = "夕方";
            this.checkYugata.UseVisualStyleBackColor = true;
            // 
            // checkAsagata
            // 
            this.checkAsagata.AutoSize = true;
            this.checkAsagata.Location = new System.Drawing.Point(23, 16);
            this.checkAsagata.Name = "checkAsagata";
            this.checkAsagata.Size = new System.Drawing.Size(48, 16);
            this.checkAsagata.TabIndex = 53;
            this.checkAsagata.Text = "早朝";
            this.checkAsagata.UseVisualStyleBackColor = true;
            // 
            // checkSinya
            // 
            this.checkSinya.AutoSize = true;
            this.checkSinya.Location = new System.Drawing.Point(251, 16);
            this.checkSinya.Name = "checkSinya";
            this.checkSinya.Size = new System.Drawing.Size(48, 16);
            this.checkSinya.TabIndex = 65;
            this.checkSinya.Text = "深夜";
            this.checkSinya.UseVisualStyleBackColor = true;
            // 
            // checkWeek1
            // 
            this.checkWeek1.AutoSize = true;
            this.checkWeek1.Location = new System.Drawing.Point(23, 38);
            this.checkWeek1.Name = "checkWeek1";
            this.checkWeek1.Size = new System.Drawing.Size(72, 16);
            this.checkWeek1.TabIndex = 55;
            this.checkWeek1.Text = "週1～2日";
            this.checkWeek1.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(476, 189);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 36;
            this.label18.Text = "写真";
            // 
            // txtJobContents
            // 
            this.txtJobContents.Location = new System.Drawing.Point(90, 75);
            this.txtJobContents.Multiline = true;
            this.txtJobContents.Name = "txtJobContents";
            this.txtJobContents.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtJobContents.Size = new System.Drawing.Size(368, 144);
            this.txtJobContents.TabIndex = 35;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(283, 226);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 34;
            this.label17.Text = "単位";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(13, 483);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 12);
            this.label14.TabIndex = 30;
            this.label14.Text = "応募締め切り";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(476, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(55, 12);
            this.label13.TabIndex = 29;
            this.label13.Text = "アピール文";
            // 
            // comboTodo
            // 
            this.comboTodo.FormattingEnabled = true;
            this.comboTodo.Location = new System.Drawing.Point(90, 246);
            this.comboTodo.Name = "comboTodo";
            this.comboTodo.Size = new System.Drawing.Size(100, 20);
            this.comboTodo.TabIndex = 28;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(294, 459);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 12);
            this.label12.TabIndex = 27;
            this.label12.Text = "円まで";
            // 
            // comboSalTani
            // 
            this.comboSalTani.FormattingEnabled = true;
            this.comboSalTani.Location = new System.Drawing.Point(328, 223);
            this.comboSalTani.Name = "comboSalTani";
            this.comboSalTani.Size = new System.Drawing.Size(123, 20);
            this.comboSalTani.TabIndex = 26;
            // 
            // comboJobType
            // 
            this.comboJobType.FormattingEnabled = true;
            this.comboJobType.Location = new System.Drawing.Point(90, 28);
            this.comboJobType.Name = "comboJobType";
            this.comboJobType.Size = new System.Drawing.Size(273, 20);
            this.comboJobType.TabIndex = 18;
            // 
            // txtArea
            // 
            this.txtArea.Location = new System.Drawing.Point(90, 270);
            this.txtArea.Name = "txtArea";
            this.txtArea.Size = new System.Drawing.Size(368, 19);
            this.txtArea.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 457);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 16;
            this.label9.Text = "交通費";
            // 
            // txtTranMoney
            // 
            this.txtTranMoney.Location = new System.Drawing.Point(143, 454);
            this.txtTranMoney.Name = "txtTranMoney";
            this.txtTranMoney.Size = new System.Drawing.Size(143, 19);
            this.txtTranMoney.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 434);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 14;
            this.label8.Text = "最寄駅";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 368);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 12;
            this.label7.Text = "勤務条件";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 298);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 10;
            this.label6.Text = "勤務時間";
            // 
            // txtStation
            // 
            this.txtStation.Location = new System.Drawing.Point(90, 431);
            this.txtStation.Name = "txtStation";
            this.txtStation.Size = new System.Drawing.Size(368, 19);
            this.txtStation.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 249);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "勤務地";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 226);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "給与";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "仕事の内容";
            // 
            // txtJobIntro
            // 
            this.txtJobIntro.Location = new System.Drawing.Point(90, 52);
            this.txtJobIntro.Name = "txtJobIntro";
            this.txtJobIntro.Size = new System.Drawing.Size(368, 19);
            this.txtJobIntro.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(205, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "企業";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "仕事の紹介";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(13, 9);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(45, 12);
            this.label26.TabIndex = 0;
            this.label26.Text = "案件NO";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "業種";
            // 
            // frmJobDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LemonChiffon;
            this.ClientSize = new System.Drawing.Size(1162, 701);
            this.Controls.Add(this.panel1);
            this.Name = "frmJobDetail";
            this.Text = "jobDetail";
            this.Load += new System.EventHandler(this.frmJobDetail_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtCloseYmd;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtJobContents;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboTodo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboSalTani;
        private System.Windows.Forms.ComboBox comboJobType;
        private System.Windows.Forms.TextBox txtArea;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTranMoney;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtStation;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtJobIntro;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox checkWeekEnd;
        private System.Windows.Forms.CheckBox checkSheeft;
        private System.Windows.Forms.CheckBox checkTanki;
        private System.Windows.Forms.CheckBox checkWeekDay;
        private System.Windows.Forms.CheckBox checkConsul;
        private System.Windows.Forms.CheckBox checkAtHome;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox checkWeek3;
        private System.Windows.Forms.CheckBox checkWeek2;
        private System.Windows.Forms.CheckBox checkAsa;
        private System.Windows.Forms.CheckBox checkHiru;
        private System.Windows.Forms.CheckBox checkYugata;
        private System.Windows.Forms.CheckBox checkAsagata;
        private System.Windows.Forms.CheckBox checkSinya;
        private System.Windows.Forms.CheckBox checkWeek1;
        private System.Windows.Forms.RadioButton radioNashi;
        private System.Windows.Forms.RadioButton radioAri;
        private System.Windows.Forms.TextBox txtAppeal;
        private System.Windows.Forms.ComboBox comboSalType;
        private System.Windows.Forms.PictureBox picBox;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox_MailBody;
        private System.Windows.Forms.TextBox textBox_MailTitle;
        private System.Windows.Forms.TextBox textBox_mailBcc;
        private System.Windows.Forms.TextBox textBox_mailCc;
        private System.Windows.Forms.TextBox textBox_fromTo;
        private System.Windows.Forms.TextBox textBox_mailFrom;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox_appealPoint_B;
        private System.Windows.Forms.TextBox textBox_appealPoint_A;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox comboBox_PUBLISHLANGTO;
        private System.Windows.Forms.ComboBox comboBox_PUBLISHLANGFROM;
        private System.Windows.Forms.CheckBox checkBox_Need_Translate;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.CheckedListBox checkedListBox_publish;
        private System.Windows.Forms.TextBox textBox_job_no;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox_kigyouNo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_kigyouName;
        private System.Windows.Forms.Button button_mailRefresh;
    }
}