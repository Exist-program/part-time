﻿namespace parttime.kanri
{
    partial class frmRegKanri
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRegKanri));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnDel = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnUpd = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtSyainNo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSyainNm = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.comboLevel = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtSyainPw = new System.Windows.Forms.TextBox();
            this.txtSyainId = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbCnt = new System.Windows.Forms.Label();
            this.axfpSpread1 = new AxFPUSpreadADO.AxfpSpread();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axfpSpread1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.LemonChiffon;
            this.groupBox3.Controls.Add(this.btnClose);
            this.groupBox3.Controls.Add(this.btnDel);
            this.groupBox3.Controls.Add(this.btnClear);
            this.groupBox3.Controls.Add(this.btnUpd);
            this.groupBox3.Location = new System.Drawing.Point(12, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1138, 40);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnClose.Location = new System.Drawing.Point(852, 11);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnDel
            // 
            this.btnDel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnDel.Location = new System.Drawing.Point(225, 11);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(75, 23);
            this.btnDel.TabIndex = 1;
            this.btnDel.Text = "削除";
            this.btnDel.UseVisualStyleBackColor = true;
            this.btnDel.Click += new System.EventHandler(this.btnDel_Click);
            // 
            // btnClear
            // 
            this.btnClear.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnClear.Location = new System.Drawing.Point(308, 11);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnUpd
            // 
            this.btnUpd.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnUpd.Location = new System.Drawing.Point(143, 11);
            this.btnUpd.Name = "btnUpd";
            this.btnUpd.Size = new System.Drawing.Size(75, 23);
            this.btnUpd.TabIndex = 0;
            this.btnUpd.Text = "更新";
            this.btnUpd.UseVisualStyleBackColor = true;
            this.btnUpd.Click += new System.EventHandler(this.btnUpd_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtSyainNo);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtSyainNm);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.comboLevel);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.txtSyainPw);
            this.groupBox2.Controls.Add(this.txtSyainId);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(12, 49);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1138, 151);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "社員情報";
            // 
            // txtSyainNo
            // 
            this.txtSyainNo.Location = new System.Drawing.Point(143, 12);
            this.txtSyainNo.Name = "txtSyainNo";
            this.txtSyainNo.ReadOnly = true;
            this.txtSyainNo.Size = new System.Drawing.Size(120, 19);
            this.txtSyainNo.TabIndex = 79;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(89, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 12);
            this.label3.TabIndex = 78;
            this.label3.Text = "社員No";
            // 
            // txtSyainNm
            // 
            this.txtSyainNm.Location = new System.Drawing.Point(143, 67);
            this.txtSyainNm.Name = "txtSyainNm";
            this.txtSyainNm.Size = new System.Drawing.Size(120, 19);
            this.txtSyainNm.TabIndex = 77;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(89, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 12);
            this.label2.TabIndex = 76;
            this.label2.Text = "PW";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label26.Location = new System.Drawing.Point(89, 126);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(34, 12);
            this.label26.TabIndex = 66;
            this.label26.Text = "レベル";
            // 
            // comboLevel
            // 
            this.comboLevel.Location = new System.Drawing.Point(143, 124);
            this.comboLevel.Name = "comboLevel";
            this.comboLevel.Size = new System.Drawing.Size(120, 20);
            this.comboLevel.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label25.Location = new System.Drawing.Point(89, 71);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(41, 12);
            this.label25.TabIndex = 64;
            this.label25.Text = "社員名";
            // 
            // txtSyainPw
            // 
            this.txtSyainPw.Location = new System.Drawing.Point(143, 96);
            this.txtSyainPw.Name = "txtSyainPw";
            this.txtSyainPw.Size = new System.Drawing.Size(120, 19);
            this.txtSyainPw.TabIndex = 5;
            // 
            // txtSyainId
            // 
            this.txtSyainId.Location = new System.Drawing.Point(143, 39);
            this.txtSyainId.Name = "txtSyainId";
            this.txtSyainId.Size = new System.Drawing.Size(120, 19);
            this.txtSyainId.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(89, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 12);
            this.label1.TabIndex = 61;
            this.label1.Text = "社員ID";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.axfpSpread1);
            this.panel1.Location = new System.Drawing.Point(13, 231);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1137, 458);
            this.panel1.TabIndex = 3;
            // 
            // lbCnt
            // 
            this.lbCnt.AutoSize = true;
            this.lbCnt.Location = new System.Drawing.Point(59, 209);
            this.lbCnt.Name = "lbCnt";
            this.lbCnt.Size = new System.Drawing.Size(35, 12);
            this.lbCnt.TabIndex = 4;
            this.lbCnt.Text = "label3";
            // 
            // axfpSpread1
            // 
            this.axfpSpread1.DataSource = null;
            this.axfpSpread1.Location = new System.Drawing.Point(8, 5);
            this.axfpSpread1.Name = "axfpSpread1";
            this.axfpSpread1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axfpSpread1.OcxState")));
            this.axfpSpread1.Size = new System.Drawing.Size(1126, 450);
            this.axfpSpread1.TabIndex = 0;
            this.axfpSpread1.ClickEvent += new AxFPUSpreadADO._DSpreadEvents_ClickEventHandler(this.axfpSpread1_ClickEvent);
            // 
            // frmRegKanri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LemonChiffon;
            this.ClientSize = new System.Drawing.Size(1162, 701);
            this.Controls.Add(this.lbCnt);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Name = "frmRegKanri";
            this.Text = "管理者登録";
            this.Load += new System.EventHandler(this.frmRegKanri_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axfpSpread1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnDel;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnUpd;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox comboLevel;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtSyainPw;
        private System.Windows.Forms.TextBox txtSyainId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSyainNm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private AxFPUSpreadADO.AxfpSpread axfpSpread1;
        private System.Windows.Forms.Label lbCnt;
        private System.Windows.Forms.TextBox txtSyainNo;
        private System.Windows.Forms.Label label3;
    }
}