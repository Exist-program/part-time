﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using parttime.common;

namespace parttime.kanri
{
    public partial class frmRegKanri : Form
    {
        public frmRegKanri()
        {
            InitializeComponent();
        }

        private void frmRegKanri_Load(object sender, EventArgs e)
        {

            Common.setComboBox(1, comboLevel);
            setPage();
            setField();
        }

        private void btnUpd_Click(object sender, EventArgs e)
        {
            updWorker();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            remomveWorker();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            fieldClear();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            frmClose();
        }

        private void axfpSpread1_ClickEvent(object sender, AxFPUSpreadADO._DSpreadEvents_ClickEvent e)
        {
            for (int j = 0; j <= axfpSpread1.MaxRows; j++)
            {
                Common.setFildSpread(axfpSpread1, 3, j);
                if (axfpSpread1.BackColor == Color.Lavender)
                {
                    for (int k = 1; k <= axfpSpread1.MaxCols; k++)
                    {
                        Common.setFildSpread(axfpSpread1, k + 1, j);
                        axfpSpread1.BackColor = Color.White;
                    }
                }
            }

            for (int i = 1; i <= axfpSpread1.MaxCols; i++)
            {
                int col = -1;

                Common.setFildSpread(axfpSpread1, col = i + 1, e.row);
                axfpSpread1.BackColor = Color.Lavender;

                object val = null;

                axfpSpread1.GetText(col, e.row, ref val);

                if (col == 2)
                {

                    txtSyainNo.Text = (string)val;

                }
                else if (col == 3)
                {

                    txtSyainId.Text = (string)val;

                }
                else if (col == 4)
                {

                    txtSyainNm.Text = (string)val;

                }
                else if (col == 5)
                {
                    string code = null;

                    if (((string)val).Trim().Equals(CodeMaster.Master))
                    {
                        code = CodeMaster.Level_Master;
                    }
                    else if (((string)val).Trim().Equals(CodeMaster.Public))
                    {

                        code = CodeMaster.Level_Public;
                    }
                    else {

                        code = CodeMaster.Level_Limited;
                    }

                    comboLevel.SelectedValue = code;
                }
                else if (col == 6)
                {

                    txtSyainPw.Text = (string)val;

                }

            }

        }

        private void setPage()
        {
            Common.setClrSpread(axfpSpread1);
            setSpread();
        }

        private void updWorker()
        {

            ArrayList colList = new ArrayList();
            ArrayList valList = new ArrayList();

            colList.Add("@admin_id");
            colList.Add("@admin_name");
            colList.Add("@admin_pw");
            colList.Add("@admin_level");
            colList.Add("@vadmin_id");
            colList.Add("@vadmin_pw");

            valList.Add(txtSyainId.Text.ToString());
            valList.Add(txtSyainNm.Text.ToString());
            valList.Add(txtSyainPw.Text.ToString());
            valList.Add(comboLevel.SelectedValue.ToString());
            valList.Add(txtSyainId.Text.ToString());
            valList.Add(txtSyainPw.Text.ToString());

            string ret = DbCon.insertInfo(colList, valList, Sql.UDP_01);

            if (CodeMaster.OK.Equals(ret))
            {
                setPage();
            }

        }

        private void remomveWorker()
        {
            int totCnt = 0;

            for (int i = 1; i <= axfpSpread1.MaxRows; i++)
            {
                Common.setFildSpread(axfpSpread1, 1, i);
                if (axfpSpread1.Text == "1")
                {
                    totCnt++;
                }
            }

            if(totCnt > 0) {

                for (int i = 1; i < axfpSpread1.MaxRows; i++)
                {
                    Common.setFildSpread(axfpSpread1, 1, i);

                    ArrayList colList = new ArrayList();
                    ArrayList valList = new ArrayList();

                    if (axfpSpread1.Text == "1")
                    {
                        colList.Clear();
                        valList.Clear();

                        colList.Add("@admin_id");
                        colList.Add("@admin_pw");

                        Common.setFildSpread(axfpSpread1, 3, i);
                        string val = axfpSpread1.Text;
                        valList.Add(val);

                        Common.setFildSpread(axfpSpread1, 6, i);
                        val = axfpSpread1.Text;
                        valList.Add(val);

                        string ret = DbCon.updateInfo(colList, valList, Sql.DEL_01);

                        if (CodeMaster.OK.Equals(ret))
                        {
                            setPage();
                        }
                    }
                }

            } else {

                MessageBox.Show("チェックボークスを選択してください。");
            }

        }

        private void fieldClear() {

            txtSyainNo.Text = string.Empty;
            txtSyainId.Text = string.Empty;
            txtSyainNm.Text = string.Empty;
            txtSyainPw.Text = string.Empty;
            comboLevel.SelectedValue = "";
        }

        private void frmClose() {

            frmRegKanri_FormClosing(null, null);
            this.Close();
        }

        private void frmRegKanri_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmMain pForm = (frmMain)this.MdiParent;
            CodeMaster.FormArray.Remove(this);
        }

        private void setSpread() {

            DataSet ds = DbCon.selectInfoNoneCondition(Sql.SEL_03);

            if (ds.Tables[0].Rows.Count > 0)
            {
                axfpSpread1.MaxRows = ds.Tables[0].Rows.Count;

                for (int i = 0; i < axfpSpread1.MaxRows;i++ )
                {

                    axfpSpread1.SetText(2, i + 1, ds.Tables[0].Rows[i]["admin_no"].ToString());

                    axfpSpread1.SetText(3, i + 1, ds.Tables[0].Rows[i]["admin_id"].ToString());

                    axfpSpread1.SetText(4, i + 1, ds.Tables[0].Rows[i]["admin_name"].ToString());

                    axfpSpread1.SetText(5, i + 1, getLevelStr(ds.Tables[0].Rows[i]["admin_level"].ToString()));
                    axfpSpread1.SetText(6, i + 1, ds.Tables[0].Rows[i]["admin_pw"].ToString());
                }

                lbCnt.Text = Convert.ToString(ds.Tables[0].Rows.Count);

            }
            else {

                lbCnt.Text = "該当なし";
                axfpSpread1.MaxRows = 0;
            }
        }

        private void setField()
        {

            object val = null;

            // No.
            axfpSpread1.GetText(2, 1, ref val);

            txtSyainNo.Text = (string)val;

            val = null;

            // ID
            axfpSpread1.GetText(3, 1, ref val);

            txtSyainId.Text = (string)val;

            val = null;

            // Name
            axfpSpread1.GetText(4, 1, ref val);

            txtSyainNm.Text = (string)val;

            val = null;

            // Pw
            axfpSpread1.GetText(6, 1, ref val);

            txtSyainPw.Text = (string)val;

            val = null;

            // Level
            axfpSpread1.GetText(5, 1, ref val);

            string code = null;

            if (((string)val).Trim().Equals(CodeMaster.Master))
            {
                code = CodeMaster.Level_Master;
            }
            else if (((string)val).Trim().Equals(CodeMaster.Public))
            {
                code = CodeMaster.Level_Public;
            }
            else
            {
                code = CodeMaster.Level_Limited;
            }

            comboLevel.SelectedValue = code;

        }

        private string getLevelStr(string val) { 
            
            if(CodeMaster.Level_Master.Equals(val)) {

                val = CodeMaster.Master;

            } else if(CodeMaster.Level_Public.Equals(val)) {

                val = CodeMaster.Public;

            } else if(CodeMaster.Level_Limited.Equals(val)) {

                val = CodeMaster.Limited;
            }

            return val;

        }

    }
}