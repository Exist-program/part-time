﻿namespace parttime.staff
{
    partial class frmStaffDetail
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkWeekEnd = new System.Windows.Forms.CheckBox();
            this.checkSheeft = new System.Windows.Forms.CheckBox();
            this.checkTanki = new System.Windows.Forms.CheckBox();
            this.checkWeekDay = new System.Windows.Forms.CheckBox();
            this.checkConsul = new System.Windows.Forms.CheckBox();
            this.checkAtHome = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkWeek3 = new System.Windows.Forms.CheckBox();
            this.checkWeek2 = new System.Windows.Forms.CheckBox();
            this.checkAsa = new System.Windows.Forms.CheckBox();
            this.checkHiru = new System.Windows.Forms.CheckBox();
            this.checkYugata = new System.Windows.Forms.CheckBox();
            this.checkAsagata = new System.Windows.Forms.CheckBox();
            this.checkSinya = new System.Windows.Forms.CheckBox();
            this.checkWeek1 = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.checkAmuse2 = new System.Windows.Forms.CheckBox();
            this.checkOffice3 = new System.Windows.Forms.CheckBox();
            this.checkOffice4 = new System.Windows.Forms.CheckBox();
            this.checkMedical = new System.Windows.Forms.CheckBox();
            this.checkRest = new System.Windows.Forms.CheckBox();
            this.checkIt2 = new System.Windows.Forms.CheckBox();
            this.checkIt3 = new System.Windows.Forms.CheckBox();
            this.checkLan2 = new System.Windows.Forms.CheckBox();
            this.checkEvent = new System.Windows.Forms.CheckBox();
            this.checkFacion = new System.Windows.Forms.CheckBox();
            this.checkBeauty = new System.Windows.Forms.CheckBox();
            this.checkLan1 = new System.Windows.Forms.CheckBox();
            this.checkIt1 = new System.Windows.Forms.CheckBox();
            this.checkAmuse4 = new System.Windows.Forms.CheckBox();
            this.checkAmuse5 = new System.Windows.Forms.CheckBox();
            this.checkAmuse3 = new System.Windows.Forms.CheckBox();
            this.checkAffare5 = new System.Windows.Forms.CheckBox();
            this.checkAffare3 = new System.Windows.Forms.CheckBox();
            this.checkAffare4 = new System.Windows.Forms.CheckBox();
            this.checkAffare2 = new System.Windows.Forms.CheckBox();
            this.checkAffare1 = new System.Windows.Forms.CheckBox();
            this.checkAmuse1 = new System.Windows.Forms.CheckBox();
            this.checkOffice5 = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.checkService2 = new System.Windows.Forms.CheckBox();
            this.checkService3 = new System.Windows.Forms.CheckBox();
            this.checkService4 = new System.Windows.Forms.CheckBox();
            this.checkService5 = new System.Windows.Forms.CheckBox();
            this.checkService6 = new System.Windows.Forms.CheckBox();
            this.checkService7 = new System.Windows.Forms.CheckBox();
            this.checkOffice1 = new System.Windows.Forms.CheckBox();
            this.checkOffice2 = new System.Windows.Forms.CheckBox();
            this.checkFood7 = new System.Windows.Forms.CheckBox();
            this.checkFood8 = new System.Windows.Forms.CheckBox();
            this.checkFood9 = new System.Windows.Forms.CheckBox();
            this.checkFood10 = new System.Windows.Forms.CheckBox();
            this.checkSell2 = new System.Windows.Forms.CheckBox();
            this.checkSell3 = new System.Windows.Forms.CheckBox();
            this.checkSell4 = new System.Windows.Forms.CheckBox();
            this.checkSell5 = new System.Windows.Forms.CheckBox();
            this.checkSell8 = new System.Windows.Forms.CheckBox();
            this.checkSell9 = new System.Windows.Forms.CheckBox();
            this.checkFood1 = new System.Windows.Forms.CheckBox();
            this.checkFood3 = new System.Windows.Forms.CheckBox();
            this.checkSell6 = new System.Windows.Forms.CheckBox();
            this.checkSell7 = new System.Windows.Forms.CheckBox();
            this.checkService1 = new System.Windows.Forms.CheckBox();
            this.checkFood5 = new System.Windows.Forms.CheckBox();
            this.checkFood6 = new System.Windows.Forms.CheckBox();
            this.checkFood4 = new System.Windows.Forms.CheckBox();
            this.checkFood2 = new System.Windows.Forms.CheckBox();
            this.checkSell1 = new System.Windows.Forms.CheckBox();
            this.label20 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtKeiMail = new System.Windows.Forms.TextBox();
            this.txtKeiTel = new System.Windows.Forms.TextBox();
            this.txtTel = new System.Windows.Forms.TextBox();
            this.checkScout = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtBirthDay = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.comboTerm2 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comboTodo = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.comboTerm1 = new System.Windows.Forms.ComboBox();
            this.comboSex = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.comboShcool = new System.Windows.Forms.ComboBox();
            this.comboSts = new System.Windows.Forms.ComboBox();
            this.comboLan = new System.Windows.Forms.ComboBox();
            this.comboJpnLev = new System.Windows.Forms.ComboBox();
            this.comboNation = new System.Windows.Forms.ComboBox();
            this.txtAddr2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAddr1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtJobCr2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtJobCr1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPostNo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNm = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMail = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.picBox = new System.Windows.Forms.PictureBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Wheat;
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1138, 677);
            this.panel1.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.LemonChiffon;
            this.groupBox4.Controls.Add(this.btnClose);
            this.groupBox4.Location = new System.Drawing.Point(4, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1131, 40);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            // 
            // btnClose
            // 
            this.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnClose.Location = new System.Drawing.Point(852, 11);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.LemonChiffon;
            this.groupBox3.Controls.Add(this.checkWeekEnd);
            this.groupBox3.Controls.Add(this.checkSheeft);
            this.groupBox3.Controls.Add(this.checkTanki);
            this.groupBox3.Controls.Add(this.checkWeekDay);
            this.groupBox3.Controls.Add(this.checkConsul);
            this.groupBox3.Controls.Add(this.checkAtHome);
            this.groupBox3.Location = new System.Drawing.Point(924, 173);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(211, 116);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "希望条件";
            // 
            // checkWeekEnd
            // 
            this.checkWeekEnd.AutoSize = true;
            this.checkWeekEnd.Location = new System.Drawing.Point(23, 41);
            this.checkWeekEnd.Name = "checkWeekEnd";
            this.checkWeekEnd.Size = new System.Drawing.Size(69, 16);
            this.checkWeekEnd.TabIndex = 47;
            this.checkWeekEnd.Text = "土日のみ";
            this.checkWeekEnd.UseVisualStyleBackColor = true;
            // 
            // checkSheeft
            // 
            this.checkSheeft.AutoSize = true;
            this.checkSheeft.Location = new System.Drawing.Point(23, 19);
            this.checkSheeft.Name = "checkSheeft";
            this.checkSheeft.Size = new System.Drawing.Size(86, 16);
            this.checkSheeft.TabIndex = 46;
            this.checkSheeft.Text = "シフト制勤務";
            this.checkSheeft.UseVisualStyleBackColor = true;
            // 
            // checkTanki
            // 
            this.checkTanki.AutoSize = true;
            this.checkTanki.Location = new System.Drawing.Point(117, 40);
            this.checkTanki.Name = "checkTanki";
            this.checkTanki.Size = new System.Drawing.Size(84, 16);
            this.checkTanki.TabIndex = 48;
            this.checkTanki.Text = "短期間勤務";
            this.checkTanki.UseVisualStyleBackColor = true;
            // 
            // checkWeekDay
            // 
            this.checkWeekDay.AutoSize = true;
            this.checkWeekDay.Location = new System.Drawing.Point(117, 18);
            this.checkWeekDay.Name = "checkWeekDay";
            this.checkWeekDay.Size = new System.Drawing.Size(69, 16);
            this.checkWeekDay.TabIndex = 52;
            this.checkWeekDay.Text = "平日のみ";
            this.checkWeekDay.UseVisualStyleBackColor = true;
            // 
            // checkConsul
            // 
            this.checkConsul.AutoSize = true;
            this.checkConsul.Location = new System.Drawing.Point(23, 63);
            this.checkConsul.Name = "checkConsul";
            this.checkConsul.Size = new System.Drawing.Size(138, 16);
            this.checkConsul.TabIndex = 41;
            this.checkConsul.Text = "時間・曜日応相談勤務";
            this.checkConsul.UseVisualStyleBackColor = true;
            // 
            // checkAtHome
            // 
            this.checkAtHome.AutoSize = true;
            this.checkAtHome.Location = new System.Drawing.Point(23, 85);
            this.checkAtHome.Name = "checkAtHome";
            this.checkAtHome.Size = new System.Drawing.Size(48, 16);
            this.checkAtHome.TabIndex = 62;
            this.checkAtHome.Text = "在宅";
            this.checkAtHome.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.LemonChiffon;
            this.groupBox2.Controls.Add(this.checkWeek3);
            this.groupBox2.Controls.Add(this.checkWeek2);
            this.groupBox2.Controls.Add(this.checkAsa);
            this.groupBox2.Controls.Add(this.checkHiru);
            this.groupBox2.Controls.Add(this.checkYugata);
            this.groupBox2.Controls.Add(this.checkAsagata);
            this.groupBox2.Controls.Add(this.checkSinya);
            this.groupBox2.Controls.Add(this.checkWeek1);
            this.groupBox2.Location = new System.Drawing.Point(924, 51);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(211, 116);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "希望勤務時間";
            // 
            // checkWeek3
            // 
            this.checkWeek3.AutoSize = true;
            this.checkWeek3.Location = new System.Drawing.Point(23, 87);
            this.checkWeek3.Name = "checkWeek3";
            this.checkWeek3.Size = new System.Drawing.Size(78, 16);
            this.checkWeek3.TabIndex = 67;
            this.checkWeek3.Text = "週5日以上";
            this.checkWeek3.UseVisualStyleBackColor = true;
            // 
            // checkWeek2
            // 
            this.checkWeek2.AutoSize = true;
            this.checkWeek2.Location = new System.Drawing.Point(114, 65);
            this.checkWeek2.Name = "checkWeek2";
            this.checkWeek2.Size = new System.Drawing.Size(72, 16);
            this.checkWeek2.TabIndex = 66;
            this.checkWeek2.Text = "週3～4日";
            this.checkWeek2.UseVisualStyleBackColor = true;
            // 
            // checkAsa
            // 
            this.checkAsa.AutoSize = true;
            this.checkAsa.Location = new System.Drawing.Point(82, 16);
            this.checkAsa.Name = "checkAsa";
            this.checkAsa.Size = new System.Drawing.Size(36, 16);
            this.checkAsa.TabIndex = 50;
            this.checkAsa.Text = "朝";
            this.checkAsa.UseVisualStyleBackColor = true;
            // 
            // checkHiru
            // 
            this.checkHiru.AutoSize = true;
            this.checkHiru.Location = new System.Drawing.Point(137, 16);
            this.checkHiru.Name = "checkHiru";
            this.checkHiru.Size = new System.Drawing.Size(36, 16);
            this.checkHiru.TabIndex = 49;
            this.checkHiru.Text = "昼";
            this.checkHiru.UseVisualStyleBackColor = true;
            // 
            // checkYugata
            // 
            this.checkYugata.AutoSize = true;
            this.checkYugata.Location = new System.Drawing.Point(23, 41);
            this.checkYugata.Name = "checkYugata";
            this.checkYugata.Size = new System.Drawing.Size(48, 16);
            this.checkYugata.TabIndex = 51;
            this.checkYugata.Text = "夕方";
            this.checkYugata.UseVisualStyleBackColor = true;
            // 
            // checkAsagata
            // 
            this.checkAsagata.AutoSize = true;
            this.checkAsagata.Location = new System.Drawing.Point(23, 16);
            this.checkAsagata.Name = "checkAsagata";
            this.checkAsagata.Size = new System.Drawing.Size(48, 16);
            this.checkAsagata.TabIndex = 53;
            this.checkAsagata.Text = "早朝";
            this.checkAsagata.UseVisualStyleBackColor = true;
            // 
            // checkSinya
            // 
            this.checkSinya.AutoSize = true;
            this.checkSinya.Location = new System.Drawing.Point(82, 38);
            this.checkSinya.Name = "checkSinya";
            this.checkSinya.Size = new System.Drawing.Size(48, 16);
            this.checkSinya.TabIndex = 65;
            this.checkSinya.Text = "深夜";
            this.checkSinya.UseVisualStyleBackColor = true;
            // 
            // checkWeek1
            // 
            this.checkWeek1.AutoSize = true;
            this.checkWeek1.Location = new System.Drawing.Point(23, 65);
            this.checkWeek1.Name = "checkWeek1";
            this.checkWeek1.Size = new System.Drawing.Size(72, 16);
            this.checkWeek1.TabIndex = 55;
            this.checkWeek1.Text = "週1～2日";
            this.checkWeek1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LemonChiffon;
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.checkAmuse2);
            this.groupBox1.Controls.Add(this.checkOffice3);
            this.groupBox1.Controls.Add(this.checkOffice4);
            this.groupBox1.Controls.Add(this.checkMedical);
            this.groupBox1.Controls.Add(this.checkRest);
            this.groupBox1.Controls.Add(this.checkIt2);
            this.groupBox1.Controls.Add(this.checkIt3);
            this.groupBox1.Controls.Add(this.checkLan2);
            this.groupBox1.Controls.Add(this.checkEvent);
            this.groupBox1.Controls.Add(this.checkFacion);
            this.groupBox1.Controls.Add(this.checkBeauty);
            this.groupBox1.Controls.Add(this.checkLan1);
            this.groupBox1.Controls.Add(this.checkIt1);
            this.groupBox1.Controls.Add(this.checkAmuse4);
            this.groupBox1.Controls.Add(this.checkAmuse5);
            this.groupBox1.Controls.Add(this.checkAmuse3);
            this.groupBox1.Controls.Add(this.checkAffare5);
            this.groupBox1.Controls.Add(this.checkAffare3);
            this.groupBox1.Controls.Add(this.checkAffare4);
            this.groupBox1.Controls.Add(this.checkAffare2);
            this.groupBox1.Controls.Add(this.checkAffare1);
            this.groupBox1.Controls.Add(this.checkAmuse1);
            this.groupBox1.Controls.Add(this.checkOffice5);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.checkService2);
            this.groupBox1.Controls.Add(this.checkService3);
            this.groupBox1.Controls.Add(this.checkService4);
            this.groupBox1.Controls.Add(this.checkService5);
            this.groupBox1.Controls.Add(this.checkService6);
            this.groupBox1.Controls.Add(this.checkService7);
            this.groupBox1.Controls.Add(this.checkOffice1);
            this.groupBox1.Controls.Add(this.checkOffice2);
            this.groupBox1.Controls.Add(this.checkFood7);
            this.groupBox1.Controls.Add(this.checkFood8);
            this.groupBox1.Controls.Add(this.checkFood9);
            this.groupBox1.Controls.Add(this.checkFood10);
            this.groupBox1.Controls.Add(this.checkSell2);
            this.groupBox1.Controls.Add(this.checkSell3);
            this.groupBox1.Controls.Add(this.checkSell4);
            this.groupBox1.Controls.Add(this.checkSell5);
            this.groupBox1.Controls.Add(this.checkSell8);
            this.groupBox1.Controls.Add(this.checkSell9);
            this.groupBox1.Controls.Add(this.checkFood1);
            this.groupBox1.Controls.Add(this.checkFood3);
            this.groupBox1.Controls.Add(this.checkSell6);
            this.groupBox1.Controls.Add(this.checkSell7);
            this.groupBox1.Controls.Add(this.checkService1);
            this.groupBox1.Controls.Add(this.checkFood5);
            this.groupBox1.Controls.Add(this.checkFood6);
            this.groupBox1.Controls.Add(this.checkFood4);
            this.groupBox1.Controls.Add(this.checkFood2);
            this.groupBox1.Controls.Add(this.checkSell1);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Location = new System.Drawing.Point(367, 51);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(551, 623);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "希望職種";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label27.Location = new System.Drawing.Point(203, 419);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(96, 12);
            this.label27.TabIndex = 70;
            this.label27.Text = "外国語語学講師";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label28.Location = new System.Drawing.Point(18, 419);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(143, 12);
            this.label28.TabIndex = 69;
            this.label28.Text = "製造・組立・建設・他作業";
            // 
            // checkAmuse2
            // 
            this.checkAmuse2.AutoSize = true;
            this.checkAmuse2.Location = new System.Drawing.Point(205, 316);
            this.checkAmuse2.Name = "checkAmuse2";
            this.checkAmuse2.Size = new System.Drawing.Size(72, 16);
            this.checkAmuse2.TabIndex = 68;
            this.checkAmuse2.Text = "漫画喫茶";
            this.checkAmuse2.UseVisualStyleBackColor = true;
            // 
            // checkOffice3
            // 
            this.checkOffice3.AutoSize = true;
            this.checkOffice3.Location = new System.Drawing.Point(19, 338);
            this.checkOffice3.Name = "checkOffice3";
            this.checkOffice3.Size = new System.Drawing.Size(78, 16);
            this.checkOffice3.TabIndex = 67;
            this.checkOffice3.Text = "広報・宣伝";
            this.checkOffice3.UseVisualStyleBackColor = true;
            // 
            // checkOffice4
            // 
            this.checkOffice4.AutoSize = true;
            this.checkOffice4.Location = new System.Drawing.Point(19, 360);
            this.checkOffice4.Name = "checkOffice4";
            this.checkOffice4.Size = new System.Drawing.Size(89, 16);
            this.checkOffice4.TabIndex = 66;
            this.checkOffice4.Text = "コールセンター";
            this.checkOffice4.UseVisualStyleBackColor = true;
            // 
            // checkMedical
            // 
            this.checkMedical.AutoSize = true;
            this.checkMedical.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkMedical.Location = new System.Drawing.Point(19, 562);
            this.checkMedical.Name = "checkMedical";
            this.checkMedical.Size = new System.Drawing.Size(116, 16);
            this.checkMedical.TabIndex = 64;
            this.checkMedical.Text = "医療・看護・介護";
            this.checkMedical.UseVisualStyleBackColor = true;
            // 
            // checkRest
            // 
            this.checkRest.AutoSize = true;
            this.checkRest.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkRest.Location = new System.Drawing.Point(205, 562);
            this.checkRest.Name = "checkRest";
            this.checkRest.Size = new System.Drawing.Size(104, 16);
            this.checkRest.TabIndex = 63;
            this.checkRest.Text = "専門職・その他";
            this.checkRest.UseVisualStyleBackColor = true;
            // 
            // checkIt2
            // 
            this.checkIt2.AutoSize = true;
            this.checkIt2.Location = new System.Drawing.Point(19, 464);
            this.checkIt2.Name = "checkIt2";
            this.checkIt2.Size = new System.Drawing.Size(135, 16);
            this.checkIt2.TabIndex = 61;
            this.checkIt2.Text = "WEB・編集・クリエイター";
            this.checkIt2.UseVisualStyleBackColor = true;
            // 
            // checkIt3
            // 
            this.checkIt3.AutoSize = true;
            this.checkIt3.Location = new System.Drawing.Point(19, 486);
            this.checkIt3.Name = "checkIt3";
            this.checkIt3.Size = new System.Drawing.Size(110, 16);
            this.checkIt3.TabIndex = 60;
            this.checkIt3.Text = "IT関連・エンジニア";
            this.checkIt3.UseVisualStyleBackColor = true;
            // 
            // checkLan2
            // 
            this.checkLan2.AutoSize = true;
            this.checkLan2.Location = new System.Drawing.Point(205, 464);
            this.checkLan2.Name = "checkLan2";
            this.checkLan2.Size = new System.Drawing.Size(120, 16);
            this.checkLan2.TabIndex = 59;
            this.checkLan2.Text = "語学塾非常勤講師";
            this.checkLan2.UseVisualStyleBackColor = true;
            // 
            // checkEvent
            // 
            this.checkEvent.AutoSize = true;
            this.checkEvent.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkEvent.Location = new System.Drawing.Point(20, 528);
            this.checkEvent.Name = "checkEvent";
            this.checkEvent.Size = new System.Drawing.Size(166, 16);
            this.checkEvent.TabIndex = 58;
            this.checkEvent.Text = "イベント・芸能・キャンペーン";
            this.checkEvent.UseVisualStyleBackColor = true;
            // 
            // checkFacion
            // 
            this.checkFacion.AutoSize = true;
            this.checkFacion.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkFacion.Location = new System.Drawing.Point(205, 528);
            this.checkFacion.Name = "checkFacion";
            this.checkFacion.Size = new System.Drawing.Size(126, 16);
            this.checkFacion.TabIndex = 57;
            this.checkFacion.Text = "ファッション・アパレル";
            this.checkFacion.UseVisualStyleBackColor = true;
            // 
            // checkBeauty
            // 
            this.checkBeauty.AutoSize = true;
            this.checkBeauty.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkBeauty.Location = new System.Drawing.Point(371, 528);
            this.checkBeauty.Name = "checkBeauty";
            this.checkBeauty.Size = new System.Drawing.Size(126, 16);
            this.checkBeauty.TabIndex = 56;
            this.checkBeauty.Text = "美容・エステ・ネイル";
            this.checkBeauty.UseVisualStyleBackColor = true;
            // 
            // checkLan1
            // 
            this.checkLan1.AutoSize = true;
            this.checkLan1.Location = new System.Drawing.Point(205, 441);
            this.checkLan1.Name = "checkLan1";
            this.checkLan1.Size = new System.Drawing.Size(166, 16);
            this.checkLan1.TabIndex = 54;
            this.checkLan1.Text = "個人レッスン・プライベート講師";
            this.checkLan1.UseVisualStyleBackColor = true;
            // 
            // checkIt1
            // 
            this.checkIt1.AutoSize = true;
            this.checkIt1.Location = new System.Drawing.Point(19, 441);
            this.checkIt1.Name = "checkIt1";
            this.checkIt1.Size = new System.Drawing.Size(138, 16);
            this.checkIt1.TabIndex = 45;
            this.checkIt1.Text = "データ入力・オペレーター";
            this.checkIt1.UseVisualStyleBackColor = true;
            // 
            // checkAmuse4
            // 
            this.checkAmuse4.AutoSize = true;
            this.checkAmuse4.Location = new System.Drawing.Point(205, 360);
            this.checkAmuse4.Name = "checkAmuse4";
            this.checkAmuse4.Size = new System.Drawing.Size(60, 16);
            this.checkAmuse4.TabIndex = 44;
            this.checkAmuse4.Text = "映画館";
            this.checkAmuse4.UseVisualStyleBackColor = true;
            // 
            // checkAmuse5
            // 
            this.checkAmuse5.AutoSize = true;
            this.checkAmuse5.Location = new System.Drawing.Point(205, 383);
            this.checkAmuse5.Name = "checkAmuse5";
            this.checkAmuse5.Size = new System.Drawing.Size(124, 16);
            this.checkAmuse5.TabIndex = 43;
            this.checkAmuse5.Text = "その他アミューズメント";
            this.checkAmuse5.UseVisualStyleBackColor = true;
            // 
            // checkAmuse3
            // 
            this.checkAmuse3.AutoSize = true;
            this.checkAmuse3.Location = new System.Drawing.Point(205, 338);
            this.checkAmuse3.Name = "checkAmuse3";
            this.checkAmuse3.Size = new System.Drawing.Size(134, 16);
            this.checkAmuse3.TabIndex = 42;
            this.checkAmuse3.Text = "レジャー・ゲームセンター";
            this.checkAmuse3.UseVisualStyleBackColor = true;
            // 
            // checkAffare5
            // 
            this.checkAffare5.AutoSize = true;
            this.checkAffare5.Location = new System.Drawing.Point(371, 381);
            this.checkAffare5.Name = "checkAffare5";
            this.checkAffare5.Size = new System.Drawing.Size(151, 16);
            this.checkAffare5.TabIndex = 40;
            this.checkAffare5.Text = "その他軽作業・清掃・警備";
            this.checkAffare5.UseVisualStyleBackColor = true;
            // 
            // checkAffare3
            // 
            this.checkAffare3.AutoSize = true;
            this.checkAffare3.Location = new System.Drawing.Point(371, 338);
            this.checkAffare3.Name = "checkAffare3";
            this.checkAffare3.Size = new System.Drawing.Size(48, 16);
            this.checkAffare3.TabIndex = 39;
            this.checkAffare3.Text = "警備";
            this.checkAffare3.UseVisualStyleBackColor = true;
            // 
            // checkAffare4
            // 
            this.checkAffare4.AutoSize = true;
            this.checkAffare4.Location = new System.Drawing.Point(371, 360);
            this.checkAffare4.Name = "checkAffare4";
            this.checkAffare4.Size = new System.Drawing.Size(48, 16);
            this.checkAffare4.TabIndex = 38;
            this.checkAffare4.Text = "清掃";
            this.checkAffare4.UseVisualStyleBackColor = true;
            // 
            // checkAffare2
            // 
            this.checkAffare2.AutoSize = true;
            this.checkAffare2.Location = new System.Drawing.Point(371, 314);
            this.checkAffare2.Name = "checkAffare2";
            this.checkAffare2.Size = new System.Drawing.Size(97, 16);
            this.checkAffare2.TabIndex = 37;
            this.checkAffare2.Text = "仕分け・引越し";
            this.checkAffare2.UseVisualStyleBackColor = true;
            // 
            // checkAffare1
            // 
            this.checkAffare1.AutoSize = true;
            this.checkAffare1.Location = new System.Drawing.Point(371, 292);
            this.checkAffare1.Name = "checkAffare1";
            this.checkAffare1.Size = new System.Drawing.Size(126, 16);
            this.checkAffare1.TabIndex = 36;
            this.checkAffare1.Text = "商品梱包・在庫管理";
            this.checkAffare1.UseVisualStyleBackColor = true;
            // 
            // checkAmuse1
            // 
            this.checkAmuse1.AutoSize = true;
            this.checkAmuse1.Location = new System.Drawing.Point(205, 292);
            this.checkAmuse1.Name = "checkAmuse1";
            this.checkAmuse1.Size = new System.Drawing.Size(59, 16);
            this.checkAmuse1.TabIndex = 35;
            this.checkAmuse1.Text = "カラオケ";
            this.checkAmuse1.UseVisualStyleBackColor = true;
            // 
            // checkOffice5
            // 
            this.checkOffice5.AutoSize = true;
            this.checkOffice5.Location = new System.Drawing.Point(19, 383);
            this.checkOffice5.Name = "checkOffice5";
            this.checkOffice5.Size = new System.Drawing.Size(115, 16);
            this.checkOffice5.TabIndex = 34;
            this.checkOffice5.Text = "その他オフィスワーク";
            this.checkOffice5.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label23.Location = new System.Drawing.Point(369, 271);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(153, 12);
            this.label23.TabIndex = 33;
            this.label23.Text = "軽作業・清掃・警備・引越し";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label24.Location = new System.Drawing.Point(203, 271);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(82, 12);
            this.label24.TabIndex = 32;
            this.label24.Text = "アミューズメント";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label25.Location = new System.Drawing.Point(17, 271);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(105, 12);
            this.label25.TabIndex = 31;
            this.label25.Text = "オフィスワーク・事務";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label22.Location = new System.Drawing.Point(369, 20);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(79, 12);
            this.label22.TabIndex = 30;
            this.label22.Text = "接客・サービス";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label21.Location = new System.Drawing.Point(203, 20);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(68, 12);
            this.label21.TabIndex = 29;
            this.label21.Text = "飲食・フード";
            // 
            // checkService2
            // 
            this.checkService2.AutoSize = true;
            this.checkService2.Location = new System.Drawing.Point(371, 65);
            this.checkService2.Name = "checkService2";
            this.checkService2.Size = new System.Drawing.Size(83, 16);
            this.checkService2.TabIndex = 28;
            this.checkService2.Text = "ホテル・旅館";
            this.checkService2.UseVisualStyleBackColor = true;
            // 
            // checkService3
            // 
            this.checkService3.AutoSize = true;
            this.checkService3.Location = new System.Drawing.Point(371, 87);
            this.checkService3.Name = "checkService3";
            this.checkService3.Size = new System.Drawing.Size(135, 16);
            this.checkService3.TabIndex = 27;
            this.checkService3.Text = "ブライダル・他冠婚葬祭";
            this.checkService3.UseVisualStyleBackColor = true;
            // 
            // checkService4
            // 
            this.checkService4.AutoSize = true;
            this.checkService4.Location = new System.Drawing.Point(371, 108);
            this.checkService4.Name = "checkService4";
            this.checkService4.Size = new System.Drawing.Size(48, 16);
            this.checkService4.TabIndex = 26;
            this.checkService4.Text = "旅行";
            this.checkService4.UseVisualStyleBackColor = true;
            // 
            // checkService5
            // 
            this.checkService5.AutoSize = true;
            this.checkService5.Location = new System.Drawing.Point(371, 132);
            this.checkService5.Name = "checkService5";
            this.checkService5.Size = new System.Drawing.Size(94, 16);
            this.checkService5.TabIndex = 25;
            this.checkService5.Text = "ガソリンスタンド";
            this.checkService5.UseVisualStyleBackColor = true;
            // 
            // checkService6
            // 
            this.checkService6.AutoSize = true;
            this.checkService6.Location = new System.Drawing.Point(371, 154);
            this.checkService6.Name = "checkService6";
            this.checkService6.Size = new System.Drawing.Size(143, 16);
            this.checkService6.TabIndex = 24;
            this.checkService6.Text = "店長・マネージャー(接客)";
            this.checkService6.UseVisualStyleBackColor = true;
            // 
            // checkService7
            // 
            this.checkService7.AutoSize = true;
            this.checkService7.Location = new System.Drawing.Point(371, 176);
            this.checkService7.Name = "checkService7";
            this.checkService7.Size = new System.Drawing.Size(122, 16);
            this.checkService7.TabIndex = 23;
            this.checkService7.Text = "その他接客・サービス";
            this.checkService7.UseVisualStyleBackColor = true;
            // 
            // checkOffice1
            // 
            this.checkOffice1.AutoSize = true;
            this.checkOffice1.Location = new System.Drawing.Point(19, 292);
            this.checkOffice1.Name = "checkOffice1";
            this.checkOffice1.Size = new System.Drawing.Size(72, 16);
            this.checkOffice1.TabIndex = 22;
            this.checkOffice1.Text = "一般事務";
            this.checkOffice1.UseVisualStyleBackColor = true;
            // 
            // checkOffice2
            // 
            this.checkOffice2.AutoSize = true;
            this.checkOffice2.Location = new System.Drawing.Point(19, 316);
            this.checkOffice2.Name = "checkOffice2";
            this.checkOffice2.Size = new System.Drawing.Size(48, 16);
            this.checkOffice2.TabIndex = 21;
            this.checkOffice2.Text = "受付";
            this.checkOffice2.UseVisualStyleBackColor = true;
            // 
            // checkFood7
            // 
            this.checkFood7.AutoSize = true;
            this.checkFood7.Location = new System.Drawing.Point(205, 176);
            this.checkFood7.Name = "checkFood7";
            this.checkFood7.Size = new System.Drawing.Size(153, 16);
            this.checkFood7.TabIndex = 20;
            this.checkFood7.Text = "ケーキ・パン・スイーツ(調理)";
            this.checkFood7.UseVisualStyleBackColor = true;
            // 
            // checkFood8
            // 
            this.checkFood8.AutoSize = true;
            this.checkFood8.Location = new System.Drawing.Point(205, 198);
            this.checkFood8.Name = "checkFood8";
            this.checkFood8.Size = new System.Drawing.Size(68, 16);
            this.checkFood8.TabIndex = 19;
            this.checkFood8.Text = "デリバリー";
            this.checkFood8.UseVisualStyleBackColor = true;
            // 
            // checkFood9
            // 
            this.checkFood9.AutoSize = true;
            this.checkFood9.Location = new System.Drawing.Point(205, 218);
            this.checkFood9.Name = "checkFood9";
            this.checkFood9.Size = new System.Drawing.Size(143, 16);
            this.checkFood9.TabIndex = 18;
            this.checkFood9.Text = "店長・マネージャー(飲食)";
            this.checkFood9.UseVisualStyleBackColor = true;
            // 
            // checkFood10
            // 
            this.checkFood10.AutoSize = true;
            this.checkFood10.Location = new System.Drawing.Point(205, 240);
            this.checkFood10.Name = "checkFood10";
            this.checkFood10.Size = new System.Drawing.Size(112, 16);
            this.checkFood10.TabIndex = 17;
            this.checkFood10.Text = "その他飲食・フード";
            this.checkFood10.UseVisualStyleBackColor = true;
            // 
            // checkSell2
            // 
            this.checkSell2.AutoSize = true;
            this.checkSell2.Location = new System.Drawing.Point(19, 65);
            this.checkSell2.Name = "checkSell2";
            this.checkSell2.Size = new System.Drawing.Size(72, 16);
            this.checkSell2.TabIndex = 16;
            this.checkSell2.Text = "雑貨販売";
            this.checkSell2.UseVisualStyleBackColor = true;
            // 
            // checkSell3
            // 
            this.checkSell3.AutoSize = true;
            this.checkSell3.Location = new System.Drawing.Point(19, 87);
            this.checkSell3.Name = "checkSell3";
            this.checkSell3.Size = new System.Drawing.Size(149, 16);
            this.checkSell3.TabIndex = 15;
            this.checkSell3.Text = "ドラッグストア・化粧品販売";
            this.checkSell3.UseVisualStyleBackColor = true;
            // 
            // checkSell4
            // 
            this.checkSell4.AutoSize = true;
            this.checkSell4.Location = new System.Drawing.Point(19, 110);
            this.checkSell4.Name = "checkSell4";
            this.checkSell4.Size = new System.Drawing.Size(112, 16);
            this.checkSell4.TabIndex = 14;
            this.checkSell4.Text = "本・CD・DVD販売";
            this.checkSell4.UseVisualStyleBackColor = true;
            // 
            // checkSell5
            // 
            this.checkSell5.AutoSize = true;
            this.checkSell5.Location = new System.Drawing.Point(19, 132);
            this.checkSell5.Name = "checkSell5";
            this.checkSell5.Size = new System.Drawing.Size(63, 16);
            this.checkSell5.TabIndex = 13;
            this.checkSell5.Text = "スーバー";
            this.checkSell5.UseVisualStyleBackColor = true;
            // 
            // checkSell8
            // 
            this.checkSell8.AutoSize = true;
            this.checkSell8.Location = new System.Drawing.Point(19, 198);
            this.checkSell8.Name = "checkSell8";
            this.checkSell8.Size = new System.Drawing.Size(143, 16);
            this.checkSell8.TabIndex = 12;
            this.checkSell8.Text = "店長・マネージャー(販売)";
            this.checkSell8.UseVisualStyleBackColor = true;
            // 
            // checkSell9
            // 
            this.checkSell9.AutoSize = true;
            this.checkSell9.Location = new System.Drawing.Point(19, 220);
            this.checkSell9.Name = "checkSell9";
            this.checkSell9.Size = new System.Drawing.Size(87, 16);
            this.checkSell9.TabIndex = 11;
            this.checkSell9.Text = "その他、販売";
            this.checkSell9.UseVisualStyleBackColor = true;
            // 
            // checkFood1
            // 
            this.checkFood1.AutoSize = true;
            this.checkFood1.Location = new System.Drawing.Point(205, 41);
            this.checkFood1.Name = "checkFood1";
            this.checkFood1.Size = new System.Drawing.Size(48, 16);
            this.checkFood1.TabIndex = 10;
            this.checkFood1.Text = "カフェ";
            this.checkFood1.UseVisualStyleBackColor = true;
            // 
            // checkFood3
            // 
            this.checkFood3.AutoSize = true;
            this.checkFood3.Location = new System.Drawing.Point(205, 87);
            this.checkFood3.Name = "checkFood3";
            this.checkFood3.Size = new System.Drawing.Size(83, 16);
            this.checkFood3.TabIndex = 9;
            this.checkFood3.Text = "ファストフード";
            this.checkFood3.UseVisualStyleBackColor = true;
            // 
            // checkSell6
            // 
            this.checkSell6.AutoSize = true;
            this.checkSell6.Location = new System.Drawing.Point(19, 154);
            this.checkSell6.Name = "checkSell6";
            this.checkSell6.Size = new System.Drawing.Size(58, 16);
            this.checkSell6.TabIndex = 8;
            this.checkSell6.Text = "コンビニ";
            this.checkSell6.UseVisualStyleBackColor = true;
            // 
            // checkSell7
            // 
            this.checkSell7.AutoSize = true;
            this.checkSell7.Location = new System.Drawing.Point(19, 176);
            this.checkSell7.Name = "checkSell7";
            this.checkSell7.Size = new System.Drawing.Size(72, 16);
            this.checkSell7.TabIndex = 7;
            this.checkSell7.Text = "食品販売";
            this.checkSell7.UseVisualStyleBackColor = true;
            // 
            // checkService1
            // 
            this.checkService1.AutoSize = true;
            this.checkService1.Location = new System.Drawing.Point(371, 43);
            this.checkService1.Name = "checkService1";
            this.checkService1.Size = new System.Drawing.Size(112, 16);
            this.checkService1.TabIndex = 6;
            this.checkService1.Text = "フロント・受付窓口";
            this.checkService1.UseVisualStyleBackColor = true;
            // 
            // checkFood5
            // 
            this.checkFood5.AutoSize = true;
            this.checkFood5.Location = new System.Drawing.Point(205, 132);
            this.checkFood5.Name = "checkFood5";
            this.checkFood5.Size = new System.Drawing.Size(107, 16);
            this.checkFood5.TabIndex = 5;
            this.checkFood5.Text = "パーテンダー・バー";
            this.checkFood5.UseVisualStyleBackColor = true;
            // 
            // checkFood6
            // 
            this.checkFood6.AutoSize = true;
            this.checkFood6.Location = new System.Drawing.Point(205, 154);
            this.checkFood6.Name = "checkFood6";
            this.checkFood6.Size = new System.Drawing.Size(143, 16);
            this.checkFood6.TabIndex = 4;
            this.checkFood6.Text = "他飲食店ホール・キッチン";
            this.checkFood6.UseVisualStyleBackColor = true;
            // 
            // checkFood4
            // 
            this.checkFood4.AutoSize = true;
            this.checkFood4.Location = new System.Drawing.Point(205, 110);
            this.checkFood4.Name = "checkFood4";
            this.checkFood4.Size = new System.Drawing.Size(60, 16);
            this.checkFood4.TabIndex = 3;
            this.checkFood4.Text = "居酒屋";
            this.checkFood4.UseVisualStyleBackColor = true;
            // 
            // checkFood2
            // 
            this.checkFood2.AutoSize = true;
            this.checkFood2.Location = new System.Drawing.Point(205, 65);
            this.checkFood2.Name = "checkFood2";
            this.checkFood2.Size = new System.Drawing.Size(113, 16);
            this.checkFood2.TabIndex = 2;
            this.checkFood2.Text = "ファミレス・レストラン";
            this.checkFood2.UseVisualStyleBackColor = true;
            // 
            // checkSell1
            // 
            this.checkSell1.AutoSize = true;
            this.checkSell1.Location = new System.Drawing.Point(19, 43);
            this.checkSell1.Name = "checkSell1";
            this.checkSell1.Size = new System.Drawing.Size(102, 16);
            this.checkSell1.TabIndex = 1;
            this.checkSell1.Text = "家電・携帯販売";
            this.checkSell1.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label20.Location = new System.Drawing.Point(17, 20);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(31, 12);
            this.label20.TabIndex = 0;
            this.label20.Text = "販売";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LemonChiffon;
            this.panel2.Controls.Add(this.txtKeiMail);
            this.panel2.Controls.Add(this.txtKeiTel);
            this.panel2.Controls.Add(this.txtTel);
            this.panel2.Controls.Add(this.checkScout);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.txtBirthDay);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.comboTerm2);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.comboTodo);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.comboTerm1);
            this.panel2.Controls.Add(this.comboSex);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.comboShcool);
            this.panel2.Controls.Add(this.comboSts);
            this.panel2.Controls.Add(this.comboLan);
            this.panel2.Controls.Add(this.comboJpnLev);
            this.panel2.Controls.Add(this.comboNation);
            this.panel2.Controls.Add(this.txtAddr2);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.txtAddr1);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.txtJobCr2);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txtJobCr1);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.txtPostNo);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtNm);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtMail);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(4, 51);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(357, 623);
            this.panel2.TabIndex = 0;
            // 
            // txtKeiMail
            // 
            this.txtKeiMail.Location = new System.Drawing.Point(90, 501);
            this.txtKeiMail.Name = "txtKeiMail";
            this.txtKeiMail.Size = new System.Drawing.Size(135, 19);
            this.txtKeiMail.TabIndex = 41;
            // 
            // txtKeiTel
            // 
            this.txtKeiTel.Location = new System.Drawing.Point(90, 469);
            this.txtKeiTel.Name = "txtKeiTel";
            this.txtKeiTel.Size = new System.Drawing.Size(135, 19);
            this.txtKeiTel.TabIndex = 40;
            // 
            // txtTel
            // 
            this.txtTel.Location = new System.Drawing.Point(90, 438);
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(135, 19);
            this.txtTel.TabIndex = 39;
            // 
            // checkScout
            // 
            this.checkScout.AutoSize = true;
            this.checkScout.Location = new System.Drawing.Point(90, 566);
            this.checkScout.Name = "checkScout";
            this.checkScout.Size = new System.Drawing.Size(186, 16);
            this.checkScout.TabIndex = 38;
            this.checkScout.Text = "企業（店舗）カラのスカウトを受ける";
            this.checkScout.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(15, 566);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(57, 12);
            this.label19.TabIndex = 37;
            this.label19.Text = "メール受信";
            // 
            // txtBirthDay
            // 
            this.txtBirthDay.Location = new System.Drawing.Point(90, 529);
            this.txtBirthDay.Name = "txtBirthDay";
            this.txtBirthDay.Size = new System.Drawing.Size(100, 19);
            this.txtBirthDay.TabIndex = 35;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(196, 532);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 34;
            this.label17.Text = "性別";
            // 
            // comboTerm2
            // 
            this.comboTerm2.FormattingEnabled = true;
            this.comboTerm2.Location = new System.Drawing.Point(125, 326);
            this.comboTerm2.Name = "comboTerm2";
            this.comboTerm2.Size = new System.Drawing.Size(110, 20);
            this.comboTerm2.TabIndex = 33;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(15, 504);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 12);
            this.label16.TabIndex = 32;
            this.label16.Text = "携帯メール";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(15, 537);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 31;
            this.label15.Text = "生年月日";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 472);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 30;
            this.label14.Text = "携帯電話";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 445);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 29;
            this.label13.Text = "電話";
            // 
            // comboTodo
            // 
            this.comboTodo.FormattingEnabled = true;
            this.comboTodo.Location = new System.Drawing.Point(90, 381);
            this.comboTodo.Name = "comboTodo";
            this.comboTodo.Size = new System.Drawing.Size(100, 20);
            this.comboTodo.TabIndex = 28;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 381);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 27;
            this.label12.Text = "住所";
            // 
            // comboTerm1
            // 
            this.comboTerm1.FormattingEnabled = true;
            this.comboTerm1.Location = new System.Drawing.Point(125, 271);
            this.comboTerm1.Name = "comboTerm1";
            this.comboTerm1.Size = new System.Drawing.Size(110, 20);
            this.comboTerm1.TabIndex = 25;
            // 
            // comboSex
            // 
            this.comboSex.FormattingEnabled = true;
            this.comboSex.Location = new System.Drawing.Point(231, 529);
            this.comboSex.Name = "comboSex";
            this.comboSex.Size = new System.Drawing.Size(110, 20);
            this.comboSex.TabIndex = 26;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(88, 332);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 24;
            this.label11.Text = "期間";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(88, 277);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 23;
            this.label10.Text = "期間";
            // 
            // comboShcool
            // 
            this.comboShcool.FormattingEnabled = true;
            this.comboShcool.Location = new System.Drawing.Point(90, 211);
            this.comboShcool.Name = "comboShcool";
            this.comboShcool.Size = new System.Drawing.Size(145, 20);
            this.comboShcool.TabIndex = 22;
            // 
            // comboSts
            // 
            this.comboSts.FormattingEnabled = true;
            this.comboSts.Location = new System.Drawing.Point(90, 174);
            this.comboSts.Name = "comboSts";
            this.comboSts.Size = new System.Drawing.Size(145, 20);
            this.comboSts.TabIndex = 21;
            // 
            // comboLan
            // 
            this.comboLan.FormattingEnabled = true;
            this.comboLan.Location = new System.Drawing.Point(90, 104);
            this.comboLan.Name = "comboLan";
            this.comboLan.Size = new System.Drawing.Size(145, 20);
            this.comboLan.TabIndex = 20;
            // 
            // comboJpnLev
            // 
            this.comboJpnLev.FormattingEnabled = true;
            this.comboJpnLev.Location = new System.Drawing.Point(90, 138);
            this.comboJpnLev.Name = "comboJpnLev";
            this.comboJpnLev.Size = new System.Drawing.Size(145, 20);
            this.comboJpnLev.TabIndex = 19;
            // 
            // comboNation
            // 
            this.comboNation.FormattingEnabled = true;
            this.comboNation.Location = new System.Drawing.Point(90, 72);
            this.comboNation.Name = "comboNation";
            this.comboNation.Size = new System.Drawing.Size(145, 20);
            this.comboNation.TabIndex = 18;
            // 
            // txtAddr2
            // 
            this.txtAddr2.Location = new System.Drawing.Point(90, 407);
            this.txtAddr2.Name = "txtAddr2";
            this.txtAddr2.Size = new System.Drawing.Size(251, 19);
            this.txtAddr2.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 354);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 16;
            this.label9.Text = "郵便番号";
            // 
            // txtAddr1
            // 
            this.txtAddr1.Location = new System.Drawing.Point(198, 382);
            this.txtAddr1.Name = "txtAddr1";
            this.txtAddr1.Size = new System.Drawing.Size(143, 19);
            this.txtAddr1.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 249);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 14;
            this.label8.Text = "仕事経歴";
            // 
            // txtJobCr2
            // 
            this.txtJobCr2.Location = new System.Drawing.Point(90, 302);
            this.txtJobCr2.Name = "txtJobCr2";
            this.txtJobCr2.Size = new System.Drawing.Size(251, 19);
            this.txtJobCr2.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 219);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 12;
            this.label7.Text = "最終学歴";
            // 
            // txtJobCr1
            // 
            this.txtJobCr1.Location = new System.Drawing.Point(90, 246);
            this.txtJobCr1.Name = "txtJobCr1";
            this.txtJobCr1.Size = new System.Drawing.Size(251, 19);
            this.txtJobCr1.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 12);
            this.label6.TabIndex = 10;
            this.label6.Text = "現状の状態";
            // 
            // txtPostNo
            // 
            this.txtPostNo.Location = new System.Drawing.Point(90, 354);
            this.txtPostNo.Name = "txtPostNo";
            this.txtPostNo.Size = new System.Drawing.Size(100, 19);
            this.txtPostNo.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "日本語レベル";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 6;
            this.label4.Text = "母国語";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "国籍";
            // 
            // txtNm
            // 
            this.txtNm.Location = new System.Drawing.Point(90, 39);
            this.txtNm.Name = "txtNm";
            this.txtNm.Size = new System.Drawing.Size(145, 19);
            this.txtNm.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "名前";
            // 
            // txtMail
            // 
            this.txtMail.Location = new System.Drawing.Point(90, 10);
            this.txtMail.Name = "txtMail";
            this.txtMail.Size = new System.Drawing.Size(145, 19);
            this.txtMail.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "メール";
            // 
            // picBox
            // 
            this.picBox.Location = new System.Drawing.Point(13, 15);
            this.picBox.Name = "picBox";
            this.picBox.Size = new System.Drawing.Size(188, 132);
            this.picBox.TabIndex = 49;
            this.picBox.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.LemonChiffon;
            this.groupBox5.Controls.Add(this.picBox);
            this.groupBox5.Location = new System.Drawing.Point(924, 295);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(211, 153);
            this.groupBox5.TabIndex = 63;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "写真";
            // 
            // frmStaffDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LemonChiffon;
            this.ClientSize = new System.Drawing.Size(1162, 701);
            this.Controls.Add(this.panel1);
            this.Name = "frmStaffDetail";
            this.Text = "スタッフ詳細";
            this.Load += new System.EventHandler(this.staffDetail_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtAddr2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAddr1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtJobCr2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtJobCr1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtPostNo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMail;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboShcool;
        private System.Windows.Forms.ComboBox comboSts;
        private System.Windows.Forms.ComboBox comboLan;
        private System.Windows.Forms.ComboBox comboJpnLev;
        private System.Windows.Forms.ComboBox comboNation;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboTerm2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboTodo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboTerm1;
        private System.Windows.Forms.ComboBox comboSex;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtBirthDay;
        private System.Windows.Forms.CheckBox checkSell2;
        private System.Windows.Forms.CheckBox checkSell3;
        private System.Windows.Forms.CheckBox checkSell4;
        private System.Windows.Forms.CheckBox checkSell5;
        private System.Windows.Forms.CheckBox checkSell8;
        private System.Windows.Forms.CheckBox checkSell9;
        private System.Windows.Forms.CheckBox checkFood1;
        private System.Windows.Forms.CheckBox checkFood3;
        private System.Windows.Forms.CheckBox checkSell6;
        private System.Windows.Forms.CheckBox checkSell7;
        private System.Windows.Forms.CheckBox checkService1;
        private System.Windows.Forms.CheckBox checkFood5;
        private System.Windows.Forms.CheckBox checkFood6;
        private System.Windows.Forms.CheckBox checkFood4;
        private System.Windows.Forms.CheckBox checkFood2;
        private System.Windows.Forms.CheckBox checkSell1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox checkScout;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox checkFood7;
        private System.Windows.Forms.CheckBox checkFood8;
        private System.Windows.Forms.CheckBox checkFood9;
        private System.Windows.Forms.CheckBox checkFood10;
        private System.Windows.Forms.CheckBox checkService2;
        private System.Windows.Forms.CheckBox checkService3;
        private System.Windows.Forms.CheckBox checkService4;
        private System.Windows.Forms.CheckBox checkService5;
        private System.Windows.Forms.CheckBox checkService6;
        private System.Windows.Forms.CheckBox checkService7;
        private System.Windows.Forms.CheckBox checkOffice1;
        private System.Windows.Forms.CheckBox checkOffice2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox checkOffice3;
        private System.Windows.Forms.CheckBox checkOffice4;
        private System.Windows.Forms.CheckBox checkSinya;
        private System.Windows.Forms.CheckBox checkMedical;
        private System.Windows.Forms.CheckBox checkRest;
        private System.Windows.Forms.CheckBox checkAtHome;
        private System.Windows.Forms.CheckBox checkIt2;
        private System.Windows.Forms.CheckBox checkIt3;
        private System.Windows.Forms.CheckBox checkLan2;
        private System.Windows.Forms.CheckBox checkEvent;
        private System.Windows.Forms.CheckBox checkFacion;
        private System.Windows.Forms.CheckBox checkBeauty;
        private System.Windows.Forms.CheckBox checkWeek1;
        private System.Windows.Forms.CheckBox checkLan1;
        private System.Windows.Forms.CheckBox checkAsagata;
        private System.Windows.Forms.CheckBox checkWeekDay;
        private System.Windows.Forms.CheckBox checkYugata;
        private System.Windows.Forms.CheckBox checkAsa;
        private System.Windows.Forms.CheckBox checkHiru;
        private System.Windows.Forms.CheckBox checkTanki;
        private System.Windows.Forms.CheckBox checkWeekEnd;
        private System.Windows.Forms.CheckBox checkSheeft;
        private System.Windows.Forms.CheckBox checkIt1;
        private System.Windows.Forms.CheckBox checkAmuse4;
        private System.Windows.Forms.CheckBox checkAmuse5;
        private System.Windows.Forms.CheckBox checkAmuse3;
        private System.Windows.Forms.CheckBox checkConsul;
        private System.Windows.Forms.CheckBox checkAffare5;
        private System.Windows.Forms.CheckBox checkAffare3;
        private System.Windows.Forms.CheckBox checkAffare4;
        private System.Windows.Forms.CheckBox checkAffare2;
        private System.Windows.Forms.CheckBox checkAffare1;
        private System.Windows.Forms.CheckBox checkAmuse1;
        private System.Windows.Forms.CheckBox checkOffice5;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.CheckBox checkAmuse2;
        private System.Windows.Forms.CheckBox checkWeek3;
        private System.Windows.Forms.CheckBox checkWeek2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtKeiMail;
        private System.Windows.Forms.TextBox txtKeiTel;
        private System.Windows.Forms.TextBox txtTel;
        private System.Windows.Forms.PictureBox picBox;
        private System.Windows.Forms.GroupBox groupBox5;
    }
}