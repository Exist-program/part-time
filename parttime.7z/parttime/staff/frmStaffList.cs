﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using parttime.common;
using System.Collections;

namespace parttime.staff
{
    public partial class frmStaffList : Form
    {
        public frmStaffList()
        {
            InitializeComponent();
        }

        private void frmStaffList_Load(object sender, EventArgs e)
        {
            Common.setComboBox(2, comboNation);
            Common.setComboBox(3, comboLan);
            Common.setComboBox(4, comboTodo);
            setYmd();
            setPage();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            setPage();
        }

        private void btnUdp_Click(object sender, EventArgs e)
        {

            int total = 0;

            for (int i = 0; i < axfpSpread1.MaxRows; i++)
            {
                Common.setFildSpread(axfpSpread1, 14, i);
                if(axfpSpread1.Text == "1") {

                    total++;
                }
            }

            if(total > 0) {

                for (int i = 0; i<axfpSpread1.MaxRows;i++ )
                {
                    Common.setFildSpread(axfpSpread1, 14, i);
                    if (axfpSpread1.Text == "1")
                    {

                        Common.setFildSpread(axfpSpread1, 1, i);

                        staffStop(axfpSpread1.Text);
                    }
                }

            } else {
                
                MessageBox.Show("チェックボークスを選択してください。");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            frmClear();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            frmClose();
        }

        private void btnCalender1_Click(object sender, EventArgs e)
        {
            Common.gb_CalenderKB = "cal01";

            if (monthCalendar1.Visible == false)
            {
                monthCalendar1.Visible = true;
            }
            else
            {
                monthCalendar1.Visible = false;
            }
        }

        private void btnCalender2_Click(object sender, EventArgs e)
        {
            Common.gb_CalenderKB = "cal02";

            if (monthCalendar1.Visible == false)
            {
                monthCalendar1.Visible = true;
            }
            else
            {
                monthCalendar1.Visible = false;
            }
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            if (Common.gb_CalenderKB.Equals("cal01"))
            {
                txtRegYmd1.Text = e.End.ToShortDateString();
                txtRegYmd1.Focus();
            }
            else if (Common.gb_CalenderKB.Equals("cal02"))
            {
                txtRegYmd2.Text = e.End.ToShortDateString();
                txtRegYmd2.Focus();
            }

            Common.gb_CalenderKB = string.Empty;
            monthCalendar1.Visible = false;
        }

        private void axfpSpread1_ClickEvent(object sender, AxFPUSpreadADO._DSpreadEvents_ClickEvent e)
        {
            for (int j = 0; j <= axfpSpread1.MaxRows; j++)
            {
                Common.setFildSpread(axfpSpread1, 4, j);
                if (axfpSpread1.BackColor == Color.Lavender)
                {
                    for (int k = 1; k <= axfpSpread1.MaxCols; k++)
                    {
                        Common.setFildSpread(axfpSpread1, k , j);
                        axfpSpread1.BackColor = Color.White;
                    }
                }
            }

            for (int i = 1; i <= axfpSpread1.MaxCols-1; i++)
            {
                Common.setFildSpread(axfpSpread1, i, e.row);
                axfpSpread1.BackColor = Color.Lavender;
            }
        }

        private void axfpSpread1_DblClick(object sender, AxFPUSpreadADO._DSpreadEvents_DblClickEvent e)
        {
            if (e.col == 1)
            {
                Common.setFildSpread(axfpSpread1, 1, e.row);

                CodeMaster.STAFFNO = Convert.ToString(axfpSpread1.Text);

                Form form = new frmStaffDetail();
                Common.closeForm(form);
                Common.AddForm(form);
                form.MdiParent = frmMain.ActiveForm;
                form.WindowState = FormWindowState.Maximized;
                form.Show();
            }
        }

        private void setYmd() {

            string ymd = DateTime.Now.ToString();

            txtRegYmd2.Text = Common.getDateType(ymd);

            string[] temp = txtRegYmd2.Text.ToString().Split('/');

            temp[0] = Convert.ToString(Convert.ToInt32(temp[0]) - 1);

            temp[2] = Convert.ToString(Convert.ToInt32(temp[2]) + 1);

            ymd = 
                new StringBuilder().Append(temp[0]).Append("/")
                                   .Append(temp[1]).Append("/")
                                   .Append(temp[2]).ToString();

            txtRegYmd1.Text = ymd;
        }

        private void frmClear() {

            comboNation.SelectedValue = NationList.codeKuniE000;
            comboLan.SelectedValue = Mothertongue.codeLangE000;
            comboTodo.SelectedValue = TodoList.codeTodo00;
            txtRegYmd1.Text = string.Empty;
            txtRegYmd2.Text = string.Empty;
        }

        private void setPage()
        {
            Common.setClrSpread(axfpSpread1);
            setSpread();
        }

        private void setSpread() {

            StringBuilder sql = new StringBuilder();

            ArrayList colList = new ArrayList();
            ArrayList valList = new ArrayList();

            sql.Append(Sql.SEL_04_START);

            string termS = null;
            string termE = null;

            if (txtRegYmd1.Text.ToString().Length == 0)
            {

                termS = "2010-01-01";
            }
            else
            {

                termS = txtRegYmd1.Text.ToString().Trim();
            }

            colList.Add("@REGYMDSTR");
            valList.Add(termS);

            if (txtRegYmd2.Text.ToString().Length == 0)
            {

                termE = "2099-12-31";
            }
            else
            {

                termE = txtRegYmd2.Text.ToString().Trim();
            }

            colList.Add("@REGYMDEND");
            valList.Add(termE);

            if(comboNation.SelectedValue != NationList.codeKuniE000) {
                
                colList.Add("@staff_nation");
                valList.Add(comboNation.SelectedValue);
                sql.Append(Sql.SEL_04_CON1);
            } 

            if(comboLan.SelectedValue != Mothertongue.codeLangE000) {
            
                colList.Add("@staff_native_lan");
                valList.Add(comboLan.SelectedValue);
                sql.Append(Sql.SEL_04_CON2);
            }

            if(comboTodo.SelectedValue != TodoList.codeTodo00) {
            
                colList.Add("@staff_todo");
                valList.Add(comboTodo.SelectedValue);
                sql.Append(Sql.SEL_04_CON3);
            }

            sql.Append(Sql.SEL_04_END);

            DataSet ds = DbCon.selectInfo(colList, valList, sql.ToString());

            if (ds.Tables[0].Rows.Count > 0)
            {
                axfpSpread1.MaxRows = ds.Tables[0].Rows.Count;

                for (int i = 0; i < axfpSpread1.MaxRows; i++)
                {
                    // スタッフ
                    axfpSpread1.SetText(1, i + 1, ds.Tables[0].Rows[i]["staff_no"].ToString());

                    axfpSpread1.SetText(2, i + 1, MappingLists.nationListMapping(ds.Tables[0].Rows[i]["staff_nation"].ToString()));

                    axfpSpread1.SetText(3, i + 1, MappingLists.nativeListMapping(ds.Tables[0].Rows[i]["staff_native_lan"].ToString()));

                    axfpSpread1.SetText(4, i + 1, ds.Tables[0].Rows[i]["staff_name"].ToString());
                    axfpSpread1.SetText(5, i + 1, ds.Tables[0].Rows[i]["staff_tel"].ToString());

                    axfpSpread1.SetText(6, i + 1, ds.Tables[0].Rows[i]["staff_keitai_tel"].ToString());

                    axfpSpread1.SetText(7, i + 1, MappingLists.todoListMapping(ds.Tables[0].Rows[i]["staff_todo"].ToString())+ds.Tables[0].Rows[i]["staff_addr1"].ToString()+ds.Tables[0].Rows[i]["staff_addr2"].ToString());

                    axfpSpread1.SetText(8, i + 1, getSyuryoCnt(ds.Tables[0].Rows[i]["staff_no"].ToString()));

                    axfpSpread1.SetText(9, i + 1, getOuboCnt(ds.Tables[0].Rows[i]["staff_no"].ToString()));

                    axfpSpread1.SetText(10, i + 1, Common.getDateType(ds.Tables[0].Rows[i]["STAFF_REGISTER_YMD"].ToString()));

                    axfpSpread1.SetText(11, i + 1,  Common.getDateType(ds.Tables[0].Rows[i]["STAFF_LAST_CON_YMD"].ToString()));
                    axfpSpread1.SetText(12, i + 1, ds.Tables[0].Rows[i]["staff_id"].ToString());
                    axfpSpread1.SetText(13, i + 1, ds.Tables[0].Rows[i]["staff_keitai_mail"].ToString());

                }

                lbCnt.Text = Convert.ToString(ds.Tables[0].Rows.Count)+"件";

            }
            else
            {

                lbCnt.Text = "該当なし";
                axfpSpread1.MaxRows = 0;
            }
        }

        private string getSyuryoCnt(string staffno) {

            ArrayList colList = new ArrayList();
            ArrayList valList = new ArrayList();

            colList.Add("@staff_no");
            valList.Add(staffno);

            DataSet ds = DbCon.selectInfo(colList, valList, Sql.SEL_05);

            return ds.Tables[0].Rows[0][0].ToString();

        }

        private string getOuboCnt(string staffno)
        {

            ArrayList colList = new ArrayList();
            ArrayList valList = new ArrayList();

            colList.Add("@staff_no");
            valList.Add(staffno);

            DataSet ds = DbCon.selectInfo(colList, valList, Sql.SEL_06);

            return ds.Tables[0].Rows[0][0].ToString();
        }

        private void frmClose()
        {

            frmStaffList_FormClosing(null, null);
            this.Close();
        }

        private void frmStaffList_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmMain pForm = (frmMain)this.MdiParent;
            CodeMaster.FormArray.Remove(this);
        }

        private void staffStop(string staffNo)
        {

            ArrayList colList = new ArrayList();
            ArrayList valList = new ArrayList();

            string sql = "update staff_info set STAFF_STOP = 's' where staff_no = @staff_no";

            colList.Add("@staff_no");
            valList.Add(staffNo);

            string ret = DbCon.updateInfo(colList, valList, sql);

            if (CodeMaster.OK.Equals(ret))
            {

                MessageBox.Show("機能停止されました。");
            }
        }

    }
}