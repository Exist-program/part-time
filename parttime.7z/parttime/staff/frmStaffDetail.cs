﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using parttime.common;
using System.Collections;
using System.Net;
using System.IO;
using System.Web;

namespace parttime.staff
{
    public partial class frmStaffDetail : Form
    {
        public frmStaffDetail()
        {
            InitializeComponent();
        }

        private void staffDetail_Load(object sender, EventArgs e)
        {

            setPage();
        }

        private void setPage() {

            Common.setComboBox(2, comboNation);
            Common.setComboBox(3, comboLan);
            Common.setComboBox(4, comboTodo);
            Common.setComboBox(5, comboSts);
            Common.setComboBox(6, comboShcool);
            Common.setComboBox(7, comboJpnLev);
            Common.setComboBox(8, comboTerm1);
            Common.setComboBox(8, comboTerm2);
            Common.setComboBox(9, comboSex);
            
            getStaffInfo();
        }

        private void getStaffInfo() {

            ArrayList colList = new ArrayList();
            ArrayList valList = new ArrayList();

            colList.Add("@staff_no");
            valList.Add(CodeMaster.STAFFNO);

            DataSet ds = DbCon.selectInfo(colList, valList, Sql.SEL_07);

            if(ds.Tables[0].Rows.Count > 0) {

                txtMail.Text = ds.Tables[0].Rows[0]["staff_id"].ToString();
                txtNm.Text = ds.Tables[0].Rows[0]["staff_name"].ToString();
                comboNation.SelectedValue = ds.Tables[0].Rows[0]["staff_nation"].ToString();
                comboLan.SelectedValue = ds.Tables[0].Rows[0]["staff_native_lan"].ToString();
                comboJpnLev.SelectedValue = ds.Tables[0].Rows[0]["staff_jpn_lan_lev"].ToString();
                comboSts.SelectedValue = ds.Tables[0].Rows[0]["staff_sts"].ToString();
                comboShcool.SelectedValue = ds.Tables[0].Rows[0]["staff_schooling"].ToString();
                txtJobCr1.Text = ds.Tables[0].Rows[0]["staff_job_content1"].ToString();
                txtJobCr2.Text = ds.Tables[0].Rows[0]["staff_job_content2"].ToString();
                comboTerm1.SelectedValue = ds.Tables[0].Rows[0]["staff_job_term1"].ToString();
                comboTerm2.SelectedValue = ds.Tables[0].Rows[0]["staff_job_term2"].ToString();
                txtPostNo.Text = 
                    new StringBuilder().Append(ds.Tables[0].Rows[0]["staff_post_no1"].ToString()).                                                       Append("-").
                                        Append(ds.Tables[0].Rows[0]["staff_post_no2"].ToString()).ToString();
                
                comboTodo.SelectedValue = ds.Tables[0].Rows[0]["staff_todo"].ToString();
                txtAddr1.Text = ds.Tables[0].Rows[0]["staff_addr1"].ToString();
                txtAddr2.Text = ds.Tables[0].Rows[0]["staff_addr2"].ToString();
                txtTel.Text = ds.Tables[0].Rows[0]["staff_tel"].ToString();
                txtKeiTel.Text = ds.Tables[0].Rows[0]["staff_keitai_tel"].ToString();
                txtKeiMail.Text = ds.Tables[0].Rows[0]["staff_keitai_mail"].ToString();
                txtBirthDay.Text = Common.getDateType(ds.Tables[0].Rows[0]["STAFF_BIRDAY"].ToString());
                comboSex.SelectedValue = ds.Tables[0].Rows[0]["staff_sex"].ToString();
                string picture = ds.Tables[0].Rows[0]["STAFF_PHO"].ToString();

                if (picture != null && picture != string.Empty)
                {
                    WebClient wc = new WebClient();

                    string url = "http://www.parttime-jp.info/" + picture.Substring(picture.IndexOf("img"));

                    Stream stream = wc.OpenRead(url);

                    Image image = Image.FromStream(stream);

                    picBox.Image = image;
                }
                else
                {

                    picBox.Image = null;
                }

                checkScout.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_is_scout"].ToString());

                // -----------------------------------------------------

                checkSell1.Checked = Common.getChkBox( ds.Tables[0].Rows[0]["JOB_SELL_1"].ToString());
                checkSell2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_2"].ToString());
                checkSell3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_3"].ToString());
                checkSell4.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_4"].ToString());
                checkSell5.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_5"].ToString());
                checkSell6.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_6"].ToString());
                checkSell7.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_7"].ToString());
                checkSell8.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_8"].ToString());
                checkSell9.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_9"].ToString());

                checkFood1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_1"].ToString());
                checkFood2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_2"].ToString());
                checkFood3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_3"].ToString());
                checkFood4.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_4"].ToString());
                checkFood5.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_5"].ToString());
                checkFood6.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_6"].ToString());
                checkFood7.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_7"].ToString());
                checkFood8.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_8"].ToString());
                checkFood9.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_9"].ToString());
                checkFood10.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_10"].ToString());

                checkService1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_1"].ToString());
                checkService2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_2"].ToString());
                checkService3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_3"].ToString());
                checkService4.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_4"].ToString());
                checkService5.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_5"].ToString());
                checkService6.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_6"].ToString());
                checkService7.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_7"].ToString());

                checkOffice1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_OFFICE_1"].ToString());
                checkOffice2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_OFFICE_2"].ToString());
                checkOffice3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_OFFICE_3"].ToString());
                checkOffice4.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_OFFICE_4"].ToString());
                checkOffice5.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_OFFICE_5"].ToString());

                checkAmuse1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AMUSE_1"].ToString());
                checkAmuse2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AMUSE_2"].ToString());
                checkAmuse3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AMUSE_3"].ToString());
                checkAmuse4.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AMUSE_4"].ToString());
                checkAmuse5.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AMUSE_5"].ToString());

                checkAffare1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AFFAIRS_1"].ToString());
                checkAffare2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AFFAIRS_2"].ToString());
                checkAffare3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AFFAIRS_3"].ToString());
                checkAffare4.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AFFAIRS_4"].ToString());
                checkAffare5.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AFFAIRS_5"].ToString());

                checkIt1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_IT_1"].ToString());
                checkIt2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_IT_2"].ToString());
                checkIt3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_IT_3"].ToString());

                checkLan1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_LANGUAGE_1"].ToString());
                checkLan2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_LANGUAGE_2"].ToString());

                checkEvent.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_EVENT_1"].ToString());

                checkFacion.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FASION_1"].ToString());

                checkBeauty.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_BEAUTY_1"].ToString());

                checkMedical.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_MEDICAL_1"].ToString());

                checkRest.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_REST_1"].ToString());

                // -----------------------------------------------------

                checkAsagata.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_time1"].ToString());
                checkAsa.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_time2"].ToString());
                checkHiru.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_time3"].ToString());
                checkYugata.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_time4"].ToString());
                checkSinya.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_time5"].ToString());
                checkWeek1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_time6"].ToString());
                checkWeek2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_time7"].ToString());
                checkWeek3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_time8"].ToString());

                checkSheeft.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_condition1"].ToString());
                checkWeekDay.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_condition2"].ToString());
                checkWeekEnd.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_condition3"].ToString());
                checkTanki.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_condition4"].ToString());
                checkConsul.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_condition5"].ToString());
                checkAtHome.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["staff_condition6"].ToString());

            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            frmClose();
        }

        private void frmClose()
        {

            frmStaffDetail_FormClosing(null, null);
            this.Close();
        }

        private void frmStaffDetail_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmMain pForm = (frmMain)this.MdiParent;
            CodeMaster.FormArray.Remove(this);
        }

    }
}