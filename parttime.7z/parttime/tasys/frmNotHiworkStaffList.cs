﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using parttime.common;
using System.Collections;

namespace parttime.tasys
{
    public partial class frmNotHiworkStaffList : Form
    {
        public frmNotHiworkStaffList()
        {
            InitializeComponent();
        }

        private void frmNotHiworkStaffList_Load(object sender, EventArgs e)
        {
            chkMiToroku.Checked = true;
            setYmd();
            setPage();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            setPage();
        }

        private void btnMail_Click(object sender, EventArgs e)
        {
            int total = 0;
            bool chk = true;

            for (int i = 0; i < axfpSpread1.MaxRows; i++)
            {
                Common.setFildSpread(axfpSpread1, 1, i);
                if (axfpSpread1.Text == "1")
                {

                    total++;
                }
            }

            if (total > 300)
            {

                MessageBox.Show("BizMailで送信して下さい。");
                chk = false;

                for (int i = 0; i < axfpSpread1.MaxRows; i++)
                {
                    Common.setFildSpread(axfpSpread1, 1, i);
                    if (axfpSpread1.Text == "1")
                    {
                        Common.setFildSpread(axfpSpread1, 2, i);

                        string num = axfpSpread1.Text;

                        Common.updSendMail(2, num, DateTime.Now.ToString(), MailConst.Title_Staff);
                    }
                }
            }

            if (chk)
            {

                if (total > 0)
                {
                    CodeMaster.staffMailList = new ArrayList();

                    for (int i = 0; i < axfpSpread1.MaxRows; i++)
                    {
                        Common.setFildSpread(axfpSpread1, 1, i);
                        if (axfpSpread1.Text == "1")
                        {

                            StringBuilder sb = new StringBuilder();

                            // スタッフNo
                            Common.setFildSpread(axfpSpread1, 2, i);
                            sb.Append(axfpSpread1.Text).Append(",");

                            // スタッフID
                            Common.setFildSpread(axfpSpread1, 3, i);
                            sb.Append(axfpSpread1.Text).Append(",");

                            // スタッフ名
                            Common.setFildSpread(axfpSpread1, 4, i);
                            sb.Append(axfpSpread1.Text);

                            CodeMaster.staffMailList.Add(sb.ToString());
                        }
                    }

                    Form form = new mail.frmStaffMail();
                    Common.closeForm(form);
                    Common.AddForm(form);
                    form.MdiParent = frmMain.ActiveForm;
                    form.WindowState = FormWindowState.Maximized;
                    form.Show();

                }
                else
                {

                    MessageBox.Show("チェックボークスを選択してください。");
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            frmClear();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            frmClose();
        }

        private void btnCalender1_Click(object sender, EventArgs e)
        {
            Common.gb_CalenderKB = "cal01HS";

            if (monthCalendar1.Visible == false)
            {
                monthCalendar1.Visible = true;
            }
            else
            {
                monthCalendar1.Visible = false;
            }
        }

        private void btnCalender2_Click(object sender, EventArgs e)
        {
            Common.gb_CalenderKB = "cal02HS";

            if (monthCalendar1.Visible == false)
            {
                monthCalendar1.Visible = true;
            }
            else
            {
                monthCalendar1.Visible = false;
            }
        }

        private void btnCalender3_Click(object sender, EventArgs e)
        {
            Common.gb_CalenderKB = "cal03HS";

            if (monthCalendar1.Visible == false)
            {
                monthCalendar1.Visible = true;
            }
            else
            {
                monthCalendar1.Visible = false;
            }
        }

        private void btnCalender4_Click(object sender, EventArgs e)
        {
            Common.gb_CalenderKB = "cal04HS";

            if (monthCalendar1.Visible == false)
            {
                monthCalendar1.Visible = true;
            }
            else
            {
                monthCalendar1.Visible = false;
            }
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            if (Common.gb_CalenderKB.Equals("cal01HS"))
            {
                txtRegYmd1.Text = e.End.ToShortDateString();
                txtRegYmd1.Focus();
            }
            else if (Common.gb_CalenderKB.Equals("cal02HS"))
            {
                txtRegYmd2.Text = e.End.ToShortDateString();
                txtRegYmd2.Focus();
            }

            else if (Common.gb_CalenderKB.Equals("cal03HS"))
            {
                txtRegYmd3.Text = e.End.ToShortDateString();
                txtRegYmd3.Focus();
            }

            else if (Common.gb_CalenderKB.Equals("cal04HS"))
            {
                txtRegYmd4.Text = e.End.ToShortDateString();
                txtRegYmd4.Focus();
            }

            Common.gb_CalenderKB = string.Empty;
            monthCalendar1.Visible = false;
        }

        private void axfpSpread1_ClickEvent(object sender, AxFPUSpreadADO._DSpreadEvents_ClickEvent e)
        {
            for (int j = 0; j <= axfpSpread1.MaxRows; j++)
            {
                Common.setFildSpread(axfpSpread1, 4, j);
                if (axfpSpread1.BackColor == Color.Lavender)
                {
                    for (int k = 1; k <= axfpSpread1.MaxCols; k++)
                    {
                        Common.setFildSpread(axfpSpread1, k, j);
                        axfpSpread1.BackColor = Color.White;
                    }
                }
            }

            for (int i = 1; i <= axfpSpread1.MaxCols; i++)
            {
                Common.setFildSpread(axfpSpread1, i + 1, e.row);
                axfpSpread1.BackColor = Color.Lavender;
            }
        }

        private void axfpSpread1_DblClick(object sender, AxFPUSpreadADO._DSpreadEvents_DblClickEvent e)
        {
            if (e.col == 2)
            {
                Common.setFildSpread(axfpSpread1, 2, e.row);

                CodeMaster.STAFFNO = Convert.ToString(axfpSpread1.Text);

                Form form = new company.frmCompanyDetail();
                Common.closeForm(form);
                Common.AddForm(form);
                form.MdiParent = frmMain.ActiveForm;
                form.WindowState = FormWindowState.Maximized;
                form.Show();
            }
        }

        private void setYmd()
        {

            string ymd = DateTime.Now.ToString();

            txtRegYmd2.Text = Common.getDateType(ymd);

            string[] temp = txtRegYmd2.Text.ToString().Split('/');

            temp[0] = Convert.ToString(Convert.ToInt32(temp[0]) - 1);

            temp[2] = Convert.ToString(Convert.ToInt32(temp[2]) + 1);

            ymd =
                new StringBuilder().Append(temp[0]).Append("/")
                                   .Append(temp[1]).Append("/")
                                   .Append(temp[2]).ToString();

            txtRegYmd1.Text = ymd;
        }

        private void setPage()
        {
            Common.setClrSpread(axfpSpread1);
            setSpread();
        }

        private void setSpread()
        {
            
            ArrayList colList = new ArrayList();
            ArrayList valList = new ArrayList();

            string term = null;

            if (txtRegYmd1.Text.ToString().Length == 0)
            {

                term = "2010-01-01";
            }
            else
            {

                term = txtRegYmd1.Text.ToString().Trim();
            }

            colList.Add("@REGYMDSTR");
            valList.Add(term);

            if (txtRegYmd2.Text.ToString().Length == 0)
            {

                term = "2099-12-31";
            }
            else
            {

                term = txtRegYmd2.Text.ToString().Trim();
            }

            colList.Add("@REGYMDEND");
            valList.Add(term);

            if (txtRegYmd3.Text.ToString().Length == 0)
            {

                term = "2010-01-01";
            }
            else
            {

                term = txtRegYmd1.Text.ToString().Trim();
            }

            colList.Add("@REGYMDSTR2");
            valList.Add(term);

            if (txtRegYmd4.Text.ToString().Length == 0)
            {

                term = "2099-12-31";
            }
            else
            {

                term = txtRegYmd2.Text.ToString().Trim();
            }

            colList.Add("@REGYMDEND2");
            valList.Add(term);

            string sql = null;

            if (chkDisAll.Checked)
            {

                sql = Sql.SEL_18;
            }
            else
            {

                sql = Sql.SEL_18_1;
            }

            DataSet ds = DbCon.selectInfo(colList, valList, sql);

            DataSet ds2 = null;

            if (ds.Tables[0].Rows.Count > 0)
            {

                ArrayList notExistList = new ArrayList();

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    colList.Clear();
                    colList.Add("@STAFFID");
                    valList.Clear();
                    valList.Add(ds.Tables[0].Rows[i]["STAFF_ID"].ToString());

                    ds2 = DbCon.selectInfo2(colList, valList, Sql.SEL_19);

                    if(chkMiToroku.Checked) {
                    
                        if (ds2.Tables[0].Rows[0][0].ToString().Equals("0"))
                        {

                            colList.Clear();
                            valList.Clear();

                            colList.Add("@STAFFID");
                            valList.Add(ds.Tables[0].Rows[i]["STAFF_ID"].ToString());

                            DataSet ds3 = DbCon.selectInfo(colList, valList, Sql.SEL_20);

                            notExistList.Add(ds3);
                        }

                    } else if(chkToroku.Checked) {
                        
                        if (!ds2.Tables[0].Rows[0][0].ToString().Equals("0"))
                        {

                            colList.Clear();
                            valList.Clear();

                            colList.Add("@STAFFID");
                            valList.Add(ds.Tables[0].Rows[i]["STAFF_ID"].ToString());

                            DataSet ds3 = DbCon.selectInfo(colList, valList, Sql.SEL_20);

                            notExistList.Add(ds3);
                        }

                    } else if(chkAll.Checked) {
                    
                            colList.Clear();
                            valList.Clear();

                            colList.Add("@STAFFID");
                            valList.Add(ds.Tables[0].Rows[i]["STAFF_ID"].ToString());

                            DataSet ds3 = DbCon.selectInfo(colList, valList, Sql.SEL_20);

                            notExistList.Add(ds3);
                    }

                }

                if (notExistList.Count > 0)
                {

                    axfpSpread1.MaxRows = notExistList.Count;

                    for (int i = 0; i < notExistList.Count; i++)
                    {

                        DataSet result = (DataSet)notExistList[i];

                        axfpSpread1.SetText(2, i + 1, result.Tables[0].Rows[0]["STAFF_NO"].ToString());

                        axfpSpread1.SetText(3, i + 1, result.Tables[0].Rows[0]["STAFF_ID"].ToString());

                        axfpSpread1.SetText(4, i + 1, result.Tables[0].Rows[0]["STAFF_NAME"].ToString());

                        axfpSpread1.SetText(5, i + 1, MappingLists.nationListMapping(result.Tables[0].Rows[0]["staff_nation"].ToString()));

                        axfpSpread1.SetText(6, i + 1, MappingLists.nativeListMapping(result.Tables[0].Rows[0]["staff_native_lan"].ToString()));

                        axfpSpread1.SetText(7, i + 1, result.Tables[0].Rows[0]["staff_tel"].ToString());

                        axfpSpread1.SetText(8, i + 1, result.Tables[0].Rows[0]["staff_keitai_tel"].ToString());

                        axfpSpread1.SetText(9, i + 1, MappingLists.todoListMapping(result.Tables[0].Rows[0]["staff_todo"].ToString())+result.Tables[0].Rows[0]["staff_addr1"].ToString()+result.Tables[0].Rows[0]["staff_addr2"].ToString());

                        axfpSpread1.SetText(10, i + 1, Common.getDateType(result.Tables[0].Rows[0]["STAFF_REGISTER_YMD"].ToString()));
                         
                        axfpSpread1.SetText(11, i + 1, Common.getDateType(result.Tables[0].Rows[0]["STAFF_LAST_CON_YMD"].ToString()));
                         axfpSpread1.SetText(12, i + 1, result.Tables[0].Rows[0]["staff_keitai_tel"].ToString());
                         axfpSpread1.SetText(13, i + 1, Common.getDateType(result.Tables[0].Rows[0]["STAFF_MAIL_SEND_YMD_NEW"].ToString()));
                        axfpSpread1.SetText(13, i + 1, result.Tables[0].Rows[0]["STAFF_MAIL_SEND_CON_NEW"].ToString());

                    }

                    lbCnt.Text = Convert.ToString(notExistList.Count) + "件";

                }
                else
                {

                    lbCnt.Text = "該当なし";
                    axfpSpread1.MaxRows = 0;
                }

            }
            else
            {

                lbCnt.Text = "該当なし";
                axfpSpread1.MaxRows = 0;
            }
        }

        private void frmClear()
        {

            txtRegYmd1.Text = string.Empty;
            txtRegYmd2.Text = string.Empty;
            txtRegYmd3.Text = string.Empty;
            txtRegYmd4.Text = string.Empty;

            chkMiToroku.Checked = true;
            chkToroku.Checked = false;
            chkAll.Checked = false;
           
            chkDisAll.Checked = false;

        }

        private void frmClose()
        {

            frmNotHiworkStaffListt_FormClosing(null, null);
            this.Close();
        }

        private void frmNotHiworkStaffListt_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmMain pForm = (frmMain)this.MdiParent;
            CodeMaster.FormArray.Remove(this);
        }

        private void chkSentakuAll_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSentakuAll.Checked)
            {

                for (int j = 1; j <= axfpSpread1.MaxRows; j++)
                {
                    Common.setFildSpread(axfpSpread1, 1, j);

                    axfpSpread1.Text = "1";
                }
            }
            else {

                for (int j = 1; j <= axfpSpread1.MaxRows; j++)
                {
                    Common.setFildSpread(axfpSpread1, 1, j);

                    axfpSpread1.Text = "";
                }
            }
        }

        private void chkMiToroku_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMiToroku.Checked)
            {
                chkToroku.Checked = false;
                chkAll.Checked = false;

            }


        }

        private void chkToroku_CheckedChanged(object sender, EventArgs e)
        {
            if (chkToroku.Checked)
            {
                chkMiToroku.Checked = false;
                chkAll.Checked = false;
            } 

        }

        private void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAll.Checked)
            {
                chkMiToroku.Checked = false;
                chkToroku.Checked = false;

            } 

        }
    }
}