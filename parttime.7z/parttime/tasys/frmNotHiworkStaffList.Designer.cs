﻿namespace parttime.tasys
{
    partial class frmNotHiworkStaffList
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNotHiworkStaffList));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chkToroku = new System.Windows.Forms.CheckBox();
            this.chkAll = new System.Windows.Forms.CheckBox();
            this.chkMiToroku = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRegYmd3 = new System.Windows.Forms.TextBox();
            this.btnCalender3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRegYmd4 = new System.Windows.Forms.TextBox();
            this.btnCalender4 = new System.Windows.Forms.Button();
            this.chkDisAll = new System.Windows.Forms.CheckBox();
            this.btnMail = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.txtRegYmd1 = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnCalender1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtRegYmd2 = new System.Windows.Forms.TextBox();
            this.btnCalender2 = new System.Windows.Forms.Button();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.axfpSpread1 = new AxFPUSpreadADO.AxfpSpread();
            this.lbCnt = new System.Windows.Forms.Label();
            this.chkSentakuAll = new System.Windows.Forms.CheckBox();
            this.groupBox3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axfpSpread1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.LemonChiffon;
            this.groupBox3.Controls.Add(this.chkToroku);
            this.groupBox3.Controls.Add(this.chkAll);
            this.groupBox3.Controls.Add(this.chkMiToroku);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.txtRegYmd3);
            this.groupBox3.Controls.Add(this.btnCalender3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.txtRegYmd4);
            this.groupBox3.Controls.Add(this.btnCalender4);
            this.groupBox3.Controls.Add(this.chkDisAll);
            this.groupBox3.Controls.Add(this.btnMail);
            this.groupBox3.Controls.Add(this.btnSearch);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.txtRegYmd1);
            this.groupBox3.Controls.Add(this.btnClose);
            this.groupBox3.Controls.Add(this.btnCalender1);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.btnClear);
            this.groupBox3.Controls.Add(this.txtRegYmd2);
            this.groupBox3.Controls.Add(this.btnCalender2);
            this.groupBox3.Location = new System.Drawing.Point(3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1138, 78);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            // 
            // chkToroku
            // 
            this.chkToroku.AutoSize = true;
            this.chkToroku.Location = new System.Drawing.Point(409, 50);
            this.chkToroku.Name = "chkToroku";
            this.chkToroku.Size = new System.Drawing.Size(84, 16);
            this.chkToroku.TabIndex = 267;
            this.chkToroku.Text = "登録者表示";
            this.chkToroku.UseVisualStyleBackColor = true;
            this.chkToroku.CheckedChanged += new System.EventHandler(this.chkToroku_CheckedChanged);
            // 
            // chkAll
            // 
            this.chkAll.AutoSize = true;
            this.chkAll.Location = new System.Drawing.Point(497, 50);
            this.chkAll.Name = "chkAll";
            this.chkAll.Size = new System.Drawing.Size(126, 16);
            this.chkAll.TabIndex = 266;
            this.chkAll.Text = "未登録・登録者表示";
            this.chkAll.UseVisualStyleBackColor = true;
            this.chkAll.CheckedChanged += new System.EventHandler(this.chkAll_CheckedChanged);
            // 
            // chkMiToroku
            // 
            this.chkMiToroku.AutoSize = true;
            this.chkMiToroku.Location = new System.Drawing.Point(308, 49);
            this.chkMiToroku.Name = "chkMiToroku";
            this.chkMiToroku.Size = new System.Drawing.Size(96, 16);
            this.chkMiToroku.TabIndex = 265;
            this.chkMiToroku.Text = "未登録者表示";
            this.chkMiToroku.UseVisualStyleBackColor = true;
            this.chkMiToroku.CheckedChanged += new System.EventHandler(this.chkMiToroku_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(24, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 260;
            this.label1.Text = "接続日";
            // 
            // txtRegYmd3
            // 
            this.txtRegYmd3.Location = new System.Drawing.Point(67, 45);
            this.txtRegYmd3.Name = "txtRegYmd3";
            this.txtRegYmd3.Size = new System.Drawing.Size(75, 19);
            this.txtRegYmd3.TabIndex = 256;
            // 
            // btnCalender3
            // 
            this.btnCalender3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnCalender3.Location = new System.Drawing.Point(143, 44);
            this.btnCalender3.Name = "btnCalender3";
            this.btnCalender3.Size = new System.Drawing.Size(23, 21);
            this.btnCalender3.TabIndex = 257;
            this.btnCalender3.Text = "C";
            this.btnCalender3.UseVisualStyleBackColor = true;
            this.btnCalender3.Click += new System.EventHandler(this.btnCalender3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(171, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 261;
            this.label2.Text = "～";
            // 
            // txtRegYmd4
            // 
            this.txtRegYmd4.Location = new System.Drawing.Point(190, 45);
            this.txtRegYmd4.Name = "txtRegYmd4";
            this.txtRegYmd4.Size = new System.Drawing.Size(75, 19);
            this.txtRegYmd4.TabIndex = 258;
            // 
            // btnCalender4
            // 
            this.btnCalender4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnCalender4.Location = new System.Drawing.Point(266, 44);
            this.btnCalender4.Name = "btnCalender4";
            this.btnCalender4.Size = new System.Drawing.Size(23, 21);
            this.btnCalender4.TabIndex = 259;
            this.btnCalender4.Text = "C";
            this.btnCalender4.UseVisualStyleBackColor = true;
            this.btnCalender4.Click += new System.EventHandler(this.btnCalender4_Click);
            // 
            // chkDisAll
            // 
            this.chkDisAll.AutoSize = true;
            this.chkDisAll.Location = new System.Drawing.Point(646, 19);
            this.chkDisAll.Name = "chkDisAll";
            this.chkDisAll.Size = new System.Drawing.Size(77, 16);
            this.chkDisAll.TabIndex = 255;
            this.chkDisAll.Text = "すべて表示";
            this.chkDisAll.UseVisualStyleBackColor = true;
            // 
            // btnMail
            // 
            this.btnMail.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnMail.Location = new System.Drawing.Point(396, 14);
            this.btnMail.Name = "btnMail";
            this.btnMail.Size = new System.Drawing.Size(75, 23);
            this.btnMail.TabIndex = 254;
            this.btnMail.Text = "メール作成";
            this.btnMail.UseVisualStyleBackColor = true;
            this.btnMail.Click += new System.EventHandler(this.btnMail_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSearch.Location = new System.Drawing.Point(308, 14);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 3;
            this.btnSearch.Text = "検索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label19.Location = new System.Drawing.Point(24, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(41, 12);
            this.label19.TabIndex = 251;
            this.label19.Text = "登録日";
            // 
            // txtRegYmd1
            // 
            this.txtRegYmd1.Location = new System.Drawing.Point(67, 16);
            this.txtRegYmd1.Name = "txtRegYmd1";
            this.txtRegYmd1.Size = new System.Drawing.Size(75, 19);
            this.txtRegYmd1.TabIndex = 247;
            // 
            // btnClose
            // 
            this.btnClose.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnClose.Location = new System.Drawing.Point(849, 13);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnCalender1
            // 
            this.btnCalender1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnCalender1.Location = new System.Drawing.Point(143, 15);
            this.btnCalender1.Name = "btnCalender1";
            this.btnCalender1.Size = new System.Drawing.Size(23, 21);
            this.btnCalender1.TabIndex = 248;
            this.btnCalender1.Text = "C";
            this.btnCalender1.UseVisualStyleBackColor = true;
            this.btnCalender1.Click += new System.EventHandler(this.btnCalender1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(171, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 252;
            this.label4.Text = "～";
            // 
            // btnClear
            // 
            this.btnClear.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnClear.Location = new System.Drawing.Point(484, 14);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtRegYmd2
            // 
            this.txtRegYmd2.Location = new System.Drawing.Point(190, 16);
            this.txtRegYmd2.Name = "txtRegYmd2";
            this.txtRegYmd2.Size = new System.Drawing.Size(75, 19);
            this.txtRegYmd2.TabIndex = 249;
            // 
            // btnCalender2
            // 
            this.btnCalender2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnCalender2.Location = new System.Drawing.Point(266, 15);
            this.btnCalender2.Name = "btnCalender2";
            this.btnCalender2.Size = new System.Drawing.Size(23, 21);
            this.btnCalender2.TabIndex = 250;
            this.btnCalender2.Text = "C";
            this.btnCalender2.UseVisualStyleBackColor = true;
            this.btnCalender2.Click += new System.EventHandler(this.btnCalender2_Click);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(72, 72);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 256;
            this.monthCalendar1.Visible = false;
            this.monthCalendar1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateSelected);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.axfpSpread1);
            this.panel1.Location = new System.Drawing.Point(1, 110);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1157, 584);
            this.panel1.TabIndex = 257;
            // 
            // axfpSpread1
            // 
            this.axfpSpread1.DataSource = null;
            this.axfpSpread1.Location = new System.Drawing.Point(6, 4);
            this.axfpSpread1.Name = "axfpSpread1";
            this.axfpSpread1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axfpSpread1.OcxState")));
            this.axfpSpread1.Size = new System.Drawing.Size(1151, 577);
            this.axfpSpread1.TabIndex = 0;
            this.axfpSpread1.DblClick += new AxFPUSpreadADO._DSpreadEvents_DblClickEventHandler(this.axfpSpread1_DblClick);
            this.axfpSpread1.ClickEvent += new AxFPUSpreadADO._DSpreadEvents_ClickEventHandler(this.axfpSpread1_ClickEvent);
            // 
            // lbCnt
            // 
            this.lbCnt.AutoSize = true;
            this.lbCnt.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lbCnt.ForeColor = System.Drawing.Color.Red;
            this.lbCnt.Location = new System.Drawing.Point(110, 89);
            this.lbCnt.Name = "lbCnt";
            this.lbCnt.Size = new System.Drawing.Size(41, 12);
            this.lbCnt.TabIndex = 258;
            this.lbCnt.Text = "label1";
            // 
            // chkSentakuAll
            // 
            this.chkSentakuAll.AutoSize = true;
            this.chkSentakuAll.Location = new System.Drawing.Point(60, 88);
            this.chkSentakuAll.Name = "chkSentakuAll";
            this.chkSentakuAll.Size = new System.Drawing.Size(44, 16);
            this.chkSentakuAll.TabIndex = 259;
            this.chkSentakuAll.Text = "ALL";
            this.chkSentakuAll.UseVisualStyleBackColor = true;
            this.chkSentakuAll.CheckedChanged += new System.EventHandler(this.chkSentakuAll_CheckedChanged);
            // 
            // frmNotHiworkStaffList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LemonChiffon;
            this.ClientSize = new System.Drawing.Size(1162, 701);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.chkSentakuAll);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbCnt);
            this.Name = "frmNotHiworkStaffList";
            this.Text = "Hiwork未登録スタッフリスト";
            this.Load += new System.EventHandler(this.frmNotHiworkStaffList_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axfpSpread1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox chkDisAll;
        private System.Windows.Forms.Button btnMail;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtRegYmd1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnCalender1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtRegYmd2;
        private System.Windows.Forms.Button btnCalender2;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Panel panel1;
        private AxFPUSpreadADO.AxfpSpread axfpSpread1;
        private System.Windows.Forms.Label lbCnt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRegYmd3;
        private System.Windows.Forms.Button btnCalender3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtRegYmd4;
        private System.Windows.Forms.Button btnCalender4;
        private System.Windows.Forms.CheckBox chkToroku;
        private System.Windows.Forms.CheckBox chkAll;
        private System.Windows.Forms.CheckBox chkMiToroku;
        private System.Windows.Forms.CheckBox chkSentakuAll;
    }
}