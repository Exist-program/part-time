﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Net.Mail;
using System.Net;
using parttime.common;


namespace parttime.mail
{
    public partial class frmStaffMail : Form
    {
        public frmStaffMail()
        {
            InitializeComponent();
        }

        private void frmStaffMail_Load(object sender, EventArgs e)
        {
            setData();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            sendMail();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            frmClose();
        }

        private void frmClose()
        {

            frmStaffMail_FormClosing(null, null);
            this.Close();
        }

        private void frmStaffMail_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmMain pForm = (frmMain)this.MdiParent;
            CodeMaster.FormArray.Remove(this);
        }

        private void setData()
        {

            Hashtable loginInfo = (Hashtable)Common.ADMININFO;

            AdminInfoBean adminInfo = (AdminInfoBean)loginInfo[CodeMaster.LoginInfo];

            ArrayList colList = new ArrayList();
            ArrayList valList = new ArrayList();

            colList.Add("@shain_code");
            valList.Add(adminInfo.getAdminId());

            txtForm.Text = DbCon.selectInfo2(colList, valList, Sql.SEL_23).Tables[0].Rows[0]["shain_email"].ToString();

            txtTitle.Text = MailConst.Title_Staff;

            StringBuilder to = new StringBuilder();

            string staffNm = null;

            for (int i = 0; i < CodeMaster.staffMailList.Count; i++)
            {

                string str = (string)CodeMaster.staffMailList[i];

                string[] strs = str.Split(',');

                if (i == 0)
                {

                    staffNm = strs[2];
                }

                to.Append(strs[1]);

                if (i != CodeMaster.staffMailList.Count - 1)
                {

                    to.Append(",");
                }
            }

            txtTo.Text = to.ToString();

            txtNaiyou.Text = getHeader(staffNm) + MailConst.getNaiyoStaff() + getBottom(staffNm);
        }

        private string getHeader(string staffNm)
        {

            string body = string.Empty;

            body += "\r\n" + "【" + staffNm + "】様、こんにちは！";
            body += "\r\n";

            return body;
        }

        private string getBottom(string staffNm)
        {
            string body = string.Empty;

            body += "\r\n" + "【" + staffNm + "】様に合う、良い仕事が見つかることを願いします。";
            body += "\r\n";

            return body;
        }

        private void sendMail()
        {

            for (int i = 0; i < CodeMaster.staffMailList.Count; i++)
            {

                try
                {
                    MailMessage Mail = new MailMessage();

                    string str = (string)CodeMaster.staffMailList[i];

                    string[] strs = str.Split(',');

                    Mail.To.Add(new MailAddress(strs[1]));
                    Mail.From = new MailAddress(txtForm.Text.ToString());
                    Mail.Subject = txtTitle.Text;
                    Mail.Body = getHeader(strs[2]) + MailConst.getNaiyoStaff() + getBottom(strs[2]);

                    SmtpClient client = new SmtpClient(MailControll.gb_Smtpser, 587);
                    client.Credentials = new NetworkCredential(MailControll.gb_SmtpID, MailControll.gb_SmtpPW);
                    client.Send(Mail);
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }

            }

            for (int i = 0; i < CodeMaster.staffMailList.Count; i++)
            {
                string str = (string)CodeMaster.staffMailList[i];

                string[] strs = str.Split(',');

                Common.updSendMail(2, strs[0], DateTime.Now.ToString(), MailConst.Title_Staff);

            }

            MessageBox.Show("メールを送信しました。");

        }   
    }
}