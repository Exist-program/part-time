﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class SalType
    {

        // 給料名
        static public string nameSalType0 = "▼給料形態";
        static public string nameSalType1 = "時給";
        static public string nameSalType2 = "日給";
        static public string nameSalType3 = "月給";


        // 給料値
        static public string codeSalType0 = "0";
        static public string codeSalType1 = "1";
        static public string codeSalType2 = "2";
        static public string codeSalType3 = "3";

        public static string[] nameSalTypeList = new string[] { 
    
            SalType.nameSalType0,
            SalType.nameSalType1,
            SalType.nameSalType2,
            SalType.nameSalType3
        };

        public static string[] codeSalTypeList = new string[] { 
    
            SalType.codeSalType0,
            SalType.codeSalType1,
            SalType.codeSalType2,
            SalType.codeSalType3
        };
    }
}
