﻿using System;
using System.Collections;
using System.Text;

namespace parttime.common
{

    class AdminInfoBean
    {

        private String adminNo = null;

        private String adminPw = null;

        private String adminId = null;

        private String adminLevel = null;

        private String adminName = null;

        private String adminFlg = null;

        public String getAdminNo()
        {
            return adminNo;
        }

        public void setAdminNo(String adminNo)
        {
            this.adminNo = adminNo;
        }

        public String getAdminPw()
        {
            return adminPw;
        }

        public void setAdminPw(String adminPw)
        {
            this.adminPw = adminPw;
        }

        public String getAdminId()
        {
            return adminId;
        }

        public void setAdminId(String adminId)
        {
            this.adminId = adminId;
        }

        public String getAdminLevel()
        {
            return adminLevel;
        }

        public void setAdminLevel(String adminLevel)
        {
            this.adminLevel = adminLevel;
        }

        public String getAdminName()
        {
            return adminName;
        }

        public void setAdminName(String adminName)
        {
            this.adminName = adminName;
        }

        public String getAdminFlg()
        {
            return adminFlg;
        }

        public void setAdminFlg(String adminFlg)
        {
            this.adminFlg = adminFlg;
        }
    }
}
