﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using AxFPUSpreadADO;
using System.Web.UI.WebControls;
using System.Collections;

namespace parttime.common
{
    class Common
    {

        public static Object ADMININFO = null;

        public static string gb_CalenderKB = null;

        public static void setComboBox(int flg, ComboBox obj)
        {

            ArrayList list = new ArrayList();

            if (flg == 1)
            {

                list.Add(new ListItem("▼--", ""));
                list.Add(new ListItem("Master", CodeMaster.Level_Master));
                list.Add(new ListItem("Public", CodeMaster.Level_Public));
                list.Add(new ListItem("Limited", CodeMaster.Level_Limited));
            }

            // 国家
            else if (flg == 2)
            {

                for (int i = 0; i < NationList.nameKuniList.Length; i++)
                {
                    list.Add(
                    new ListItem(NationList.nameKuniList[i], NationList.codeKuniList[i]));
                }
            }

            // 母国語
            else if (flg == 3)
            {

                for (int i = 0; i < Mothertongue.nameLangList.Length; i++)
                {
                    list.Add(
                        new ListItem(Mothertongue.nameLangList[i], Mothertongue.codeLangList[i]));
                }
            }

            // Todo
            else if (flg == 4)
            {

                for (int i = 0; i < TodoList.nameTodoList.Length; i++)
                {
                    list.Add(
                        new ListItem(TodoList.nameTodoList[i], TodoList.codeTodoList[i]));
                }
            }

            // 現在の状態
            else if (flg == 5)
            {

                for (int i = 0; i < CurrentSts.nameCurStsList.Length; i++)
                {
                    list.Add(
                        new ListItem(CurrentSts.nameCurStsList[i], CurrentSts.codeCurStsList[i]));
                }
            }

            // 学歴
            else if (flg == 6)
            {

                for (int i = 0; i < Schooling.nameSchoolList.Length; i++)
                {
                    list.Add(
                        new ListItem(Schooling.nameSchoolList[i], Schooling.codeSchoolList[i]));
                }
            }

            // 日本語Lv
            else if (flg == 7)
            {

                for (int i = 0; i < JapaneseLev.nameLanLevList.Length; i++)
                {
                    list.Add(
                        new ListItem(JapaneseLev.nameLanLevList[i], JapaneseLev.codeLanLevList[i]));
                }
            }

            // 期間
            else if (flg == 8)
            {

                for (int i = 0; i < Terms.nameTermList.Length; i++)
                {
                    list.Add(
                        new ListItem(Terms.nameTermList[i], Terms.codeTermList[i]));
                }
            }

            // 性別
            else if (flg == 9)
            {

                for (int i = 0; i < SexList.nameSexList.Length; i++)
                {

                    list.Add(new ListItem(SexList.nameSexList[i], SexList.codeSexList[i]));
                }
            }

            // 業種
            else if (flg == 10)
            {

                list.Add(new ListItem(JobList.nameJob00, JobList.codeJob00));

                // sell
                for (int i = 0; i < JobList.nameJobSellList.Length; i++)
                {
                    list.Add(new ListItem(JobList.nameJobSellList[i], JobList.codeJobSellList[i]));
                }

                // food
                for (int i = 0; i < JobList.nameJobFoodList.Length; i++)
                {
                    list.Add(new ListItem(JobList.nameJobFoodList[i], JobList.codeJobFoodList[i]));
                }

                // service
                for (int i = 0; i < JobList.nameJobServiceList.Length; i++)
                {
                    list.Add(new ListItem(JobList.nameJobServiceList[i], JobList.codeJobServiceList[i]));
                }

                // office
                for (int i = 0; i < JobList.nameJobOfficeList.Length; i++)
                {
                    list.Add(new ListItem(JobList.nameJobOfficeList[i], JobList.codeJobOfficeList[i]));
                }

                // amuse
                for (int i = 0; i < JobList.nameJobAmuseList.Length; i++)
                {
                    list.Add(new ListItem(JobList.nameJobAmuseList[i], JobList.codeJobAmuseList[i]));
                }

                // affair
                for (int i = 0; i < JobList.nameJobAffairsList.Length; i++)
                {
                    list.Add(new ListItem(JobList.nameJobAffairsList[i], JobList.codeJobAffairsList[i]));
                }

                // it
                for (int i = 0; i < JobList.nameJobItList.Length; i++)
                {
                    list.Add(new ListItem(JobList.nameJobItList[i], JobList.codeJobItList[i]));
                }

                // lang
                for (int i = 0; i < JobList.nameJobLanList.Length; i++)
                {
                    list.Add(new ListItem(JobList.nameJobLanList[i], JobList.codeJobLanList[i]));
                }
            }

            // 給与単位
            else if (flg == 11)
            {


            }

            // 給与タイプ
            else if (flg == 12)
            {

                for (int i = 0; i < SalType.nameSalTypeList.Length; i++)
                {

                    list.Add(new ListItem(SalType.nameSalTypeList[i], SalType.codeSalTypeList[i]));
                }
            }

            obj.DataSource = list;
            obj.DisplayMember = "TEXT";
            obj.ValueMember = "VALUE";
        }

        static public void setFildSpread(AxfpSpread fpSpread, int col, int row)
        {
            fpSpread.Col = col;
            fpSpread.Row = row;
        }

        static public void setClrSpread(AxfpSpread fpSpread)
        {
            fpSpread.MaxRows = 1;

            fpSpread.ClearRange(0, 1, fpSpread.MaxCols, fpSpread.MaxRows, true);
        }

        static public String getDateType(String ymd)
        {

            if (ymd != null && ymd != string.Empty)
            {

                DateTime dt = Convert.ToDateTime(ymd);

                ymd = String.Format("{0: yyyy/MM/dd}", dt);
            }

            return ymd;

        }

        static public void AddForm(Form XForm)
        {
            bool chkForm = false;

            for (int i = 0; i < CodeMaster.FormArray.Count; i++)
            {
                Form TempForm = (Form)CodeMaster.FormArray[i];
                if (TempForm.Name == XForm.Name)
                {
                    chkForm = true;
                }
            }
            if (!chkForm)
            {
                CodeMaster.FormArray.Add(XForm);
            }
        }

        static public void closeForm(Form XForm)
        {
            for (int i = 0; i < CodeMaster.FormArray.Count; i++)
            {
                Form TempForm = (Form)CodeMaster.FormArray[i];
                if (TempForm.Name == XForm.Name)
                {
                    TempForm.Close();
                    TempForm.Dispose();
                }
            }
        }

        static public Boolean getChkBox(String str)
        {

            Boolean chker = false;

            if (CodeMaster.ChkBoxYes.Equals(str))
            {

                chker = true;
            }

            return chker;

        }

        static public String getMoneyType(string str)
        {

            str = Convert.ToString(Math.Truncate(Convert.ToDouble(str)));

            return str;

        }

        static public void updSendMail(int flg, string num, string mailSendYmd, string mailSendTitle) {

            ArrayList colList = new ArrayList();
            ArrayList valList = new ArrayList();

            // 企業
            if(flg == 1) {
                
                colList.Add("@COMPANY_NO");
                valList.Add(num);

                DataSet ds = DbCon.selectInfo(colList, valList, Sql.SEL_21);

                string str = ds.Tables[0].Rows[0]["COMPANY_MAIL_SEND_CON_NEW"].ToString();

                if (str != string.Empty)
                {
                    
                    colList.Add("@COMPANY_MAIL_SEND_YMD_OLD");
                    valList.Add(Common.getDateType(ds.Tables[0].Rows[0]["COMPANY_MAIL_SEND_YMD_NEW"].ToString()));
                    colList.Add("@COMPANY_MAIL_SEND_CON_OLD");
                    valList.Add(ds.Tables[0].Rows[0]["COMPANY_MAIL_SEND_CON_NEW"].ToString());

                    // old update
                    DbCon.updateInfo(colList, valList, Sql.UDP_02);

                }

                colList.Clear();
                valList.Clear();

                colList.Add("@COMPANY_NO");
                valList.Add(num);
                colList.Add("@COMPANY_MAIL_SEND_YMD_NEW");
                valList.Add(Common.getDateType(mailSendYmd));
                colList.Add("@COMPANY_MAIL_SEND_CON_NEW");
                valList.Add(mailSendTitle);

                // new update
                DbCon.updateInfo(colList, valList, Sql.UDP_04);

            // スタッフ
            } else {

                colList.Add("@STAFF_NO");
                valList.Add(num);

                DataSet ds = DbCon.selectInfo(colList, valList, Sql.SEL_22);

                if (ds.Tables[0].Rows.Count > 0)
                {

                    colList.Add("@STAFF_MAIL_SEND_YMD_OLD");
                    valList.Add(ds.Tables[0].Rows[0]["STAFF_MAIL_SEND_YMD_NEW"].ToString());
                    colList.Add("@STAFF_MAIL_SEND_CON_OLD");
                    valList.Add(ds.Tables[0].Rows[0]["STAFF_MAIL_SEND_CON_NEW"].ToString());

                    // old update
                    DbCon.updateInfo(colList, valList, Sql.UDP_03);

                }

                colList.Clear();
                valList.Clear();

                colList.Add("STAFF_NO");
                valList.Add(num);
                colList.Add("@STAFF_MAIL_SEND_YMD_NEW");
                valList.Add(mailSendYmd);
                colList.Add("@STAFF_MAIL_SEND_CON_NEW");
                valList.Add(mailSendTitle);

                // new update
                DbCon.updateInfo(colList, valList, Sql.UDP_05);
                
            }

        }
    }
}