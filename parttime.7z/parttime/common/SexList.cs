﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class SexList
    {
        public static string nameSex0 = "▼性別";
        public static string nameSex1 = "男性";
        public static string nameSex2 = "女性";

        public static string codeSex0 = "0";
        public static string codeSex1 = "1";
        public static string codeSex2 = "2";

        public static string[] nameSexList = new string[] {
    
            SexList.nameSex0,
            SexList.nameSex1,
            SexList.nameSex2
        };

        public static string[] codeSexList = new string[] {
    
            SexList.codeSex0,
            SexList.codeSex1,
            SexList.codeSex2
        };
    }
}
