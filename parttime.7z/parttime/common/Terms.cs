﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class Terms
    {

        // 期間名
        static public string nameTerm0 = "▼期間";
        static public string nameTerm1 = "3ヶ月未満";
        static public string nameTerm2 = "6ヶ月未満";
        static public string nameTerm3 = "1年未満";
        static public string nameTerm4 = "1年～2年";
        static public string nameTerm5 = "2年～3年";
        static public string nameTerm6 = "3年以上";
        // static public string nameTerm7 = "7ヶ月";
        // static public string nameTerm8 = "8ヶ月";
        // static public string nameTerm9 = "9ヶ月";
        // static public string nameTerm10 = "10ヶ月";
        // static public string nameTerm11 = "11ヶ月";
        // static public string nameTerm12 = "1年以上";

        // 期間値
        static public string codeTerm0 = "0";
        static public string codeTerm1 = "1";
        static public string codeTerm2 = "2";
        static public string codeTerm3 = "3";
        static public string codeTerm4 = "4";
        static public string codeTerm5 = "5";
        static public string codeTerm6 = "6";
        // static public string codeTerm7 = "7";
        // static public string codeTerm8 = "8";
        // static public string codeTerm9 = "9";
        // static public string codeTerm10 = "10";
        // static public string codeTerm11 = "11";
        // static public string codeTerm12 = "12";

        public static string[] nameTermList = new string[] {
    
            Terms.nameTerm0,
            Terms.nameTerm1,
            Terms.nameTerm2,
            Terms.nameTerm3,
            Terms.nameTerm4,
            Terms.nameTerm5,
            Terms.nameTerm6
            // Terms.nameTerm7,
            // Terms.nameTerm8,
            // Terms.nameTerm9,
            // Terms.nameTerm10,
            // Terms.nameTerm11,
            // Terms.nameTerm12
        };

        public static string[] codeTermList = new string[] {
    
            Terms.codeTerm0,
            Terms.codeTerm1,
            Terms.codeTerm2,
            Terms.codeTerm3,
            Terms.codeTerm4,
            Terms.codeTerm5,
            Terms.codeTerm6
            // Terms.codeTerm7,
            // Terms.codeTerm8,
            // Terms.codeTerm9,
            // Terms.codeTerm10,
            // Terms.codeTerm11,
            // Terms.codeTerm12
        };
    }
}
