﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class JobList
    {

        public static string nameJob00 = "▼職種を選択";
        public static string codeJob00 = "000";

        public static string nameJobSell1 = "家電･携帯販売";
        public static string nameJobSell2 = "雑貨販売";
        public static string nameJobSell3 = "ドラッグストア･化粧品販売";
        public static string nameJobSell4 = "本･CD･DVD販売";
        public static string nameJobSell5 = "スーパー";
        public static string nameJobSell6 = "コンビニ";
        public static string nameJobSell7 = "食品販売";
        public static string nameJobSell8 = "店長･マネージャー(販売)";
        public static string nameJobSell9 = "その他販売";

        public static string codeJobSell1 = "s01";
        public static string codeJobSell2 = "s02";
        public static string codeJobSell3 = "s03";
        public static string codeJobSell4 = "s04";
        public static string codeJobSell5 = "s05";
        public static string codeJobSell6 = "s06";
        public static string codeJobSell7 = "s07";
        public static string codeJobSell8 = "s08";
        public static string codeJobSell9 = "s09";

        public static string[] nameJobSellList = new string[] {
    
            JobList.nameJobSell1,
            JobList.nameJobSell2,
            JobList.nameJobSell3,
            JobList.nameJobSell4,
            JobList.nameJobSell5,
            JobList.nameJobSell6,
            JobList.nameJobSell7,
            JobList.nameJobSell8,
            JobList.nameJobSell9

        };

        public static string[] codeJobSellList = new string[] {
    
            JobList.codeJobSell1,
            JobList.codeJobSell2,
            JobList.codeJobSell3,
            JobList.codeJobSell4,
            JobList.codeJobSell5,
            JobList.codeJobSell6,
            JobList.codeJobSell7,
            JobList.codeJobSell8,
            JobList.codeJobSell9

        };

        public static string nameJobFood1 = "カフェ";
        public static string nameJobFood2 = "ファミレス･レストラン";
        public static string nameJobFood3 = "ファストフード";
        public static string nameJobFood4 = "居酒屋";
        public static string nameJobFood5 = "バーテンダー･バー";
        public static string nameJobFood6 = "他飲食店ホール･キッチン";
        public static string nameJobFood7 = "ケーキ･パン･スイーツ(調理)";
        public static string nameJobFood8 = "デリバリー";
        public static string nameJobFood9 = "店長･マネージャー(飲食)";
        public static string nameJobFood10 = "その他飲食･フード";

        public static string codeJobFood1 = "f01";
        public static string codeJobFood2 = "f02";
        public static string codeJobFood3 = "f03";
        public static string codeJobFood4 = "f04";
        public static string codeJobFood5 = "f05";
        public static string codeJobFood6 = "f06";
        public static string codeJobFood7 = "f07";
        public static string codeJobFood8 = "f08";
        public static string codeJobFood9 = "f09";
        public static string codeJobFood10 = "f10";

        public static string[] nameJobFoodList = new string[] {
    
            JobList.nameJobFood1, 
            JobList.nameJobFood2, 
            JobList.nameJobFood3, 
            JobList.nameJobFood4, 
            JobList.nameJobFood5, 
            JobList.nameJobFood6, 
            JobList.nameJobFood7, 
            JobList.nameJobFood8, 
            JobList.nameJobFood9, 
            JobList.nameJobFood10

        };

        public static string[] codeJobFoodList = new string[] {
    
            JobList.codeJobFood1, 
            JobList.codeJobFood2, 
            JobList.codeJobFood3, 
            JobList.codeJobFood4, 
            JobList.codeJobFood5, 
            JobList.codeJobFood6, 
            JobList.codeJobFood7, 
            JobList.codeJobFood8, 
            JobList.codeJobFood9, 
            JobList.codeJobFood10

        };

        public static string nameJobService1 = "フロント･受付窓口";
        public static string nameJobService2 = "ホテル･旅館";
        public static string nameJobService3 = "ブライダル･他冠婚葬祭";
        public static string nameJobService4 = "旅行";
        public static string nameJobService5 = "ガソリンスタンド";
        public static string nameJobService6 = "店長･マネージャー(接客)";
        public static string nameJobService7 = "その他接客･サービス";

        public static string codeJobService1 = "v01";
        public static string codeJobService2 = "v02";
        public static string codeJobService3 = "v03";
        public static string codeJobService4 = "v04";
        public static string codeJobService5 = "v05";
        public static string codeJobService6 = "v06";
        public static string codeJobService7 = "v07";

        public static string[] nameJobServiceList = new string[] {
    
            JobList.nameJobService1, 
            JobList.nameJobService2, 
            JobList.nameJobService3, 
            JobList.nameJobService4, 
            JobList.nameJobService5, 
            JobList.nameJobService6, 
            JobList.nameJobService7

        };

        public static string[] codeJobServiceList = new string[] {
    
            JobList.codeJobService1, 
            JobList.codeJobService2, 
            JobList.codeJobService3, 
            JobList.codeJobService4, 
            JobList.codeJobService5, 
            JobList.codeJobService6, 
            JobList.codeJobService7

        };

        public static string nameJobOffice1 = "一般事務";
        public static string nameJobOffice2 = "受付";
        public static string nameJobOffice3 = "広報･宣伝";
        public static string nameJobOffice4 = "コールセンター";
        public static string nameJobOffice5 = "その他オフィスワーク";

        public static string codeJobOffice1 = "o01";
        public static string codeJobOffice2 = "o02";
        public static string codeJobOffice3 = "o03";
        public static string codeJobOffice4 = "o04";
        public static string codeJobOffice5 = "o05";

        public static string[] nameJobOfficeList = new string[] {
    
            JobList.nameJobOffice1, 
            JobList.nameJobOffice2, 
            JobList.nameJobOffice3, 
            JobList.nameJobOffice4, 
            JobList.nameJobOffice5
        };

        public static string[] codeJobOfficeList = new string[] {
    
            JobList.codeJobOffice1, 
            JobList.codeJobOffice2, 
            JobList.codeJobOffice3, 
            JobList.codeJobOffice4, 
            JobList.codeJobOffice5

        };

        public static string nameJobAmuse1 = "カラオケ";
        public static string nameJobAmuse2 = "漫画喫茶";
        public static string nameJobAmuse3 = "レジャー･ゲームセンター";
        public static string nameJobAmuse4 = "映画館";
        public static string nameJobAmuse5 = "その他アミューズメント";

        public static string codeJobAmuse1 = "a01";
        public static string codeJobAmuse2 = "a02";
        public static string codeJobAmuse3 = "a03";
        public static string codeJobAmuse4 = "a04";
        public static string codeJobAmuse5 = "a05";

        public static string[] nameJobAmuseList = new string[] {
    
            JobList.nameJobAmuse1, 
            JobList.nameJobAmuse2, 
            JobList.nameJobAmuse3, 
            JobList.nameJobAmuse4, 
            JobList.nameJobAmuse5

        };

        public static string[] codeJobAmuseList = new string[] {
    
            JobList.codeJobAmuse1, 
            JobList.codeJobAmuse2, 
            JobList.codeJobAmuse3, 
            JobList.codeJobAmuse4, 
            JobList.codeJobAmuse5

        };

        public static string nameJobAffairs1 = "商品梱包･在庫管理";
        public static string nameJobAffairs2 = "仕分け･引越し";
        public static string nameJobAffairs3 = "警備";
        public static string nameJobAffairs4 = "清掃";
        public static string nameJobAffairs5 = "その他軽作業･清掃･警備";

        public static string codeJobAffairs1 = "j01";
        public static string codeJobAffairs2 = "j02";
        public static string codeJobAffairs3 = "j03";
        public static string codeJobAffairs4 = "j04";
        public static string codeJobAffairs5 = "j05";

        public static string[] nameJobAffairsList = new string[] {
    
            JobList.nameJobAffairs1, 
            JobList.nameJobAffairs2, 
            JobList.nameJobAffairs3, 
            JobList.nameJobAffairs4, 
            JobList.nameJobAffairs5

        };

        public static string[] codeJobAffairsList = new string[] {
    
            JobList.codeJobAffairs1, 
            JobList.codeJobAffairs2, 
            JobList.codeJobAffairs3, 
            JobList.codeJobAffairs4, 
            JobList.codeJobAffairs5

        };

        public static string nameJobIt1 = "データ入力･オペレーター";
        public static string nameJobIt2 = "WEB･編集･クリエイター";
        public static string nameJobIt3 = "IT関連･エンジニア";

        public static string codeJobIt1 = "i01";
        public static string codeJobIt2 = "i02";
        public static string codeJobIt3 = "i03";

        public static string[] nameJobItList = new string[] {
    
            JobList.nameJobIt1, 
            JobList.nameJobIt2, 
            JobList.nameJobIt3

        };

        public static string[] codeJobItList = new string[] {
    
            JobList.codeJobIt1, 
            JobList.codeJobIt2, 
            JobList.codeJobIt3

        };

        public static string nameJobLan1 = "個人レッスン・プライベート講師";
        public static string nameJobLan2 = "語学塾非常勤講師";

        public static string codeJobLan1 = "l01";
        public static string codeJobLan2 = "l02";

        public static string[] nameJobLanList = new string[] {
    
            JobList.nameJobLan1, 
            JobList.nameJobLan2

        };

        public static string[] codeJobLanList = new string[] {
    
            JobList.codeJobLan1, 
            JobList.codeJobLan2 

        };

        public static string nameJobEvent1 = "イベント･芸能･キャンペーン";

        public static string codeJobEvent1 = "e01";

        public static string nameJobFasion1 = "ファッション・アパレル";

        public static string codeJobFasion1 = "f01";

        public static string nameJobBeauty1 = "美容･エステ･ネイル";

        public static string codeJobBeauty1 = "b01";

        public static string nameJobMedical1 = "医療･看護･介護";

        public static string codeJobMedical1 = "m01";

        public static string nameJobRest1 = "専門職･その他";

        public static string codeJobRest1 = "r01";
    }
}
