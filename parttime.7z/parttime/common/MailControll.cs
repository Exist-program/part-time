﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class MailControll
    {

        static public string gb_Smtpser = "mail.b-cause.co.jp";     //EMAIL送信SMTP
        static public string gb_SmtpID = "yokoyama";               //EMAIL送信ID
        static public string gb_SmtpPW = "y486bcs25";              //EMAIL送信PW


    }
}
