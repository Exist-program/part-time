﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace parttime.common
{
    class MailConst
    {
        public static string Title_KIgyou = "業界最大級の外国人の求人、採用情報検索サイトのご紹介";

        public static string Title_Staff = "外国人及び外国語を使った仕事の検索ができるサイトのご紹介";

        public static string getNaiyoKigyou() {
            /*
            企業名
            担当者様

            いつも大変お世話になっております。
            株式会社 ビーコスの【担当者名】です

            外国人求人：http://www.hiwork.jp/
            アルバイト募集：http://www.parttime-jp.info/
            外国人向けのアンケート調査：http://www.survey-navi.com/

            署名ーーーーーーーーーーーーーーーーーー
            */

            Hashtable loginInfo = (Hashtable)Common.ADMININFO;

            AdminInfoBean adminInfo = (AdminInfoBean)loginInfo[CodeMaster.LoginInfo];

            string body = string.Empty;

            body += "\r\n" + "いつも大変お世話になっております。";
            body += "\r\n" + "株式会社 ビーコスの【"+ adminInfo.getAdminName() +"】です";
            body += "\r\n";
            body += "\r\n" + "外国人求人：http://www.hiwork.jp/";
            body += "\r\n" + "アルバイト募集：http://www.parttime-jp.info/";
            body += "\r\n" + "外国人向けのアンケート調査：http://www.survey-navi.com/";
            body += "\r\n";
            body += "\r\n" + "□■━━━━━━━━━━━━━━━━━━━━━━━━■□";
            body += "\r\n" + "〒105-0013 東京都港区浜松町2-1-3 第二森ビル4F";
            body += "\r\n" + "Tel：03-5733-4264 　Fax：03-3433-3320";
            body += "\r\n" + "(メール) info@b-cause.co.jp";
            body += "\r\n" + "■□━━━━━━━━━━━━━━━━━━━━━━━━□■";
            body += "\r\n";

            return body;

        }

        public static string getNaiyoStaff() {

            string body = string.Empty;

            /*
            【名前】、こんにちは！
            いつも「使用のサイトURL」をご利用いただきありがとうございます。

            さて、本日は外国人及び外国語を使った仕事の検索ができるサイトのご紹介でご連絡いたしました。
            http://staff.hiwork.jp/
            地域・言語・雇用形態・職業（専門）別に仕事の検索が可能です。

            ただし、仕事の詳細を確認するには下記のページで登録が必要です。
            http://staff.hiwork.jp/staff/registration0.aspx

            【名前】さんに合う、良い仕事が見つかることを願いします。

             */

            body += "\r\n" + "いつも「使用のサイトURL」をご利用いただきありがとうございます。";
            body += "\r\n";
            body += "\r\n" + "さて、本日は外国人及び外国語を使った仕事の検索ができるサイトのご紹介でご連絡いたしました。";
            body += "\r\n" + "http://staff.hiwork.jp/";
            body += "\r\n" + "地域・言語・雇用形態・職業（専門）別に仕事の検索が可能です。";
            body += "\r\n";
            body += "\r\n" + "ただし、仕事の詳細を確認するには下記のページで登録が必要です。";
            body += "\r\n" + "http://staff.hiwork.jp/staff/registration0.aspx";
            body += "\r\n";


            return body;
        }
    }
}
