﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class JapaneseLev
    {

        // 日本語レベル名
        static public string nameLanLev0 = "▼日本語Lv";
        static public string nameLanLev1 = "できない";
        static public string nameLanLev2 = "片言";
        static public string nameLanLev3 = "日常会話レベル";
        static public string nameLanLev4 = "ビジネスレベル";
        static public string nameLanLev5 = "ネイティブ並み";
        static public string nameLanLev6 = "ネイティブ";

        // 日本語レベル値

        static public string codeLanLev0 = "0";
        static public string codeLanLev1 = "1";
        static public string codeLanLev2 = "2";
        static public string codeLanLev3 = "3";
        static public string codeLanLev4 = "4";
        static public string codeLanLev5 = "5";
        static public string codeLanLev6 = "6";

        public static string[] nameLanLevList = new string[] { 
    
            JapaneseLev.nameLanLev0,
            JapaneseLev.nameLanLev1,
            JapaneseLev.nameLanLev2,
            JapaneseLev.nameLanLev3,
            JapaneseLev.nameLanLev4,
            JapaneseLev.nameLanLev5,
            JapaneseLev.nameLanLev6

        };

        public static string[] codeLanLevList = new string[] {

            JapaneseLev.codeLanLev0,
            JapaneseLev.codeLanLev1,
            JapaneseLev.codeLanLev2,
            JapaneseLev.codeLanLev3,
            JapaneseLev.codeLanLev4,
            JapaneseLev.codeLanLev5,
            JapaneseLev.codeLanLev6

        };
    }
}
