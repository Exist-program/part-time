﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class Schooling
    {

        // 学歴
        static public string nameSchool0 = "▼学歴";
        static public string nameSchool1 = "中卒";
        static public string nameSchool2 = "高卒";
        static public string nameSchool3 = "大在中";
        static public string nameSchool4 = "大卒";

        // 現在の状態値
        static public string codeSchool0 = "0";
        static public string codeSchool1 = "1";
        static public string codeSchool2 = "2";
        static public string codeSchool3 = "3";
        static public string codeSchool4 = "4";

        public static string[] nameSchoolList = new string[] {
           Schooling.nameSchool0,
           Schooling.nameSchool1,
           Schooling.nameSchool2,
           Schooling.nameSchool3,
           Schooling.nameSchool4
        };

        public static string[] codeSchoolList = new string[] {
           Schooling.codeSchool0,
           Schooling.codeSchool1,
           Schooling.codeSchool2,
           Schooling.codeSchool3,
           Schooling.codeSchool4
        };
    }
}
