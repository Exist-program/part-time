﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace parttime.common
{
    class CodeMaster
    {
        public static ArrayList FormArray = new ArrayList();

        public static String LoginInfo = "adminLoginInfo";

        public static String MatchEmailPattern = @"^[a-z0-9A-Z][\.\-a-z0-9A-Z_]*[\-a-z0-9A-Z_]@[a-z0-9A-Z]+[\-]*[a-z0-9A-Z]+(\.[a-z0-9A-Z]+[\-]*[a-z0-9A-Z]+)*\.[a-zA-Z]+$";

        public static String MatchPwPatter = "^[a-zA-Z0-9]+$";

        public static String IdNotExist = "0";

        public static String OK = "OK";

        public static String STAFFNO = null;

        public static String COMPANYNO = null;

        public static String JOBNO = null;

        public static String ChkBoxYes = "1";

        public static String ChkBoxNo = "2";

        public static String ChkBoxAri = "A";

        public static String ChkBoxNasi = "N";

        public static String checkBoxTime1 = "早朝";

        public static String checkBoxTime2 = "朝";

        public static String checkBoxTime3 = "昼";

        public static String checkBoxTime4 = "夕方";

        public static String checkBoxTime5 = "深夜";

        public static String checkBoxTime6 = "週１～2日";

        public static String checkBoxTime7 = "週3～4日";

        public static String checkBoxTime8 = "週5日以上";

        public static String checkBoxCondition1 = "シフト制勤務";

        public static String checkBoxCondition2 = "平日のみ";

        public static String checkBoxCondition3 = "土日のみ";

        public static String checkBoxCondition4 = "短時間勤務";

        public static String checkBoxCondition5 = "時間・曜日応相談";

        public static String checkBoxCondition6 = "在宅";

        public static String SalType = null;

        public static String Level_Master = "1";

        public static String Level_Public = "3";

        public static String Level_Limited = "4";

        public static String Master = "Master";

        public static String Public = "Public";

        public static String Limited = "Limited";

        public static ArrayList staffMailList = null;

        public static ArrayList kigyouMailList = null;
    }
}
