﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class MessageConst
    {
        public static string IdMustEnterErr = "※ IDを入力してください。";

        public static string PwMustEnterErr = "※ PWを入力してください。";

        public static string MailPatternChkErr = "※ メール形式ではありません。確認して下さい。";

        public static string NotExistIdEnterErr = "※ 存在しないIDです。IDを確認して下さい。";

        public static string NotExistPWEnterErr = "※ PWが間違っています。PWを確認して下さい。";

        public static string LimitedLv = "管理者へお問い合わせして下さい。";
    }
}
