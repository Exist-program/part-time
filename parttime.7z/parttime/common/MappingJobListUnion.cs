﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using AxFPUSpreadADO;
using System.Web.UI.WebControls;
using System.Collections;

namespace parttime.common
{
    class MappingJobListUnion
    {

        public static String getJobUnion(DataSet ds, int flg, int i)
        {

            StringBuilder sb = new StringBuilder();

            int cnt = 0;

            if (ds.Tables[0].Rows[i]["JOB_SELL_1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobSell1));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SELL_2"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobSell2));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SELL_3"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobSell3));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SELL_4"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobSell4));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SELL_5"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobSell5));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SELL_6"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobSell6));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SELL_7"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobSell7));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SELL_8"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobSell8));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SELL_9"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobSell9));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_FOOD_1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobFood1));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_FOOD_2"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobFood2));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_FOOD_3"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobFood3));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_FOOD_4"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobFood4));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_FOOD_5"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobFood5));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_FOOD_6"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobFood6));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_FOOD_7"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobFood7));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_FOOD_8"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobFood8));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_FOOD_9"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobFood9));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_FOOD_10"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobFood10));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SERVICE_1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobService1));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SERVICE_2"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobService2));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SERVICE_3"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobService3));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SERVICE_4"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobService4));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SERVICE_5"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobService5));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SERVICE_6"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobService6));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_SERVICE_7"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobService7));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_OFFICE_1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobOffice1));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_OFFICE_2"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobOffice2));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_OFFICE_3"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobOffice3));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_OFFICE_4"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobOffice4));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_OFFICE_5"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobOffice5));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_AFFAIRS_1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobAffairs1));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_AFFAIRS_2"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobAffairs2));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_AFFAIRS_3"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobAffairs3));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_AFFAIRS_4"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobAffairs4));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_AFFAIRS_5"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobAffairs5));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_AMUSE_1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobAmuse1));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_AMUSE_2"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobAmuse2));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_AMUSE_3"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobAmuse3));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_AMUSE_4"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobAmuse4));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_AMUSE_5"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobAmuse5));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_IT_1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobIt1));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_IT_2"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobIt2));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_IT_3"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobIt3));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_LANGUAGE_1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobLan1));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_LANGUAGE_2"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobLan2));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_EVENT_1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobEvent1));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_FASION_1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobFasion1));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_MEDICAL_1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobMedical1));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_BEAUTY_1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobBeauty1));
                cnt++;
            }

            if (ds.Tables[0].Rows[i]["JOB_REST_1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                if (cnt != 0)
                {
                    sb.Append(",");
                }

                sb.Append(MappingJobList.JobListMapping(JobList.codeJobRest1));
                cnt++;
            }

            string union = null;

            if (flg == 1)
            {
                string[] strs = sb.ToString().Split(',');

                union = strs[0];
            }
            else
            {

                union = sb.ToString();
            }

            return union;
        }
    }
}
