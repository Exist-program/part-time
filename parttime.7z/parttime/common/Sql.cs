﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class Sql
    {
        public static string SEL_01 = "SELECT COUNT(*) FROM M_CS_SHAIN WHERE SHAIN_CODE = @shain_code";

        public static string SEL_02 = "SELECT SHAIN_CODE, SHAIN_PASSWORD, SHAIN_NAME FROM M_CS_SHAIN where SHAIN_CODE = @shain_code and SHAIN_PASSWORD = @shain_password";

        public static string SEL_03 = "select admin_no, admin_id, admin_name, admin_level, admin_pw from admin_info where admin_flg = '1' order by admin_no";

        public static string SEL_04_START = "select staff_no, staff_nation, staff_native_lan, staff_todo, staff_addr1, staff_addr2, staff_sex, staff_jpn_lan_lev, staff_age, staff_post_no1, staff_post_no2, staff_id, staff_keitai_mail,staff_schooling, staff_sts, staff_job_content1, staff_job_content2, staff_job_term1, staff_job_term2,staff_is_scout, staff_name, staff_tel, staff_keitai_tel ,staff_time1 ,staff_time2 ,staff_time3 ,staff_time4 ,staff_time5,staff_time6,staff_time7,staff_time8, staff_condition1,staff_condition2,staff_condition3,staff_condition4, staff_condition5 ,staff_condition6,STAFF_REGISTER_YMD, STAFF_LAST_CON_YMD from staff_info where staff_register_ymd BETWEEN CONVERT(Datetime, @REGYMDSTR + ' 00:00:00') AND CONVERT(Datetime, @REGYMDEND + ' 23:59:59')";

        public static string SEL_04_CON1 = " and staff_nation = @staff_nation";

        public static string SEL_04_CON2 = " and staff_native_lan = @staff_native_lan";

        public static string SEL_04_CON3 = " and staff_todo = @staff_todo";

        public static string SEL_04_END = " order by STAFF_REGISTER_YMD desc";

        public static string SEL_05 = "select count(*) from recruit_info where staff_no = @staff_no and staff_apply_sts = 6";

        public static string SEL_06 = "select count(*) from recruit_info where staff_no = @staff_no and staff_apply_sts = 2";

        public static string SEL_07 = "select myStaffTbl.staff_no, staff_nation, staff_native_lan, staff_todo, staff_addr1, staff_addr2, staff_sex, staff_jpn_lan_lev, staff_age, staff_post_no1, staff_post_no2, staff_id, staff_keitai_mail, staff_schooling, staff_sts, staff_job_content1, staff_job_content2, staff_job_term1,staff_job_term2, staff_is_scout,JOB_SELL_1,JOB_SELL_2,JOB_SELL_3,JOB_SELL_4,JOB_SELL_5,JOB_SELL_6,JOB_SELL_7,JOB_SELL_8,JOB_SELL_9,JOB_FOOD_1,JOB_FOOD_2,JOB_FOOD_3,JOB_FOOD_4,JOB_FOOD_5,JOB_FOOD_6,JOB_FOOD_7,JOB_FOOD_8,JOB_FOOD_9,JOB_FOOD_10,JOB_SERVICE_1,JOB_SERVICE_2,JOB_SERVICE_3,JOB_SERVICE_4,JOB_SERVICE_5,JOB_SERVICE_6,JOB_SERVICE_7,JOB_OFFICE_1,JOB_OFFICE_2,JOB_OFFICE_3,JOB_OFFICE_4,JOB_OFFICE_5,JOB_AMUSE_1,JOB_AMUSE_2,JOB_AMUSE_3,JOB_AMUSE_4,JOB_AMUSE_5,JOB_AFFAIRS_1,JOB_AFFAIRS_2,JOB_AFFAIRS_3,JOB_AFFAIRS_4,JOB_AFFAIRS_5,JOB_IT_1,JOB_IT_2,JOB_IT_3,JOB_LANGUAGE_1,JOB_LANGUAGE_2,JOB_EVENT_1,JOB_FASION_1,JOB_BEAUTY_1,JOB_MEDICAL_1,JOB_REST_1, staff_name, staff_tel, staff_keitai_tel,staff_time1 ,staff_time2 ,staff_time3 ,staff_time4 ,staff_time5,staff_time6,staff_time7,staff_time8, staff_condition1,staff_condition2,staff_condition3,staff_condition4, staff_condition5 ,staff_condition6,STAFF_REGISTER_YMD, STAFF_LAST_CON_YMD,STAFF_BIRDAY,STAFF_PHO from (select staff_no, staff_nation, staff_native_lan, staff_todo, staff_addr1, staff_addr2, staff_sex, staff_jpn_lan_lev, staff_age, staff_post_no1, staff_post_no2, staff_id, staff_keitai_mail,staff_schooling, staff_sts, staff_job_content1, staff_job_content2, staff_job_term1, staff_job_term2,staff_is_scout, staff_name, staff_tel, staff_keitai_tel ,staff_time1 ,staff_time2 ,staff_time3 ,staff_time4 ,staff_time5,staff_time6,staff_time7,staff_time8, staff_condition1,staff_condition2,staff_condition3,staff_condition4, staff_condition5 ,staff_condition6,STAFF_REGISTER_YMD, STAFF_LAST_CON_YMD,STAFF_BIRDAY,STAFF_PHO from staff_info where staff_no = @staff_no ) as myStaffTbl join staff_job_list as sjList on myStaffTbl.staff_no = sjList.staff_no";

        public static string SEL_08 = "select job_no, myJobTbl.company_no, company_name, job_appeal, job_contents, job_sal_type, job_time1, job_time2, job_time3, job_time4, job_time5, job_time6, job_time7, job_time8,job_condition1, job_condition2, job_condition3, job_condition4, job_condition5, job_condition6, job_todo, job_area , job_traffic_1, job_traffic_2, ISNULL(job_tra_money, '') as job_tra_money, job_closing_ymd, company_grade, job_sal_tani,job_intro, job_kind, job_pho,JOB_TRA_MONEY_UMU,company_id, JOB_UPD_YMD from (select job_no, company_no, job_appeal, job_contents, job_sal_type, job_time1, job_time2, job_time3, job_time4, job_time5, job_time6, job_time7, job_time8,job_condition1, job_condition2, job_condition3, job_condition4, job_condition5, job_condition6, job_todo, job_area , job_traffic_1, job_traffic_2, job_tra_money, job_closing_ymd, job_sal_tani,job_intro, job_kind, job_pho, JOB_TRA_MONEY_UMU, JOB_UPD_YMD from job_info where job_apply_end != 0 and job_apply_end != 6 and JOB_REGISTER_YMD BETWEEN CONVERT(Datetime, @REGYMDSTR + ' 00:00:00') AND CONVERT(Datetime, @REGYMDEND + ' 23:59:59')) as myJobTbl join company_info as cinfo on myJobTbl.company_no = cinfo.company_no order by JOB_UPD_YMD desc";

        //KIMKU_150129
        //public static string SEL_09 = "select job_no, myJobTbl.company_no, company_name, job_appeal, job_contents, job_sal_type, job_time1, job_time2, job_time3, job_time4, job_time5, job_time6, job_time7, job_time8,job_condition1, job_condition2, job_condition3, job_condition4, job_condition5, job_condition6, job_todo, job_area , job_traffic_1, job_traffic_2, job_tra_money, job_closing_ymd, company_grade, job_sal_tani,job_intro, job_kind, job_pho,JOB_TRA_MONEY_UMU,company_id, JOB_UPD_YMD from (select job_no, company_no, job_appeal, job_contents, job_sal_type, job_time1, job_time2, job_time3, job_time4, job_time5, job_time6, job_time7, job_time8,job_condition1, job_condition2, job_condition3, job_condition4, job_condition5, job_condition6, job_todo, job_area , job_traffic_1, job_traffic_2, job_tra_money, job_closing_ymd, job_sal_tani,job_intro, job_kind, job_pho, JOB_TRA_MONEY_UMU, JOB_UPD_YMD from job_info where job_apply_end != 0 and job_apply_end != 6 and job_no = @job_no) as myJobTbl join company_info as cinfo on myJobTbl.company_no = cinfo.company_no";
        public static string SEL_09 = "select job_no, myJobTbl.company_no, company_name, job_appeal, job_contents, job_sal_type, job_time1, job_time2, job_time3, job_time4, job_time5, job_time6, job_time7, job_time8,job_condition1, job_condition2, job_condition3, job_condition4, job_condition5, job_condition6, job_todo, job_area , job_traffic_1, job_traffic_2, job_tra_money, job_closing_ymd, company_grade, job_sal_tani,job_intro, job_kind, job_pho,JOB_TRA_MONEY_UMU,company_id, JOB_UPD_YMD, APPEALPOINT_A, APPEALPOINT_B, PUBLISH, PUBLISHLANGFROM, PUBLISHLANGTO, NEED_TRANSLATE from (select job_no, company_no, job_appeal, job_contents, job_sal_type, job_time1, job_time2, job_time3, job_time4, job_time5, job_time6, job_time7, job_time8,job_condition1, job_condition2, job_condition3, job_condition4, job_condition5, job_condition6, job_todo, job_area , job_traffic_1, job_traffic_2, job_tra_money, job_closing_ymd, job_sal_tani,job_intro, job_kind, job_pho, JOB_TRA_MONEY_UMU, JOB_UPD_YMD, APPEALPOINT_A, APPEALPOINT_B, PUBLISH, PUBLISHLANGFROM, PUBLISHLANGTO, NEED_TRANSLATE from job_info where job_apply_end != 0 and job_apply_end != 6 and job_no = @job_no) as myJobTbl join company_info as cinfo on myJobTbl.company_no = cinfo.company_no";

        public static string SEL_10 = "select myCompany.COMPANY_NO,COMPANY_ID,COMPANY_PW,COMPANY_NAME,COMPANY_PART,COMPANY_TANTO,COMPANY_POST_NO1,COMPANY_POST_NO2,COMPANY_TODO,COMPANY_ADDR1,COMPANY_ADDR2,COMPANY_TEL,COMPANY_PHO,JOB_SELL_1,JOB_SELL_2,JOB_SELL_3,JOB_SELL_4,JOB_SELL_5,JOB_SELL_6,JOB_SELL_7,JOB_SELL_8,JOB_SELL_9,JOB_FOOD_1,JOB_FOOD_2,JOB_FOOD_3,JOB_FOOD_4,JOB_FOOD_5,JOB_FOOD_6,JOB_FOOD_7,JOB_FOOD_8,JOB_FOOD_9,JOB_FOOD_10,JOB_SERVICE_1,JOB_SERVICE_2,JOB_SERVICE_3,JOB_SERVICE_4,JOB_SERVICE_5,JOB_SERVICE_6,JOB_SERVICE_7,JOB_OFFICE_1,JOB_OFFICE_2,JOB_OFFICE_3,JOB_OFFICE_4,JOB_OFFICE_5,JOB_AMUSE_1,JOB_AMUSE_2,JOB_AMUSE_3,JOB_AMUSE_4,JOB_AMUSE_5,JOB_AFFAIRS_1,JOB_AFFAIRS_2,JOB_AFFAIRS_3,JOB_AFFAIRS_4,JOB_AFFAIRS_5,JOB_IT_1,JOB_IT_2,JOB_IT_3,JOB_LANGUAGE_1,JOB_LANGUAGE_2,JOB_EVENT_1,JOB_FASION_1,JOB_BEAUTY_1,JOB_MEDICAL_1,JOB_REST_1, COMPANY_ATTENTION_CNT, COMPANY_GRADE_CNT, COMPANY_GRADE,COMPANY_REGISTER_YMD, COMPANY_LAST_CON_YMD from (SELECT COMPANY_NO,COMPANY_ID,COMPANY_PW,COMPANY_NAME,COMPANY_PART,COMPANY_TANTO,COMPANY_POST_NO1,COMPANY_POST_NO2,COMPANY_TODO,COMPANY_ADDR1,COMPANY_ADDR2,COMPANY_TEL,COMPANY_PHO, COMPANY_ATTENTION_CNT, COMPANY_GRADE_CNT, COMPANY_GRADE,COMPANY_REGISTER_YMD, COMPANY_LAST_CON_YMD FROM COMPANY_INFO where COMPANY_REGISTER_YMD BETWEEN CONVERT(Datetime, @REGYMDSTR + ' 00:00:00') AND CONVERT(Datetime,  @REGYMDEND + ' 23:59:59')) as myCompany join company_job_list as cjList on myCompany.company_no = cjList.company_no order by COMPANY_REGISTER_YMD desc";

        public static string SEL_11 = "select myCompany.COMPANY_NO,COMPANY_ID,COMPANY_PW,COMPANY_NAME,COMPANY_PART,COMPANY_TANTO,COMPANY_POST_NO1,COMPANY_POST_NO2,COMPANY_TODO,COMPANY_ADDR1,COMPANY_ADDR2,COMPANY_TEL,COMPANY_PHO,JOB_SELL_1,JOB_SELL_2,JOB_SELL_3,JOB_SELL_4,JOB_SELL_5,JOB_SELL_6,JOB_SELL_7,JOB_SELL_8,JOB_SELL_9,JOB_FOOD_1,JOB_FOOD_2,JOB_FOOD_3,JOB_FOOD_4,JOB_FOOD_5,JOB_FOOD_6,JOB_FOOD_7,JOB_FOOD_8,JOB_FOOD_9,JOB_FOOD_10,JOB_SERVICE_1,JOB_SERVICE_2,JOB_SERVICE_3,JOB_SERVICE_4,JOB_SERVICE_5,JOB_SERVICE_6,JOB_SERVICE_7,JOB_OFFICE_1,JOB_OFFICE_2,JOB_OFFICE_3,JOB_OFFICE_4,JOB_OFFICE_5,JOB_AMUSE_1,JOB_AMUSE_2,JOB_AMUSE_3,JOB_AMUSE_4,JOB_AMUSE_5,JOB_AFFAIRS_1,JOB_AFFAIRS_2,JOB_AFFAIRS_3,JOB_AFFAIRS_4,JOB_AFFAIRS_5,JOB_IT_1,JOB_IT_2,JOB_IT_3,JOB_LANGUAGE_1,JOB_LANGUAGE_2,JOB_EVENT_1,JOB_FASION_1,JOB_BEAUTY_1,JOB_MEDICAL_1,JOB_REST_1, COMPANY_ATTENTION_CNT, COMPANY_GRADE_CNT, COMPANY_GRADE,COMPANY_REGISTER_YMD, COMPANY_LAST_CON_YMD from (SELECT COMPANY_NO,COMPANY_ID,COMPANY_PW,COMPANY_NAME,COMPANY_PART,COMPANY_TANTO,COMPANY_POST_NO1,COMPANY_POST_NO2,COMPANY_TODO,COMPANY_ADDR1,COMPANY_ADDR2,COMPANY_TEL,COMPANY_PHO, COMPANY_ATTENTION_CNT, COMPANY_GRADE_CNT, COMPANY_GRADE,COMPANY_REGISTER_YMD, COMPANY_LAST_CON_YMD FROM COMPANY_INFO where company_no = @company_no) as myCompany join company_job_list as cjList on myCompany.company_no = cjList.company_no";

        public static string SEL_12 = "SELECT COMPANY_ID FROM COMPANY_INFO where COMPANY_REGISTER_YMD BETWEEN CONVERT(Datetime, @REGYMDSTR + ' 00:00:00') AND CONVERT(Datetime,  @REGYMDEND + ' 23:59:59') AND COMPANY_LAST_CON_YMD BETWEEN CONVERT(Datetime, @REGYMDSTR2 + ' 00:00:00') AND CONVERT(Datetime,  @REGYMDEND2 + ' 23:59:59')";

        public static string SEL_12_1 = "SELECT TOP(100) COMPANY_ID FROM COMPANY_INFO where COMPANY_REGISTER_YMD BETWEEN CONVERT(Datetime, @REGYMDSTR + ' 00:00:00') AND CONVERT(Datetime,  @REGYMDEND + ' 23:59:59') AND COMPANY_LAST_CON_YMD BETWEEN CONVERT(Datetime, @REGYMDSTR2 + ' 00:00:00') AND CONVERT(Datetime,  @REGYMDEND2 + ' 23:59:59')";

        public static string SEL_13 = "SELECT COUNT(*) FROM K_KIGYOU WHERE KIGYOUID = @KIGYOUID";

        public static string SEL_14 = "SELECT VERSIONINFO FROM VERSION";

        public static string SEL_15 = "SELECT COUNT(*) FROM ADMIN_INFO WHERE ADMIN_ID = @admin_id";

        //public static string SEL_16 = "SELECT ADMIN_NO, ADMIN_ID ,ADMIN_PW, ADMIN_NAME, ADMIN_LEVEL, ADMIN_FLG FROM ADMIN_INFO WHERE ADMIN_ID = @admin_id AND ADMIN_PW = @admin_pw";
        //KIMKU_130813 PASSチェック解除
        public static string SEL_16 = "SELECT ADMIN_NO, ADMIN_ID ,ADMIN_PW, ADMIN_NAME, ADMIN_LEVEL, ADMIN_FLG FROM ADMIN_INFO WHERE ADMIN_ID = @admin_id";

        public static string SEL_17 = "SELECT myCompany.COMPANY_NO,COMPANY_ID,COMPANY_NAME,COMPANY_TANTO ,COMPANY_TODO,COMPANY_ADDR1,COMPANY_ADDR2,COMPANY_TEL,JOB_SELL_1,JOB_SELL_2,JOB_SELL_3,JOB_SELL_4,JOB_SELL_5,JOB_SELL_6,JOB_SELL_7,JOB_SELL_8,JOB_SELL_9,JOB_FOOD_1,JOB_FOOD_2,JOB_FOOD_3,JOB_FOOD_4,JOB_FOOD_5,JOB_FOOD_6,JOB_FOOD_7,JOB_FOOD_8,JOB_FOOD_9,JOB_FOOD_10,JOB_SERVICE_1,JOB_SERVICE_2,JOB_SERVICE_3,JOB_SERVICE_4,JOB_SERVICE_5,JOB_SERVICE_6,JOB_SERVICE_7,JOB_OFFICE_1,JOB_OFFICE_2,JOB_OFFICE_3,JOB_OFFICE_4,JOB_OFFICE_5,JOB_AMUSE_1,JOB_AMUSE_2,JOB_AMUSE_3,JOB_AMUSE_4,JOB_AMUSE_5,JOB_AFFAIRS_1,JOB_AFFAIRS_2,JOB_AFFAIRS_3,JOB_AFFAIRS_4,JOB_AFFAIRS_5,JOB_IT_1,JOB_IT_2,JOB_IT_3,JOB_LANGUAGE_1,JOB_LANGUAGE_2,JOB_EVENT_1,JOB_FASION_1,JOB_BEAUTY_1,JOB_MEDICAL_1,JOB_REST_1,COMPANY_REGISTER_YMD, COMPANY_LAST_CON_YMD, COMPANY_MAIL_SEND_YMD_NEW, COMPANY_MAIL_SEND_CON_NEW from (SELECT COMPANY_NO,COMPANY_ID,COMPANY_PW,COMPANY_NAME, COMPANY_TANTO,COMPANY_TODO,COMPANY_ADDR1,COMPANY_ADDR2,COMPANY_TEL, COMPANY_REGISTER_YMD, COMPANY_LAST_CON_YMD, COMPANY_MAIL_SEND_YMD_NEW, COMPANY_MAIL_SEND_CON_NEW FROM COMPANY_INFO where company_id = @company_id) as myCompany join company_job_list as cjList on myCompany.company_no = cjList.company_no";

        public static string SEL_18 = "SELECT STAFF_ID FROM STAFF_INFO where STAFF_REGISTER_YMD BETWEEN CONVERT(Datetime, @REGYMDSTR + ' 00:00:00') AND CONVERT(Datetime,  @REGYMDEND + ' 23:59:59') AND STAFF_LAST_CON_YMD BETWEEN CONVERT(Datetime, @REGYMDSTR2 + ' 00:00:00') AND CONVERT(Datetime,  @REGYMDEND2 + ' 23:59:59')";

        public static string SEL_18_1 = "SELECT TOP(100) STAFF_ID FROM STAFF_INFO where STAFF_REGISTER_YMD BETWEEN CONVERT(Datetime, @REGYMDSTR + ' 00:00:00') AND CONVERT(Datetime,  @REGYMDEND + ' 23:59:59') AND STAFF_LAST_CON_YMD BETWEEN CONVERT(Datetime, @REGYMDSTR2 + ' 00:00:00') AND CONVERT(Datetime,  @REGYMDEND2 + ' 23:59:59')";

        public static string SEL_19 = "SELECT COUNT(*) FROM S_STAFF WHERE STAFFID = @STAFFID";

        public static string SEL_20 = "select staff_no, staff_id, staff_name, staff_nation, staff_native_lan, staff_todo, staff_addr1, staff_addr2, staff_keitai_mail , staff_tel, staff_keitai_tel ,STAFF_REGISTER_YMD, STAFF_LAST_CON_YMD,STAFF_MAIL_SEND_YMD_NEW, STAFF_MAIL_SEND_CON_NEW from staff_info where staff_id = @STAFFID";

        public static string SEL_21 = "SELECT ISNULL(COMPANY_MAIL_SEND_CON_NEW, '') as COMPANY_MAIL_SEND_CON_NEW, ISNULL(COMPANY_MAIL_SEND_YMD_NEW, '') as COMPANY_MAIL_SEND_YMD_NEW FROM COMPANY_INFO WHERE COMPANY_NO = @COMPANY_NO";

        public static string SEL_22 = "SELECT ISNULL(STAFF_MAIL_SEND_CON_NEW, '') as STAFF_MAIL_SEND_CON_NEW, ISNULL(STAFF_MAIL_SEND_YMD_NEW, '') as STAFF_MAIL_SEND_YMD_NEW FROM STAFF_INFO WHERE STAFF_NO = @STAFF_NO";

        public static string SEL_23 = "SELECT shain_email from m_cs_shain where shain_code = @shain_code";

        public static string INS_01 = "insert admin_info (admin_id, admin_name, admin_pw, admin_level, admin_flg , admin_regist_ymd, admin_upd_ymd) values (@admin_id, @admin_name, @admin_pw, @admin_level, 1, GETDATE(), GETDATE())";

        public static string DEL_01 = "update admin_info set admin_flg = '0' where admin_id = @admin_id and admin_pw = @admin_pw";

        public static string DEL_02 = "update staff_info set STAFF_STOP = 's' where staff_no = @staff_no";

        public static string DEL_03 = "update recruit_info set company_recruit_sts = 0 where job_no = @job_no";

        public static string DEL_04 = "update job_info set JOB_APPLY_END = 0 where job_no = @job_no";

        public static string DEL_05 = "update company_info set COMPANY_STOP = 's' where company_no = @company_no";

        public static string UDP_01 = "UPDATE ADMIN_INFO SET admin_id = @admin_id, admin_name = @admin_name, admin_pw = @admin_pw, admin_level = @admin_level, admin_upd_ymd = GETDATE() where admin_id = @vadmin_id and admin_pw = @vadmin_pw";

        public static string UDP_02 = "UPDATE COMPANY_INFO SET COMPANY_MAIL_SEND_YMD_OLD = @COMPANY_MAIL_SEND_YMD_OLD, COMPANY_MAIL_SEND_CON_OLD = @COMPANY_MAIL_SEND_CON_OLD WHERE COMPANY_NO = @COMPANY_NO";

        public static string UDP_03 = "UPDATE STAFF_INFO SET STAFF_MAIL_SEND_YMD_OLD = @STAFF_MAIL_SEND_YMD_OLD, STAFF_MAIL_SEND_CON_OLD = @STAFF_MAIL_SEND_CON_OLD WHERE STAFF_NO = @STAFF_NO";

        public static string UDP_04 = "UPDATE COMPANY_INFO SET COMPANY_MAIL_SEND_YMD_NEW = @COMPANY_MAIL_SEND_YMD_NEW, COMPANY_MAIL_SEND_CON_NEW = @COMPANY_MAIL_SEND_CON_NEW WHERE COMPANY_NO = @COMPANY_NO";

        public static string UDP_05 = "UPDATE STAFF_INFO SET STAFF_MAIL_SEND_YMD_NEW = @STAFF_MAIL_SEND_YMD_NEW, STAFF_MAIL_SEND_CON_NEW = @STAFF_MAIL_SEND_CON_NEW WHERE STAFF_NO = @STAFF_NO";
    }
}
