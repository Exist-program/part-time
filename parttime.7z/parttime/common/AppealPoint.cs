﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace parttime.common
{
    class AppealPoint
    {
        static string[][] AppealPointList = new string[][]{
                 new string[]{"A01", "好きな時間に働ける"}
                ,new string[]{"A02", "土日だけでOK"}
                ,new string[]{"A03", "土日、祝日休み"}
                ,new string[]{"A04", "短い期間OK"}
                ,new string[]{"A05", "3ヶ月以上働ける"}
                ,new string[]{"A06", "すぐに働ける"}
                ,new string[]{"A07", "学歴不問"}
                ,new string[]{"A08", "時給1,200円以上"}
                ,new string[]{"A09", "会社内の割引制度あり"}
                ,new string[]{"A10", "経験者・資格ある人歓迎"}
                ,new string[]{"A11", "すぐ支払い＜その日、週＞"}

                ,new string[]{"B01", "駅から近い（3分以内）"}
                ,new string[]{"B02", "食事あり"}
                ,new string[]{"B03", "語学を生かす（母国語）"}
                ,new string[]{"B04", "外国人採用したことあり"}
                ,new string[]{"B05", "制服貸します"}
                ,new string[]{"B06", "服自由"}
                ,new string[]{"B07", "ヘアスタイル自由"}
                ,new string[]{"B08", "ヘアカラー自由"}
                ,new string[]{"B09", "ピアスOK"}
                ,new string[]{"B10", "ひげOK"}      
        };


        /// <summary>
        /// コードリストをテキストリストに変換
        /// </summary>
        /// <param name="codelist">000,000,</param>
        /// <returns>text,text,</returns>
        public static string getTextListFromCodeList(string codelist)
        {
            for (int i = 0; i < AppealPointList.Length; i++)
            {
                codelist = codelist.Replace(AppealPointList[i][0], AppealPointList[i][1]);
            }
            return codelist;
        }

    }
}
