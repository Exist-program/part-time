﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace parttime.common
{
    class MappingLists
    {

        // 国家マッピング
        public static string nationListMapping(string code)
        {

            string name = null;

            for (int i = 1; i < NationList.codeKuniList.Length; i++)
            {

                if (NationList.codeKuniList[i] == code)
                {

                    name = NationList.nameKuniList[i];
                    break;
                }
            }

            return name;

        }

        // 母国語マッピング
        public static string nativeListMapping(string code)
        {

            string name = null;

            for (int i = 1; i < Mothertongue.codeLangList.Length; i++)
            {

                if (Mothertongue.codeLangList[i] == code)
                {

                    name = Mothertongue.nameLangList[i];
                    break;
                }
            }

            return name;

        }

        // 都道府県 マッピング
        public static string todoListMapping(string code)
        {

            string name = null;

            for (int i = 1; i < TodoList.codeTodoList.Length; i++)
            {

                if (TodoList.codeTodoList[i] == code)
                {

                    name = TodoList.nameTodoList[i];
                    break;
                }
            }

            return name;

        }

        public static string salTainListMapping(string typeCode, string code)
        {

            string ret = null;

            if (SalType.codeSalType1.Equals(typeCode))
            {

                if (SalTani.codeSalTaniTime1.Equals(code))
                {

                    ret = SalTani.nameSalTaniTime1;

                }
                else if (SalTani.codeSalTaniTime2.Equals(code))
                {

                    ret = SalTani.nameSalTaniTime2;

                }
                else if (SalTani.codeSalTaniTime3.Equals(code))
                {

                    ret = SalTani.nameSalTaniTime3;

                }
                else if (SalTani.codeSalTaniTime4.Equals(code))
                {

                    ret = SalTani.nameSalTaniTime4;

                }
                else if (SalTani.codeSalTaniTime5.Equals(code))
                {

                    ret = SalTani.nameSalTaniTime5;
                }
                else if (SalTani.codeSalTaniTime6.Equals(code))
                {

                    ret = SalTani.nameSalTaniTime6;
                }

            }
            else if (SalType.codeSalType2.Equals(typeCode))
            {

                if (SalTani.codeSalTaniDate1.Equals(code))
                {

                    ret = SalTani.nameSalTaniDate1;

                }
                else if (SalTani.codeSalTaniDate2.Equals(code))
                {

                    ret = SalTani.nameSalTaniDate2;

                }
                else if (SalTani.codeSalTaniDate3.Equals(code))
                {

                    ret = SalTani.nameSalTaniDate3;

                }
                else if (SalTani.codeSalTaniDate4.Equals(code))
                {

                    ret = SalTani.nameSalTaniDate4;

                }
                else if (SalTani.codeSalTaniDate5.Equals(code))
                {

                    ret = SalTani.nameSalTaniDate5;
                }
                else if (SalTani.codeSalTaniDate6.Equals(code))
                {

                    ret = SalTani.nameSalTaniDate6;
                }
                else if (SalTani.codeSalTaniDate7.Equals(code))
                {

                    ret = SalTani.nameSalTaniDate7;
                }

            }
            else if (SalType.codeSalType3.Equals(typeCode))
            {

                if (SalTani.codeSalTaniMonth1.Equals(code))
                {

                    ret = SalTani.nameSalTaniMonth1;

                }
                else if (SalTani.codeSalTaniMonth2.Equals(code))
                {

                    ret = SalTani.nameSalTaniMonth2;

                }
                else if (SalTani.codeSalTaniMonth3.Equals(code))
                {

                    ret = SalTani.nameSalTaniMonth3;

                }
                else if (SalTani.codeSalTaniMonth4.Equals(code))
                {

                    ret = SalTani.nameSalTaniMonth4;

                }
                else if (SalTani.codeSalTaniMonth5.Equals(code))
                {

                    ret = SalTani.nameSalTaniMonth5;
                }

            }

            return ret;
        }

        public static string salTypeListMapping(string code)
        {

            string ret = null;

            if (SalType.codeSalType1.Equals(code))
            {

                ret = SalType.nameSalType1;
            }
            else if (SalType.codeSalType2.Equals(code))
            {
                ret = SalType.nameSalType2;
            }
            else if (SalType.codeSalType3.Equals(code))
            {
                ret = SalType.nameSalType3;
            }

            return ret;
        }

        public static string timeListMapping(DataSet ds, int i)
        {
            ArrayList list = new ArrayList();

            if (ds.Tables[0].Rows[i]["job_time1"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                list.Add(CodeMaster.checkBoxTime1);
            }

            if (ds.Tables[0].Rows[i]["job_time2"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                list.Add(CodeMaster.checkBoxTime2);
            }

            if (ds.Tables[0].Rows[i]["job_time3"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                list.Add(CodeMaster.checkBoxTime3);
            }

            if (ds.Tables[0].Rows[i]["job_time4"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                list.Add(CodeMaster.checkBoxTime4);
            }

            if (ds.Tables[0].Rows[i]["job_time5"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                list.Add(CodeMaster.checkBoxTime5);
            }

            if (ds.Tables[0].Rows[i]["job_time6"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                list.Add(CodeMaster.checkBoxTime6);
            }

            if (ds.Tables[0].Rows[i]["job_time7"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                list.Add(CodeMaster.checkBoxTime7);
            }

            if (ds.Tables[0].Rows[i]["job_time8"].ToString().Equals(CodeMaster.ChkBoxYes))
            {
                list.Add(CodeMaster.checkBoxTime8);
            }

            StringBuilder sb = new StringBuilder();

            for (int k = 0; k < list.Count; k++)
            {

                sb.Append((String)list[k]);

                if (list.Count - 1 != k)
                {

                    sb.Append("  、");
                }
            }

            return sb.ToString();
        }
    }
}
