﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class NationList
    {
        // 国家名
        static public string nameKuni000 = "▼国籍";
        static public string nameKuni001 = "日本";
        static public string nameKuni002 = "インド";
        static public string nameKuni003 = "インドネシア";
        static public string nameKuni004 = "カンボジア";
        static public string nameKuni005 = "シンガポール";
        static public string nameKuni006 = "スリランカ";
        static public string nameKuni007 = "タイ";
        static public string nameKuni008 = "韓国";
        static public string nameKuni009 = "中国";
        static public string nameKuni010 = "北朝鮮";
        static public string nameKuni011 = "ネパール";
        static public string nameKuni012 = "パキスタン";
        static public string nameKuni013 = "バングラデシュ";
        static public string nameKuni014 = "東ティモール";
        static public string nameKuni015 = "フィリピン";
        static public string nameKuni016 = "ブータン";
        static public string nameKuni017 = "ブルネイ";
        static public string nameKuni018 = "ベトナム";
        static public string nameKuni019 = "マレーシア";
        static public string nameKuni020 = "ミャンマー";
        static public string nameKuni021 = "モルディブ";
        static public string nameKuni022 = "モンゴル";
        static public string nameKuni023 = "ラオス";
        static public string nameKuni024 = "オーストラリア";
        static public string nameKuni025 = "キリバス";
        static public string nameKuni026 = "サモア";
        static public string nameKuni027 = "ソロモン諸島";
        static public string nameKuni028 = "ツバル";
        static public string nameKuni029 = "トンガ";
        static public string nameKuni030 = "ナウル";
        static public string nameKuni031 = "ニュージーランド";
        static public string nameKuni032 = "バヌアツ";
        static public string nameKuni033 = "パプアニューギニア";
        static public string nameKuni034 = "パラオ";
        static public string nameKuni035 = "フィジー諸島";
        static public string nameKuni036 = "マーシャル諸島";
        static public string nameKuni037 = "ミクロネシア";
        static public string nameKuni038 = "アイスランド";
        static public string nameKuni039 = "アイルランド";
        static public string nameKuni040 = "アゼルバイジャン";
        static public string nameKuni041 = "アルバニア";
        static public string nameKuni042 = "アルメニア";
        static public string nameKuni043 = "アンドラ";
        static public string nameKuni044 = "イタリア";
        static public string nameKuni045 = "ウクライナ";
        static public string nameKuni046 = "ウズベキスタン";
        static public string nameKuni047 = "エストニア";
        static public string nameKuni048 = "オーストリア";
        static public string nameKuni049 = "オランダ";
        static public string nameKuni050 = "カザフスタン";
        static public string nameKuni051 = "キプロス";
        static public string nameKuni052 = "ギリシャ";
        static public string nameKuni053 = "キルギス";
        static public string nameKuni054 = "グルジア";
        static public string nameKuni055 = "イギリス";
        static public string nameKuni056 = "クロアチア";
        static public string nameKuni057 = "サンマリノ";
        static public string nameKuni058 = "スイス";
        static public string nameKuni059 = "スウェーデン";
        static public string nameKuni060 = "スペイン";
        static public string nameKuni061 = "スロバキア";
        static public string nameKuni062 = "スロベニア";
        static public string nameKuni063 = "セルビア";
        static public string nameKuni064 = "タジキスタン";
        static public string nameKuni065 = "チェコ";
        static public string nameKuni066 = "デンマーク";
        static public string nameKuni067 = "ドイツ";
        static public string nameKuni068 = "トルクメニスタン";
        static public string nameKuni069 = "ノルウェー";
        static public string nameKuni070 = "バチカン";
        static public string nameKuni071 = "ハンガリー";
        static public string nameKuni072 = "フィンランド";
        static public string nameKuni073 = "フランス";
        static public string nameKuni074 = "ブルガリア";
        static public string nameKuni075 = "ベラルーシ";
        static public string nameKuni076 = "ベルギー";
        static public string nameKuni077 = "ボスニアヘルツェゴビナ";
        static public string nameKuni078 = "ポーランド";
        static public string nameKuni079 = "ポルトガル";
        static public string nameKuni080 = "マケドニア";
        static public string nameKuni081 = "マルタ";
        static public string nameKuni082 = "モナコ";
        static public string nameKuni083 = "モルドバ";
        static public string nameKuni084 = "モンテネグロ";
        static public string nameKuni085 = "ラトビア";
        static public string nameKuni086 = "リトアニア";
        static public string nameKuni087 = "リヒテンシュタイン";
        static public string nameKuni088 = "ルクセンブルク";
        static public string nameKuni089 = "ルーマニア";
        static public string nameKuni090 = "ロシア";
        static public string nameKuni091 = "アメリカ合衆国";
        static public string nameKuni092 = "カナダ";
        static public string nameKuni093 = "アルゼンチン";
        static public string nameKuni094 = "アンティグアバーブーダ";
        static public string nameKuni095 = "ウルグアイ";
        static public string nameKuni096 = "エクアドル";
        static public string nameKuni097 = "エルサルバドル";
        static public string nameKuni098 = "ガイアナ";
        static public string nameKuni099 = "キューバ";
        static public string nameKuni100 = "グアテマラ";
        static public string nameKuni101 = "グレナダ";
        static public string nameKuni102 = "コスタリカ";
        static public string nameKuni103 = "コロンビア";
        static public string nameKuni104 = "ジャマイカ";
        static public string nameKuni105 = "スリナム";
        static public string nameKuni106 = "セントルシア";
        static public string nameKuni107 = "チリ";
        static public string nameKuni108 = "ドミニカ共和国";
        static public string nameKuni109 = "トリニダード・トバゴ";
        static public string nameKuni110 = "ニカラグア";
        static public string nameKuni111 = "ハイチ";
        static public string nameKuni112 = "パナマ";
        static public string nameKuni113 = "バハマ";
        static public string nameKuni114 = "パラグアイ";
        static public string nameKuni115 = "バルバドス";
        static public string nameKuni116 = "ブラジル";
        static public string nameKuni117 = "ベネズエラ";
        static public string nameKuni118 = "ベリーズ";
        static public string nameKuni119 = "ペルー";
        static public string nameKuni120 = "ボリビア";
        static public string nameKuni121 = "ホンジュラス";
        static public string nameKuni122 = "メキシコ";
        static public string nameKuni123 = "アフガニスタン";
        static public string nameKuni124 = "アラブ首長国連邦";
        static public string nameKuni125 = "イエメン";
        static public string nameKuni126 = "イスラエル";
        static public string nameKuni127 = "イラク";
        static public string nameKuni128 = "イラン";
        static public string nameKuni129 = "オマーン";
        static public string nameKuni130 = "カタール";
        static public string nameKuni131 = "クウェート";
        static public string nameKuni132 = "サウジアラビア";
        static public string nameKuni133 = "シリア";
        static public string nameKuni134 = "トルコ";
        static public string nameKuni135 = "バーレーン";
        static public string nameKuni136 = "ヨルダン";
        static public string nameKuni137 = "レバノン";
        static public string nameKuni138 = "アルジェリア";
        static public string nameKuni139 = "アンゴラ";
        static public string nameKuni140 = "ウガンダ";
        static public string nameKuni141 = "エジプト";
        static public string nameKuni142 = "エチオピア";
        static public string nameKuni143 = "エリトリア";
        static public string nameKuni144 = "ガーナ";
        static public string nameKuni145 = "カーボヴェルデ";
        static public string nameKuni146 = "ガボン";
        static public string nameKuni147 = "カメルーン";
        static public string nameKuni148 = "ガンビア";
        static public string nameKuni149 = "ギニア";
        static public string nameKuni150 = "ケニア";
        static public string nameKuni151 = "コートジボワール";
        static public string nameKuni152 = "コモロ";
        static public string nameKuni153 = "コンゴ";
        static public string nameKuni154 = "サントメ・プリンシペ";
        static public string nameKuni155 = "ザンビア";
        static public string nameKuni156 = "シエラレオネ";
        static public string nameKuni157 = "ジブチ";
        static public string nameKuni158 = "リビア";
        static public string nameKuni159 = "ジンバブエ";
        static public string nameKuni160 = "スーダン";
        static public string nameKuni161 = "スワジランド";
        static public string nameKuni162 = "セーシェル";
        static public string nameKuni163 = "セネガル";
        static public string nameKuni164 = "ソマリア";
        static public string nameKuni165 = "タンザニア";
        static public string nameKuni166 = "チャド";
        static public string nameKuni167 = "中央アフリカ";
        static public string nameKuni168 = "チュニジア";
        static public string nameKuni169 = "トーゴ";
        static public string nameKuni170 = "ナイジェリア";
        static public string nameKuni171 = "ナミビア";
        static public string nameKuni172 = "ニジェール";
        static public string nameKuni173 = "ブルキナファソ";
        static public string nameKuni174 = "ブルンジ";
        static public string nameKuni175 = "ベナン";
        static public string nameKuni176 = "ボツワナ";
        static public string nameKuni177 = "マダガスカル";
        static public string nameKuni178 = "マラウイ";
        static public string nameKuni179 = "マリ";
        static public string nameKuni180 = "南アフリカ";
        static public string nameKuni181 = "モザンビーク";
        static public string nameKuni182 = "モーリシャス";
        static public string nameKuni183 = "モーリタニア";
        static public string nameKuni184 = "モロッコ";
        static public string nameKuni185 = "リベリア";
        static public string nameKuni186 = "ルワンダ";
        static public string nameKuni187 = "レソト";
        static public string nameKuni188 = "香港";
        static public string nameKuni189 = "台湾";
        static public string nameKuni190 = "ドミニカ";

        // 国家コード
        static public string codeKuniE000 = "000";
        static public string codeKuniE001 = "001";
        static public string codeKuniE002 = "002";
        static public string codeKuniE003 = "003";
        static public string codeKuniE004 = "004";
        static public string codeKuniE005 = "005";
        static public string codeKuniE006 = "006";
        static public string codeKuniE007 = "007";
        static public string codeKuniE008 = "008";
        static public string codeKuniE009 = "009";
        static public string codeKuniE010 = "010";
        static public string codeKuniE011 = "011";
        static public string codeKuniE012 = "012";
        static public string codeKuniE013 = "013";
        static public string codeKuniE014 = "014";
        static public string codeKuniE015 = "015";
        static public string codeKuniE016 = "016";
        static public string codeKuniE017 = "017";
        static public string codeKuniE018 = "018";
        static public string codeKuniE019 = "019";
        static public string codeKuniE020 = "020";
        static public string codeKuniE021 = "021";
        static public string codeKuniE022 = "022";
        static public string codeKuniE023 = "023";
        static public string codeKuniE024 = "024";
        static public string codeKuniE025 = "025";
        static public string codeKuniE026 = "026";
        static public string codeKuniE027 = "027";
        static public string codeKuniE028 = "028";
        static public string codeKuniE029 = "029";
        static public string codeKuniE030 = "030";
        static public string codeKuniE031 = "031";
        static public string codeKuniE032 = "032";
        static public string codeKuniE033 = "033";
        static public string codeKuniE034 = "034";
        static public string codeKuniE035 = "035";
        static public string codeKuniE036 = "036";
        static public string codeKuniE037 = "037";
        static public string codeKuniE038 = "038";
        static public string codeKuniE039 = "039";
        static public string codeKuniE040 = "040";
        static public string codeKuniE041 = "041";
        static public string codeKuniE042 = "042";
        static public string codeKuniE043 = "043";
        static public string codeKuniE044 = "044";
        static public string codeKuniE045 = "045";
        static public string codeKuniE046 = "046";
        static public string codeKuniE047 = "047";
        static public string codeKuniE048 = "048";
        static public string codeKuniE049 = "049";
        static public string codeKuniE050 = "050";
        static public string codeKuniE051 = "051";
        static public string codeKuniE052 = "052";
        static public string codeKuniE053 = "053";
        static public string codeKuniE054 = "054";
        static public string codeKuniE055 = "055";
        static public string codeKuniE056 = "056";
        static public string codeKuniE057 = "057";
        static public string codeKuniE058 = "058";
        static public string codeKuniE059 = "059";
        static public string codeKuniE060 = "060";
        static public string codeKuniE061 = "061";
        static public string codeKuniE062 = "062";
        static public string codeKuniE063 = "063";
        static public string codeKuniE064 = "064";
        static public string codeKuniE065 = "065";
        static public string codeKuniE066 = "066";
        static public string codeKuniE067 = "067";
        static public string codeKuniE068 = "068";
        static public string codeKuniE069 = "069";
        static public string codeKuniE070 = "070";
        static public string codeKuniE071 = "071";
        static public string codeKuniE072 = "072";
        static public string codeKuniE073 = "073";
        static public string codeKuniE074 = "074";
        static public string codeKuniE075 = "075";
        static public string codeKuniE076 = "076";
        static public string codeKuniE077 = "077";
        static public string codeKuniE078 = "078";
        static public string codeKuniE079 = "079";
        static public string codeKuniE080 = "080";
        static public string codeKuniE081 = "081";
        static public string codeKuniE082 = "082";
        static public string codeKuniE083 = "083";
        static public string codeKuniE084 = "084";
        static public string codeKuniE085 = "085";
        static public string codeKuniE086 = "086";
        static public string codeKuniE087 = "087";
        static public string codeKuniE088 = "088";
        static public string codeKuniE089 = "089";
        static public string codeKuniE090 = "090";
        static public string codeKuniE091 = "091";
        static public string codeKuniE092 = "092";
        static public string codeKuniE093 = "093";
        static public string codeKuniE094 = "094";
        static public string codeKuniE095 = "095";
        static public string codeKuniE096 = "096";
        static public string codeKuniE097 = "097";
        static public string codeKuniE098 = "098";
        static public string codeKuniE099 = "099";
        static public string codeKuniE100 = "100";
        static public string codeKuniE101 = "101";
        static public string codeKuniE102 = "102";
        static public string codeKuniE103 = "103";
        static public string codeKuniE104 = "104";
        static public string codeKuniE105 = "105";
        static public string codeKuniE106 = "106";
        static public string codeKuniE107 = "107";
        static public string codeKuniE108 = "108";
        static public string codeKuniE109 = "109";
        static public string codeKuniE110 = "110";
        static public string codeKuniE111 = "111";
        static public string codeKuniE112 = "112";
        static public string codeKuniE113 = "113";
        static public string codeKuniE114 = "114";
        static public string codeKuniE115 = "115";
        static public string codeKuniE116 = "116";
        static public string codeKuniE117 = "117";
        static public string codeKuniE118 = "118";
        static public string codeKuniE119 = "119";
        static public string codeKuniE120 = "120";
        static public string codeKuniE121 = "121";
        static public string codeKuniE122 = "122";
        static public string codeKuniE123 = "123";
        static public string codeKuniE124 = "124";
        static public string codeKuniE125 = "125";
        static public string codeKuniE126 = "126";
        static public string codeKuniE127 = "127";
        static public string codeKuniE128 = "128";
        static public string codeKuniE129 = "129";
        static public string codeKuniE130 = "130";
        static public string codeKuniE131 = "131";
        static public string codeKuniE132 = "132";
        static public string codeKuniE133 = "133";
        static public string codeKuniE134 = "134";
        static public string codeKuniE135 = "135";
        static public string codeKuniE136 = "136";
        static public string codeKuniE137 = "137";
        static public string codeKuniE138 = "138";
        static public string codeKuniE139 = "139";
        static public string codeKuniE140 = "140";
        static public string codeKuniE141 = "141";
        static public string codeKuniE142 = "142";
        static public string codeKuniE143 = "143";
        static public string codeKuniE144 = "144";
        static public string codeKuniE145 = "145";
        static public string codeKuniE146 = "146";
        static public string codeKuniE147 = "147";
        static public string codeKuniE148 = "148";
        static public string codeKuniE149 = "149";
        static public string codeKuniE150 = "150";
        static public string codeKuniE151 = "151";
        static public string codeKuniE152 = "152";
        static public string codeKuniE153 = "153";
        static public string codeKuniE154 = "154";
        static public string codeKuniE155 = "155";
        static public string codeKuniE156 = "156";
        static public string codeKuniE157 = "157";
        static public string codeKuniE158 = "158";
        static public string codeKuniE159 = "159";
        static public string codeKuniE160 = "160";
        static public string codeKuniE161 = "161";
        static public string codeKuniE162 = "162";
        static public string codeKuniE163 = "163";
        static public string codeKuniE164 = "164";
        static public string codeKuniE165 = "165";
        static public string codeKuniE166 = "166";
        static public string codeKuniE167 = "167";
        static public string codeKuniE168 = "168";
        static public string codeKuniE169 = "169";
        static public string codeKuniE170 = "170";
        static public string codeKuniE171 = "171";
        static public string codeKuniE172 = "172";
        static public string codeKuniE173 = "173";
        static public string codeKuniE174 = "174";
        static public string codeKuniE175 = "175";
        static public string codeKuniE176 = "176";
        static public string codeKuniE177 = "177";
        static public string codeKuniE178 = "178";
        static public string codeKuniE179 = "179";
        static public string codeKuniE180 = "180";
        static public string codeKuniE181 = "181";
        static public string codeKuniE182 = "182";
        static public string codeKuniE183 = "183";
        static public string codeKuniE184 = "184";
        static public string codeKuniE185 = "185";
        static public string codeKuniE186 = "186";
        static public string codeKuniE187 = "187";
        static public string codeKuniE188 = "188";
        static public string codeKuniE189 = "189";
        static public string codeKuniE190 = "190";

        public static string[] nameKuniList = new string[] {

           NationList.nameKuni000,
           NationList.nameKuni001,
           NationList.nameKuni002,
           NationList.nameKuni003,
           NationList.nameKuni004,
           NationList.nameKuni005,
           NationList.nameKuni006,
           NationList.nameKuni007,
           NationList.nameKuni008,
           NationList.nameKuni009,
           NationList.nameKuni010,
           NationList.nameKuni011,
           NationList.nameKuni012,
           NationList.nameKuni013,
           NationList.nameKuni014,
           NationList.nameKuni015,
           NationList.nameKuni016,
           NationList.nameKuni017,
           NationList.nameKuni018,
           NationList.nameKuni019,
           NationList.nameKuni020,
           NationList.nameKuni021,
           NationList.nameKuni022,
           NationList.nameKuni023,
           NationList.nameKuni024,
           NationList.nameKuni025,
           NationList.nameKuni026,
           NationList.nameKuni027,
           NationList.nameKuni028,
           NationList.nameKuni029,
           NationList.nameKuni030,
           NationList.nameKuni031,
           NationList.nameKuni032,
           NationList.nameKuni033,
           NationList.nameKuni034,
           NationList.nameKuni035,
           NationList.nameKuni036,
           NationList.nameKuni037,
           NationList.nameKuni038,
           NationList.nameKuni039,
           NationList.nameKuni040,
           NationList.nameKuni041,
           NationList.nameKuni042,
           NationList.nameKuni043,
           NationList.nameKuni044,
           NationList.nameKuni045,
           NationList.nameKuni046,
           NationList.nameKuni047,
           NationList.nameKuni048,
           NationList.nameKuni049,
           NationList.nameKuni050,
           NationList.nameKuni051,
           NationList.nameKuni052,
           NationList.nameKuni053,
           NationList.nameKuni054,
           NationList.nameKuni055,
           NationList.nameKuni056,
           NationList.nameKuni057,
           NationList.nameKuni058,
           NationList.nameKuni059,
           NationList.nameKuni060,
           NationList.nameKuni061,
           NationList.nameKuni062,
           NationList.nameKuni063,
           NationList.nameKuni064,
           NationList.nameKuni065,
           NationList.nameKuni066,
           NationList.nameKuni067,
           NationList.nameKuni068,
           NationList.nameKuni069,
           NationList.nameKuni070,
           NationList.nameKuni071,
           NationList.nameKuni072,
           NationList.nameKuni073,
           NationList.nameKuni074,
           NationList.nameKuni075,
           NationList.nameKuni076,
           NationList.nameKuni077,
           NationList.nameKuni078,
           NationList.nameKuni079,
           NationList.nameKuni080,
           NationList.nameKuni081,
           NationList.nameKuni082,
           NationList.nameKuni083,
           NationList.nameKuni084,
           NationList.nameKuni085,
           NationList.nameKuni086,
           NationList.nameKuni087,
           NationList.nameKuni088,
           NationList.nameKuni089,
           NationList.nameKuni090,
           NationList.nameKuni091,
           NationList.nameKuni092,
           NationList.nameKuni093,
           NationList.nameKuni094,
           NationList.nameKuni095,
           NationList.nameKuni096,
           NationList.nameKuni097,
           NationList.nameKuni098,
           NationList.nameKuni099,
           NationList.nameKuni100,
           NationList.nameKuni101,
           NationList.nameKuni102,
           NationList.nameKuni103,
           NationList.nameKuni104,
           NationList.nameKuni105,
           NationList.nameKuni106,
           NationList.nameKuni107,
           NationList.nameKuni108,
           NationList.nameKuni109,
           NationList.nameKuni110,
           NationList.nameKuni111,
           NationList.nameKuni112,
           NationList.nameKuni113,
           NationList.nameKuni114,
           NationList.nameKuni115,
           NationList.nameKuni116,
           NationList.nameKuni117,
           NationList.nameKuni118,
           NationList.nameKuni119,
           NationList.nameKuni120,
           NationList.nameKuni121,
           NationList.nameKuni122,
           NationList.nameKuni123,
           NationList.nameKuni124,
           NationList.nameKuni125,
           NationList.nameKuni126,
           NationList.nameKuni127,
           NationList.nameKuni128,
           NationList.nameKuni129,
           NationList.nameKuni130,
           NationList.nameKuni131,
           NationList.nameKuni132,
           NationList.nameKuni133,
           NationList.nameKuni134,
           NationList.nameKuni135,
           NationList.nameKuni136,
           NationList.nameKuni137,
           NationList.nameKuni138,
           NationList.nameKuni139,
           NationList.nameKuni140,
           NationList.nameKuni141,
           NationList.nameKuni142,
           NationList.nameKuni143,
           NationList.nameKuni144,
           NationList.nameKuni145,
           NationList.nameKuni146,
           NationList.nameKuni147,
           NationList.nameKuni148,
           NationList.nameKuni149,
           NationList.nameKuni150,
           NationList.nameKuni151,
           NationList.nameKuni152,
           NationList.nameKuni153,
           NationList.nameKuni154,
           NationList.nameKuni155,
           NationList.nameKuni156,
           NationList.nameKuni157,
           NationList.nameKuni158,
           NationList.nameKuni159,
           NationList.nameKuni160,
           NationList.nameKuni161,
           NationList.nameKuni162,
           NationList.nameKuni163,
           NationList.nameKuni164,
           NationList.nameKuni165,
           NationList.nameKuni166,
           NationList.nameKuni167,
           NationList.nameKuni168,
           NationList.nameKuni169,
           NationList.nameKuni170,
           NationList.nameKuni171,
           NationList.nameKuni172,
           NationList.nameKuni173,
           NationList.nameKuni174,
           NationList.nameKuni175,
           NationList.nameKuni176,
           NationList.nameKuni177,
           NationList.nameKuni178,
           NationList.nameKuni179,
           NationList.nameKuni180,
           NationList.nameKuni181,
           NationList.nameKuni182,
           NationList.nameKuni183,
           NationList.nameKuni184,
           NationList.nameKuni185,
           NationList.nameKuni186,
           NationList.nameKuni187,
           NationList.nameKuni188,
           NationList.nameKuni189,
           NationList.nameKuni190
    };

        public static string[] codeKuniList = new string[] {
    
           NationList.codeKuniE000,
           NationList.codeKuniE001,
           NationList.codeKuniE002,
           NationList.codeKuniE003,
           NationList.codeKuniE004,
           NationList.codeKuniE005,
           NationList.codeKuniE006,
           NationList.codeKuniE007,
           NationList.codeKuniE008,
           NationList.codeKuniE009,
           NationList.codeKuniE010,
           NationList.codeKuniE011,
           NationList.codeKuniE012,
           NationList.codeKuniE013,
           NationList.codeKuniE014,
           NationList.codeKuniE015,
           NationList.codeKuniE016,
           NationList.codeKuniE017,
           NationList.codeKuniE018,
           NationList.codeKuniE019,
           NationList.codeKuniE020,
           NationList.codeKuniE021,
           NationList.codeKuniE022,
           NationList.codeKuniE023,
           NationList.codeKuniE024,
           NationList.codeKuniE025,
           NationList.codeKuniE026,
           NationList.codeKuniE027,
           NationList.codeKuniE028,
           NationList.codeKuniE029,
           NationList.codeKuniE030,
           NationList.codeKuniE031,
           NationList.codeKuniE032,
           NationList.codeKuniE033,
           NationList.codeKuniE034,
           NationList.codeKuniE035,
           NationList.codeKuniE036,
           NationList.codeKuniE037,
           NationList.codeKuniE038,
           NationList.codeKuniE039,
           NationList.codeKuniE040,
           NationList.codeKuniE041,
           NationList.codeKuniE042,
           NationList.codeKuniE043,
           NationList.codeKuniE044,
           NationList.codeKuniE045,
           NationList.codeKuniE046,
           NationList.codeKuniE047,
           NationList.codeKuniE048,
           NationList.codeKuniE049,
           NationList.codeKuniE050,
           NationList.codeKuniE051,
           NationList.codeKuniE052,
           NationList.codeKuniE053,
           NationList.codeKuniE054,
           NationList.codeKuniE055,
           NationList.codeKuniE056,
           NationList.codeKuniE057,
           NationList.codeKuniE058,
           NationList.codeKuniE059,
           NationList.codeKuniE060,
           NationList.codeKuniE061,
           NationList.codeKuniE062,
           NationList.codeKuniE063,
           NationList.codeKuniE064,
           NationList.codeKuniE065,
           NationList.codeKuniE066,
           NationList.codeKuniE067,
           NationList.codeKuniE068,
           NationList.codeKuniE069,
           NationList.codeKuniE070,
           NationList.codeKuniE071,
           NationList.codeKuniE072,
           NationList.codeKuniE073,
           NationList.codeKuniE074,
           NationList.codeKuniE075,
           NationList.codeKuniE076,
           NationList.codeKuniE077,
           NationList.codeKuniE078,
           NationList.codeKuniE079,
           NationList.codeKuniE080,
           NationList.codeKuniE081,
           NationList.codeKuniE082,
           NationList.codeKuniE083,
           NationList.codeKuniE084,
           NationList.codeKuniE085,
           NationList.codeKuniE086,
           NationList.codeKuniE087,
           NationList.codeKuniE088,
           NationList.codeKuniE089,
           NationList.codeKuniE090,
           NationList.codeKuniE091,
           NationList.codeKuniE092,
           NationList.codeKuniE093,
           NationList.codeKuniE094,
           NationList.codeKuniE095,
           NationList.codeKuniE096,
           NationList.codeKuniE097,
           NationList.codeKuniE098,
           NationList.codeKuniE099,
           NationList.codeKuniE100,
           NationList.codeKuniE101,
           NationList.codeKuniE102,
           NationList.codeKuniE103,
           NationList.codeKuniE104,
           NationList.codeKuniE105,
           NationList.codeKuniE106,
           NationList.codeKuniE107,
           NationList.codeKuniE108,
           NationList.codeKuniE109,
           NationList.codeKuniE110,
           NationList.codeKuniE111,
           NationList.codeKuniE112,
           NationList.codeKuniE113,
           NationList.codeKuniE114,
           NationList.codeKuniE115,
           NationList.codeKuniE116,
           NationList.codeKuniE117,
           NationList.codeKuniE118,
           NationList.codeKuniE119,
           NationList.codeKuniE120,
           NationList.codeKuniE121,
           NationList.codeKuniE122,
           NationList.codeKuniE123,
           NationList.codeKuniE124,
           NationList.codeKuniE125,
           NationList.codeKuniE126,
           NationList.codeKuniE127,
           NationList.codeKuniE128,
           NationList.codeKuniE129,
           NationList.codeKuniE130,
           NationList.codeKuniE131,
           NationList.codeKuniE132,
           NationList.codeKuniE133,
           NationList.codeKuniE134,
           NationList.codeKuniE135,
           NationList.codeKuniE136,
           NationList.codeKuniE137,
           NationList.codeKuniE138,
           NationList.codeKuniE139,
           NationList.codeKuniE140,
           NationList.codeKuniE141,
           NationList.codeKuniE142,
           NationList.codeKuniE143,
           NationList.codeKuniE144,
           NationList.codeKuniE145,
           NationList.codeKuniE146,
           NationList.codeKuniE147,
           NationList.codeKuniE148,
           NationList.codeKuniE149,
           NationList.codeKuniE150,
           NationList.codeKuniE151,
           NationList.codeKuniE152,
           NationList.codeKuniE153,
           NationList.codeKuniE154,
           NationList.codeKuniE155,
           NationList.codeKuniE156,
           NationList.codeKuniE157,
           NationList.codeKuniE158,
           NationList.codeKuniE159,
           NationList.codeKuniE160,
           NationList.codeKuniE161,
           NationList.codeKuniE162,
           NationList.codeKuniE163,
           NationList.codeKuniE164,
           NationList.codeKuniE165,
           NationList.codeKuniE166,
           NationList.codeKuniE167,
           NationList.codeKuniE168,
           NationList.codeKuniE169,
           NationList.codeKuniE170,
           NationList.codeKuniE171,
           NationList.codeKuniE172,
           NationList.codeKuniE173,
           NationList.codeKuniE174,
           NationList.codeKuniE175,
           NationList.codeKuniE176,
           NationList.codeKuniE177,
           NationList.codeKuniE178,
           NationList.codeKuniE179,
           NationList.codeKuniE180,
           NationList.codeKuniE181,
           NationList.codeKuniE182,
           NationList.codeKuniE183,
           NationList.codeKuniE184,
           NationList.codeKuniE185,
           NationList.codeKuniE186,
           NationList.codeKuniE187,
           NationList.codeKuniE188,
           NationList.codeKuniE189,
           NationList.codeKuniE190,
    };
    }
}
