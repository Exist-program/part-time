﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class TodoList
    {

        // 都道府県名
        static public string nameTodo00 = "▼都道府県";
        static public string nameTodo01 = "北海道";
        static public string nameTodo02 = "青森県";
        static public string nameTodo03 = "岩手県";
        static public string nameTodo04 = "宮城県";
        static public string nameTodo05 = "秋田県";
        static public string nameTodo06 = "山形県";
        static public string nameTodo07 = "福島県";
        static public string nameTodo08 = "茨城県";
        static public string nameTodo09 = "栃木県";
        static public string nameTodo10 = "群馬県";
        static public string nameTodo11 = "埼玉県";
        static public string nameTodo12 = "千葉県";
        static public string nameTodo13 = "東京都";
        static public string nameTodo14 = "神奈川県";
        static public string nameTodo15 = "新潟県";
        static public string nameTodo16 = "富山県";
        static public string nameTodo17 = "石川県";
        static public string nameTodo18 = "福井県";
        static public string nameTodo19 = "山梨県";
        static public string nameTodo20 = "長野県";
        static public string nameTodo21 = "岐阜県";
        static public string nameTodo22 = "静岡県";
        static public string nameTodo23 = "愛知県";
        static public string nameTodo24 = "三重県";
        static public string nameTodo25 = "滋賀県";
        static public string nameTodo26 = "京都府";
        static public string nameTodo27 = "大阪府";
        static public string nameTodo28 = "兵庫県";
        static public string nameTodo29 = "奈良県";
        static public string nameTodo30 = "和歌山県";
        static public string nameTodo31 = "鳥取県";
        static public string nameTodo32 = "島根県";
        static public string nameTodo33 = "岡山県";
        static public string nameTodo34 = "広島県";
        static public string nameTodo35 = "山口県";
        static public string nameTodo36 = "徳島県";
        static public string nameTodo37 = "香川県";
        static public string nameTodo38 = "愛媛県";
        static public string nameTodo39 = "高知県";
        static public string nameTodo40 = "福岡県";
        static public string nameTodo41 = "佐賀県";
        static public string nameTodo42 = "長崎県";
        static public string nameTodo43 = "熊本県";
        static public string nameTodo44 = "大分県";
        static public string nameTodo45 = "宮崎県";
        static public string nameTodo46 = "鹿児島";
        static public string nameTodo47 = "沖縄県";

        // 都道府県コード
        static public string codeTodo00 = "00";
        static public string codeTodo01 = "01";
        static public string codeTodo02 = "02";
        static public string codeTodo03 = "03";
        static public string codeTodo04 = "04";
        static public string codeTodo05 = "05";
        static public string codeTodo06 = "06";
        static public string codeTodo07 = "07";
        static public string codeTodo08 = "08";
        static public string codeTodo09 = "09";
        static public string codeTodo10 = "10";
        static public string codeTodo11 = "11";
        static public string codeTodo12 = "12";
        static public string codeTodo13 = "13";
        static public string codeTodo14 = "14";
        static public string codeTodo15 = "15";
        static public string codeTodo16 = "16";
        static public string codeTodo17 = "17";
        static public string codeTodo18 = "18";
        static public string codeTodo19 = "19";
        static public string codeTodo20 = "20";
        static public string codeTodo21 = "21";
        static public string codeTodo22 = "22";
        static public string codeTodo23 = "23";
        static public string codeTodo24 = "24";
        static public string codeTodo25 = "25";
        static public string codeTodo26 = "26";
        static public string codeTodo27 = "27";
        static public string codeTodo28 = "28";
        static public string codeTodo29 = "29";
        static public string codeTodo30 = "30";
        static public string codeTodo31 = "31";
        static public string codeTodo32 = "32";
        static public string codeTodo33 = "33";
        static public string codeTodo34 = "34";
        static public string codeTodo35 = "35";
        static public string codeTodo36 = "36";
        static public string codeTodo37 = "37";
        static public string codeTodo38 = "38";
        static public string codeTodo39 = "39";
        static public string codeTodo40 = "40";
        static public string codeTodo41 = "41";
        static public string codeTodo42 = "42";
        static public string codeTodo43 = "43";
        static public string codeTodo44 = "44";
        static public string codeTodo45 = "45";
        static public string codeTodo46 = "46";
        static public string codeTodo47 = "47";
        //   static public string codeTodo90 = "90";
        //   static public string codeTodo91 = "91";
        //   static public string codeTodo92 = "92";
        //   static public string codeTodo93 = "93";

        static public string[] nameTodoList = new string[] {
    
        TodoList.nameTodo00,
        TodoList.nameTodo01,
        TodoList.nameTodo02,
        TodoList.nameTodo03,
        TodoList.nameTodo04,
        TodoList.nameTodo05,
        TodoList.nameTodo06,
        TodoList.nameTodo07,
        TodoList.nameTodo08,
        TodoList.nameTodo09,
        TodoList.nameTodo10,
        TodoList.nameTodo11,
        TodoList.nameTodo12,
        TodoList.nameTodo13,
        TodoList.nameTodo14,
        TodoList.nameTodo15,
        TodoList.nameTodo16,
        TodoList.nameTodo17,
        TodoList.nameTodo18,
        TodoList.nameTodo19,
        TodoList.nameTodo20,
        TodoList.nameTodo21,
        TodoList.nameTodo22,
        TodoList.nameTodo23,
        TodoList.nameTodo24,
        TodoList.nameTodo25,
        TodoList.nameTodo26,
        TodoList.nameTodo27,
        TodoList.nameTodo28,
        TodoList.nameTodo29,
        TodoList.nameTodo30,
        TodoList.nameTodo31,
        TodoList.nameTodo32,
        TodoList.nameTodo33,
        TodoList.nameTodo34,
        TodoList.nameTodo35,
        TodoList.nameTodo36,
        TodoList.nameTodo37,
        TodoList.nameTodo38,
        TodoList.nameTodo39,
        TodoList.nameTodo40,
        TodoList.nameTodo41,
        TodoList.nameTodo42,
        TodoList.nameTodo43,
        TodoList.nameTodo44,
        TodoList.nameTodo45,
        TodoList.nameTodo46,
        TodoList.nameTodo47,
    //    TodoList.nameTodo90,
    //    TodoList.nameTodo91,
    //    TodoList.nameTodo92,
    //    TodoList.nameTodo93
    };

        static public string[] codeTodoList = new string[] {

        TodoList.codeTodo00,
        TodoList.codeTodo01,
        TodoList.codeTodo02,
        TodoList.codeTodo03,
        TodoList.codeTodo04,
        TodoList.codeTodo05,
        TodoList.codeTodo06,
        TodoList.codeTodo07,
        TodoList.codeTodo08,
        TodoList.codeTodo09,
        TodoList.codeTodo10,
        TodoList.codeTodo11,
        TodoList.codeTodo12,
        TodoList.codeTodo13,
        TodoList.codeTodo14,
        TodoList.codeTodo15,
        TodoList.codeTodo16,
        TodoList.codeTodo17,
        TodoList.codeTodo18,
        TodoList.codeTodo19,
        TodoList.codeTodo20,
        TodoList.codeTodo21,
        TodoList.codeTodo22,
        TodoList.codeTodo23,
        TodoList.codeTodo24,
        TodoList.codeTodo25,
        TodoList.codeTodo26,
        TodoList.codeTodo27,
        TodoList.codeTodo28,
        TodoList.codeTodo29,
        TodoList.codeTodo30,
        TodoList.codeTodo31,
        TodoList.codeTodo32,
        TodoList.codeTodo33,
        TodoList.codeTodo34,
        TodoList.codeTodo35,
        TodoList.codeTodo36,
        TodoList.codeTodo37,
        TodoList.codeTodo38,
        TodoList.codeTodo39,
        TodoList.codeTodo40,
        TodoList.codeTodo41,
        TodoList.codeTodo42,
        TodoList.codeTodo43,
        TodoList.codeTodo44,
        TodoList.codeTodo45,
        TodoList.codeTodo46,
        TodoList.codeTodo47,
    //    TodoList.codeTodo90,
    //    TodoList.codeTodo91,
    //    TodoList.codeTodo92,
    //    TodoList.codeTodo93
    };

    }
}
