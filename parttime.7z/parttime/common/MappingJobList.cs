﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class MappingJobList
    {

        public static string JobListMapping(string code)
        {

            string name = null;

            if (code == JobList.codeJobSell1)
            {
                name = JobList.nameJobSell1;
            }
            else if (code == JobList.codeJobSell2)
            {
                name = JobList.nameJobSell2;
            }
            else if (code == JobList.codeJobSell3)
            {
                name = JobList.nameJobSell3;
            }
            else if (code == JobList.codeJobSell4)
            {
                name = JobList.nameJobSell4;
            }
            else if (code == JobList.codeJobSell5)
            {
                name = JobList.nameJobSell5;
            }
            else if (code == JobList.codeJobSell6)
            {
                name = JobList.nameJobSell6;
            }
            else if (code == JobList.codeJobSell7)
            {
                name = JobList.nameJobSell7;
            }
            else if (code == JobList.codeJobSell8)
            {
                name = JobList.nameJobSell8;
            }
            else if (code == JobList.codeJobSell9)
            {
                name = JobList.nameJobSell9;
            }
            else if (code == JobList.codeJobFood1)
            {
                name = JobList.nameJobFood1;
            }
            else if (code == JobList.codeJobFood2)
            {
                name = JobList.nameJobFood2;
            }
            else if (code == JobList.codeJobFood3)
            {
                name = JobList.nameJobFood3;
            }
            else if (code == JobList.codeJobFood4)
            {
                name = JobList.nameJobFood4;
            }
            else if (code == JobList.codeJobFood5)
            {
                name = JobList.nameJobFood5;
            }
            else if (code == JobList.codeJobFood6)
            {
                name = JobList.nameJobFood6;
            }
            else if (code == JobList.codeJobFood7)
            {
                name = JobList.nameJobFood7;
            }
            else if (code == JobList.codeJobFood8)
            {
                name = JobList.nameJobFood8;
            }
            else if (code == JobList.codeJobFood9)
            {
                name = JobList.nameJobFood9;
            }
            else if (code == JobList.codeJobFood10)
            {
                name = JobList.nameJobFood10;
            }
            else if (code == JobList.codeJobService1)
            {
                name = JobList.nameJobService1;
            }
            else if (code == JobList.codeJobService2)
            {
                name = JobList.nameJobService2;
            }
            else if (code == JobList.codeJobService3)
            {
                name = JobList.nameJobService3;
            }
            else if (code == JobList.codeJobService4)
            {
                name = JobList.nameJobService4;
            }
            else if (code == JobList.codeJobService5)
            {
                name = JobList.nameJobService5;
            }
            else if (code == JobList.codeJobService6)
            {
                name = JobList.nameJobService6;
            }
            else if (code == JobList.codeJobService7)
            {
                name = JobList.nameJobService7;
            }
            else if (code == JobList.codeJobAffairs1)
            {
                name = JobList.nameJobAffairs1;
            }
            else if (code == JobList.codeJobAffairs2)
            {
                name = JobList.nameJobAffairs2;
            }
            else if (code == JobList.codeJobAffairs3)
            {
                name = JobList.nameJobAffairs3;
            }
            else if (code == JobList.codeJobAffairs4)
            {
                name = JobList.nameJobAffairs4;
            }
            else if (code == JobList.codeJobAffairs5)
            {
                name = JobList.nameJobAffairs5;
            }
            else if (code == JobList.codeJobAmuse1)
            {
                name = JobList.nameJobAmuse1;
            }
            else if (code == JobList.codeJobAmuse2)
            {
                name = JobList.nameJobAmuse2;
            }
            else if (code == JobList.codeJobAmuse3)
            {
                name = JobList.nameJobAmuse3;
            }
            else if (code == JobList.codeJobAmuse4)
            {
                name = JobList.nameJobAmuse4;
            }
            else if (code == JobList.codeJobAmuse5)
            {
                name = JobList.nameJobAmuse5;
            }
            else if (code == JobList.codeJobIt1)
            {
                name = JobList.nameJobIt1;
            }
            else if (code == JobList.codeJobIt2)
            {
                name = JobList.nameJobIt2;
            }
            else if (code == JobList.codeJobLan1)
            {
                name = JobList.nameJobLan1;
            }
            else if (code == JobList.codeJobLan2)
            {
                name = JobList.nameJobLan2;
            }
            else if (code == JobList.codeJobEvent1)
            {
                name = JobList.nameJobEvent1;
            }
            else if (code == JobList.codeJobFasion1)
            {
                name = JobList.nameJobFasion1;
            }
            else if (code == JobList.codeJobBeauty1)
            {
                name = JobList.nameJobBeauty1;
            }
            else if (code == JobList.codeJobMedical1)
            {
                name = JobList.nameJobMedical1;
            }
            else if (code == JobList.codeJobRest1)
            {
                name = JobList.nameJobRest1;
            }
            else if (code == JobList.codeJobOffice2)
            {
                name = JobList.nameJobOffice2;
            }
            else if (code == JobList.codeJobOffice3)
            {
                name = JobList.nameJobOffice3;
            }
            else if (code == JobList.codeJobOffice4)
            {
                name = JobList.nameJobOffice4;
            }
            else if (code == JobList.codeJobOffice5)
            {
                name = JobList.nameJobOffice5;
            }

            return name;
        }
    }
}
