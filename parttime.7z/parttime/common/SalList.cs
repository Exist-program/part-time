﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class SalList
    {

        // 給料名
        static public string nameSal0 = "▼給料";
        static public string nameSal1 = "月給";
        static public string nameSal2 = "日給";
        static public string nameSal3 = "時給";

        // 給料値
        static public string codeSal0 = "0";
        static public string codeSal1 = "1";
        static public string codeSal2 = "2";
        static public string codeSal3 = "3";

        public static string[] nameSalList = new string[] { 
    
            SalList.nameSal0,
            SalList.nameSal1,
            SalList.nameSal2,
            SalList.nameSal3

        };

        public static string[] codeSalList = new string[] { 
    
            SalList.codeSal0,
            SalList.codeSal1,
            SalList.codeSal2,
            SalList.codeSal3
        };

    }
}
