﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class CurrentSts
    {

        // 現在の状態名
        static public string nameCurSts0 = "▼現在状態";
        static public string nameCurSts1 = "学生";
        static public string nameCurSts2 = "無職";

        // 現在の状態値
        static public string codeCurSts0 = "0";
        static public string codeCurSts1 = "1";
        static public string codeCurSts2 = "2";

        public static string[] nameCurStsList = new string[] { 
    
            CurrentSts.nameCurSts0,
            CurrentSts.nameCurSts1,
            CurrentSts.nameCurSts2

        };

        public static string[] codeCurStsList = new string[] { 
    
            CurrentSts.codeCurSts0,
            CurrentSts.codeCurSts1,
            CurrentSts.codeCurSts2
        };
    }
}
