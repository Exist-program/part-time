﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class SalTani
    {

        // 給料名
        static public string nameSalTaniTime0 = "▼時給";
        static public string nameSalTaniTime1 = "2000円以上";
        static public string nameSalTaniTime2 = "1500円以上";
        static public string nameSalTaniTime3 = "1000円以上";
        static public string nameSalTaniTime4 = "900円以上";
        static public string nameSalTaniTime5 = "800円以上";
        static public string nameSalTaniTime6 = "650円以上";

        // 給料値
        static public string codeSalTaniTime0 = "0";
        static public string codeSalTaniTime1 = "1";
        static public string codeSalTaniTime2 = "2";
        static public string codeSalTaniTime3 = "3";
        static public string codeSalTaniTime4 = "4";
        static public string codeSalTaniTime5 = "5";
        static public string codeSalTaniTime6 = "6";

        public static string[] nameSalTaniTimeList = new string[] { 
    
            SalTani.nameSalTaniTime0,
            SalTani.nameSalTaniTime1,
            SalTani.nameSalTaniTime2,
            SalTani.nameSalTaniTime3,
            SalTani.nameSalTaniTime4,
            SalTani.nameSalTaniTime5,
            SalTani.nameSalTaniTime6

    };

        public static string[] codeSalTaniTimeList = new string[] { 
    
            SalTani.codeSalTaniTime0,
            SalTani.codeSalTaniTime1,
            SalTani.codeSalTaniTime2,
            SalTani.codeSalTaniTime3,
            SalTani.codeSalTaniTime4,
            SalTani.codeSalTaniTime5,
            SalTani.codeSalTaniTime6
    };

        // 給料名
        static public string nameSalTaniDate0 = "▼日給";
        static public string nameSalTaniDate1 = "15000円以上";
        static public string nameSalTaniDate2 = "10000円以上";
        static public string nameSalTaniDate3 = "8000円以上";
        static public string nameSalTaniDate4 = "7000円以上";
        static public string nameSalTaniDate5 = "6000円以上";
        static public string nameSalTaniDate6 = "5000円以上";
        static public string nameSalTaniDate7 = "4000円以下";

        // 給料値
        static public string codeSalTaniDate0 = "0";
        static public string codeSalTaniDate1 = "1";
        static public string codeSalTaniDate2 = "2";
        static public string codeSalTaniDate3 = "3";
        static public string codeSalTaniDate4 = "4";
        static public string codeSalTaniDate5 = "5";
        static public string codeSalTaniDate6 = "6";
        static public string codeSalTaniDate7 = "7";

        public static string[] nameSalTaniDateList = new string[] { 
    
            SalTani.nameSalTaniDate0,
            SalTani.nameSalTaniDate1,
            SalTani.nameSalTaniDate2,
            SalTani.nameSalTaniDate3,
            SalTani.nameSalTaniDate4,
            SalTani.nameSalTaniDate5,
            SalTani.nameSalTaniDate6,
            SalTani.nameSalTaniDate7
        };

        public static string[] codeSalTaniDateList = new string[] { 
    
            SalTani.codeSalTaniDate0,
            SalTani.codeSalTaniDate1,
            SalTani.codeSalTaniDate2,
            SalTani.codeSalTaniDate3,
            SalTani.codeSalTaniDate4,
            SalTani.codeSalTaniDate5,
            SalTani.codeSalTaniDate6,
            SalTani.codeSalTaniDate7
        };

        // 給料名
        static public string nameSalTaniMonth0 = "▼月給";
        static public string nameSalTaniMonth1 = "25万円以上";
        static public string nameSalTaniMonth2 = "20万円以上";
        static public string nameSalTaniMonth3 = "18万円以上";
        static public string nameSalTaniMonth4 = "15万円以上";
        static public string nameSalTaniMonth5 = "12万円以下";

        // 給料値
        static public string codeSalTaniMonth0 = "0";
        static public string codeSalTaniMonth1 = "1";
        static public string codeSalTaniMonth2 = "2";
        static public string codeSalTaniMonth3 = "3";
        static public string codeSalTaniMonth4 = "4";
        static public string codeSalTaniMonth5 = "5";

        public static string[] nameSalTaniMonthList = new string[] { 
    
            SalTani.nameSalTaniMonth0,
            SalTani.nameSalTaniMonth1,
            SalTani.nameSalTaniMonth2,
            SalTani.nameSalTaniMonth3,
            SalTani.nameSalTaniMonth4,
            SalTani.nameSalTaniMonth5

        };

        public static string[] codeSalTaniMonthList = new string[] { 
    
            SalTani.codeSalTaniMonth0,
            SalTani.codeSalTaniMonth1,
            SalTani.codeSalTaniMonth2,
            SalTani.codeSalTaniMonth3,
            SalTani.codeSalTaniMonth4,
            SalTani.codeSalTaniMonth5
        };
    }
}
