﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data.SqlClient;
using System.Data;

namespace parttime.common
{
    class DbCon
    {
        public static string Conn_Str = "data source=hiwork.jp,14333;initial catalog=PARTTIMEJOB;password=b-cause@Kim2002;persist security info=True;user id=bcause;";

        static public string Conn_Str_Hiwork = "data source=hiwork.jp,14333;initial catalog=hiwork;password=b-cause@Kim2002;persist security info=True;user id=bcause;";

        public static DataSet selectInfo(ArrayList columnList, ArrayList valueList, String sql)
        {

            SqlConnection myConn = new SqlConnection(DbCon.Conn_Str);

            DataSet ds = new DataSet();

            SqlDataAdapter myAdapter = new SqlDataAdapter();

            if (myConn.State == ConnectionState.Open)
            {

                myConn.Close();
            }

            myConn.Open();

            SqlCommand mcd = new SqlCommand("", myConn);

            mcd.CommandType = CommandType.Text;

            System.Data.SqlClient.SqlTransaction myTrans =
                myConn.BeginTransaction(System.Data.IsolationLevel.ReadCommitted, "Trans");

            mcd.Transaction = myTrans;
            mcd.CommandText = sql;

            myAdapter.SelectCommand = mcd;

            mcd.Parameters.Clear();

            try
            {

                for (int i = 0; i < columnList.Count; i++)
                {

                    mcd.Parameters.Add((String)columnList[i], (String)valueList[i]);
                }

                myAdapter.Fill(ds);

                mcd.Parameters.Clear();
                myTrans.Commit();

            }
            catch (Exception e)
            {
                myTrans.Rollback();
                ds = null;
                string err = "Error : " + e.Message.ToString();
            }
            finally
            {
                myConn.Close();
                myConn.Dispose();
                mcd.Dispose();
                myAdapter.Dispose();
                myTrans.Dispose();
            }

            return ds;

        }

        public static DataSet selectInfo2(ArrayList columnList, ArrayList valueList, String sql)
        {

            SqlConnection myConn = new SqlConnection(DbCon.Conn_Str_Hiwork);

            DataSet ds = new DataSet();

            SqlDataAdapter myAdapter = new SqlDataAdapter();

            if (myConn.State == ConnectionState.Open)
            {

                myConn.Close();
            }

            myConn.Open();

            SqlCommand mcd = new SqlCommand("", myConn);

            mcd.CommandType = CommandType.Text;

            System.Data.SqlClient.SqlTransaction myTrans =
                myConn.BeginTransaction(System.Data.IsolationLevel.ReadCommitted, "Trans");

            mcd.Transaction = myTrans;
            mcd.CommandText = sql;

            myAdapter.SelectCommand = mcd;

            mcd.Parameters.Clear();

            try
            {

                for (int i = 0; i < columnList.Count; i++)
                {

                    mcd.Parameters.Add((String)columnList[i], (String)valueList[i]);
                }

                myAdapter.Fill(ds);

                mcd.Parameters.Clear();
                myTrans.Commit();

            }
            catch (Exception e)
            {
                myTrans.Rollback();
                ds = null;
                string err = "Error : " + e.Message.ToString();
            }
            finally
            {
                myConn.Close();
                myConn.Dispose();
                mcd.Dispose();
                myAdapter.Dispose();
                myTrans.Dispose();
            }

            return ds;

        }

        public static DataSet selectInfoNoneCondition(String sql)
        {

            SqlConnection myConn = new SqlConnection(DbCon.Conn_Str);

            DataSet ds = new DataSet();

            SqlDataAdapter myAdapter = new SqlDataAdapter();

            if (myConn.State == ConnectionState.Open)
            {

                myConn.Close();
            }

            myConn.Open();

            SqlCommand mcd = new SqlCommand("", myConn);

            mcd.CommandType = CommandType.Text;

            System.Data.SqlClient.SqlTransaction myTrans =
                myConn.BeginTransaction(System.Data.IsolationLevel.ReadCommitted, "Trans");

            mcd.Transaction = myTrans;
            mcd.CommandText = sql;

            myAdapter.SelectCommand = mcd;

            try
            {
                myAdapter.Fill(ds);

                mcd.Parameters.Clear();
                myTrans.Commit();

            }
            catch (Exception e)
            {
                myTrans.Rollback();
                ds = null;
                string ret = "Error : " + e.Message.ToString();
            }
            finally
            {
                myConn.Close();
                myConn.Dispose();
                mcd.Dispose();
                myAdapter.Dispose();
                myTrans.Dispose();
            }

            return ds;

        }

        public static String updateInfo(ArrayList columnList, ArrayList valueList, String sql)
        {

            SqlConnection myConn = new SqlConnection(DbCon.Conn_Str);

            String ret = CodeMaster.OK;

            //   SqlDataAdapter myAdapter = new SqlDataAdapter();

            if (myConn.State == ConnectionState.Open)
            {

                myConn.Close();
            }

            myConn.Open();

            SqlCommand mcd = new SqlCommand("", myConn);

            mcd.CommandType = CommandType.Text;

            System.Data.SqlClient.SqlTransaction myTrans =
                myConn.BeginTransaction(System.Data.IsolationLevel.ReadCommitted, "Trans");

            mcd.Transaction = myTrans;
            mcd.CommandText = sql;

            //     myAdapter.UpdateCommand = mcd;

            for (int i = 0; i < columnList.Count; i++)
            {

                mcd.Parameters.Add((String)columnList[i], (String)valueList[i]);
            }

            try
            {
                // myAdapter.UpdateCommand.EndExecuteNonQuery();

                mcd.ExecuteNonQuery();

                mcd.Parameters.Clear();
                myTrans.Commit();

            }
            catch (Exception e)
            {
                myTrans.Rollback();

                ret = "Error : " + e.Message.ToString();
            }
            finally
            {
                myConn.Close();
                myConn.Dispose();
                mcd.Dispose();
                //    myAdapter.Dispose();
                myTrans.Dispose();
            }

            return ret;

        }

        public static String deleteInfo(ArrayList columnList, ArrayList valueList, String sql)
        {

            SqlConnection myConn = new SqlConnection(DbCon.Conn_Str);

            String ret = CodeMaster.OK;

            //   SqlDataAdapter myAdapter = new SqlDataAdapter();

            if (myConn.State == ConnectionState.Open)
            {

                myConn.Close();
            }

            myConn.Open();

            SqlCommand mcd = new SqlCommand("", myConn);

            mcd.CommandType = CommandType.Text;

            System.Data.SqlClient.SqlTransaction myTrans =
                myConn.BeginTransaction(System.Data.IsolationLevel.ReadCommitted, "Trans");

            mcd.Transaction = myTrans;
            mcd.CommandText = sql;

            //     myAdapter.UpdateCommand = mcd;

            for (int i = 0; i < columnList.Count; i++)
            {

                mcd.Parameters.Add((String)columnList[i], (String)valueList[i]);
            }

            try
            {
                // myAdapter.UpdateCommand.EndExecuteNonQuery();

                mcd.ExecuteNonQuery();

                mcd.Parameters.Clear();
                myTrans.Commit();

            }
            catch (Exception e)
            {
                myTrans.Rollback();

                ret = "Error : " + e.Message.ToString();
            }
            finally
            {
                myConn.Close();
                myConn.Dispose();
                mcd.Dispose();
                //    myAdapter.Dispose();
                myTrans.Dispose();
            }

            return ret;

        }

        public static String insertInfo(ArrayList columnList, ArrayList valueList, String sql)
        {

            string result = CodeMaster.OK;

            SqlConnection myConn = new SqlConnection(DbCon.Conn_Str);

            SqlDataAdapter myAdapter = new SqlDataAdapter();

            if (myConn.State == ConnectionState.Open)
            {

                myConn.Close();
            }

            myConn.Open();

            SqlCommand myCommand = new SqlCommand("", myConn);
            myCommand.CommandType = CommandType.Text;

            System.Data.SqlClient.SqlTransaction myTrans =
                myConn.BeginTransaction(IsolationLevel.ReadCommitted, "Trans");

            myCommand.Transaction = myTrans;
            myCommand.CommandText = sql;

            myAdapter.InsertCommand = myCommand;

            try
            {
                for (int i = 0; i < columnList.Count; i++)
                {

                    myCommand.Parameters.Add((String)columnList[i], (String)valueList[i]);
                }

                myCommand.ExecuteNonQuery();
                myCommand.Parameters.Clear();
                myTrans.Commit();

            }
            catch (Exception e)
            {

                result = e.Message.ToString();
                myTrans.Rollback();
                string ret = "Error : " + e.Message.ToString();
            }
            finally
            {
                myConn.Close();
                myConn.Dispose();
                myCommand.Dispose();
                myAdapter.Dispose();
                myTrans.Dispose();
            }

            return result;
        }

    }
}
