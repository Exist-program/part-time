﻿using System;
using System.Collections.Generic;
using System.Text;

namespace parttime.common
{
    class Mothertongue
    {

        // 言語
        static public string nameLang000 = "▼母国語";
        static public string nameLang001 = "アイスランド語";
        static public string nameLang002 = "アイルランド語";
        static public string nameLang003 = "アゼルバイジャン語";
        static public string nameLang004 = "アッカド語";
        static public string nameLang005 = "アッサム語";
        static public string nameLang006 = "アフガン語";
        static public string nameLang007 = "アフリカーンス";
        static public string nameLang008 = "アムハリク語";
        static public string nameLang009 = "アラビア語";
        static public string nameLang010 = "アラマン語";
        static public string nameLang011 = "アラム語";
        static public string nameLang012 = "アルジェリア語";
        static public string nameLang013 = "アルバニア語";
        static public string nameLang014 = "アルメニア語";
        static public string nameLang015 = "イーディッシュ語";
        static public string nameLang016 = "イタリア語";
        static public string nameLang017 = "イロカノ語";
        static public string nameLang020 = "インドネシア語";
        static public string nameLang021 = "ウイグル語";
        static public string nameLang022 = "ウェールズ語";
        static public string nameLang023 = "ウォロフ語";
        static public string nameLang024 = "ウガンダ語";
        static public string nameLang025 = "ウクライナ語";
        static public string nameLang026 = "ウズベク語";
        static public string nameLang027 = "ウルドゥ語";
        static public string nameLang028 = "エストニア語";
        static public string nameLang029 = "エスペラント語";
        static public string nameLang030 = "エチオピア語";
        static public string nameLang031 = "英語（英国)";
        static public string nameLang032 = "英語（米国)";
        static public string nameLang033 = "オクシタン語";
        static public string nameLang034 = "オランダ語";
        static public string nameLang035 = "オリヤー語";
        static public string nameLang036 = "ガーナ語";
        static public string nameLang037 = "韓国語";
        static public string nameLang038 = "カザフ語";
        static public string nameLang039 = "客家語";
        static public string nameLang040 = "カシミール語";
        static public string nameLang041 = "カタルーニャ語";
        static public string nameLang042 = "カタロニア語";
        static public string nameLang043 = "カチン語";
        static public string nameLang044 = "カパンパンガン語";
        static public string nameLang045 = "カミラロイ語";
        static public string nameLang046 = "ガリシア語";
        static public string nameLang047 = "カンナダ語";
        static public string nameLang048 = "カンボジア語";
        static public string nameLang049 = "ギリシャ語";
        static public string nameLang051 = "キルギス語";
        static public string nameLang052 = "クウェート語";
        static public string nameLang053 = "クールギ語";
        static public string nameLang054 = "グジャラート語";
        static public string nameLang055 = "クメール語";
        static public string nameLang056 = "グルジア語";
        static public string nameLang057 = "クルド語";
        static public string nameLang058 = "クロアチア語";
        static public string nameLang059 = "クロネル語";
        static public string nameLang060 = "ゲール語";
        static public string nameLang061 = "ケチュア語(クスコ)";
        static public string nameLang062 = "ケチュア語(ボリビア)";
        static public string nameLang063 = "コーサ語";
        static public string nameLang064 = "コプト語";
        static public string nameLang065 = "コンカニ［コーンクニー］語";
        static public string nameLang066 = "サミ語";
        static public string nameLang067 = "サモス語";
        static public string nameLang068 = "サンスクリット語";
        static public string nameLang069 = "ジャワ語";
        static public string nameLang070 = "シリア語";
        static public string nameLang071 = "上海語";
        static public string nameLang072 = "シンハリ語";
        static public string nameLang073 = "スウェーデン語";
        static public string nameLang074 = "スーダン語";
        static public string nameLang075 = "ズールー語";
        static public string nameLang076 = "スペイン語(中南米)";
        static public string nameLang077 = "スペイン語(本国)";
        static public string nameLang078 = "スロバキア語";
        static public string nameLang079 = "スロベニア語";
        static public string nameLang080 = "スワヒリ語";
        static public string nameLang081 = "スンダ語";
        static public string nameLang082 = "セネガル語";
        static public string nameLang083 = "セブアノ語";
        static public string nameLang084 = "セルビア語";
        static public string nameLang085 = "ソマリ語";
        static public string nameLang086 = "ゾンカー語";
        static public string nameLang087 = "タイ語";
        static public string nameLang088 = "台湾語";
        static public string nameLang089 = "タガログ語";
        static public string nameLang090 = "タジク語";
        static public string nameLang091 = "タミル語";
        static public string nameLang092 = "タリアン語";
        static public string nameLang093 = "ダリ語";
        static public string nameLang094 = "チェコ語";
        static public string nameLang095 = "朝鮮語";
        static public string nameLang096 = "中国語(広東語)";
        static public string nameLang097 = "中国語(北京語)";
        static public string nameLang098 = "チベット語";
        static public string nameLang099 = "チャモロ語";
        static public string nameLang100 = "ディベヒ語";
        static public string nameLang101 = "イボ語";
        static public string nameLang102 = "デルタ語";
        static public string nameLang103 = "テレグ語";
        static public string nameLang104 = "デンマーク語";
        static public string nameLang105 = "ドイツ語";
        static public string nameLang106 = "トゥイ語";
        static public string nameLang107 = "トゥルクメン語";
        static public string nameLang108 = "ドグリブ語";
        static public string nameLang109 = "トルコ語";
        static public string nameLang110 = "ナイジェリア語";
        static public string nameLang111 = "ネパール語";
        static public string nameLang112 = "ノルウェー語";
        static public string nameLang113 = "日本語";
        static public string nameLang114 = "ハイチ・クレオール語";
        static public string nameLang115 = "ハウサ語";
        static public string nameLang116 = "パキスタン語";
        static public string nameLang117 = "パシュトゥー語";
        static public string nameLang118 = "バスク語";
        static public string nameLang119 = "パピアメント語";
        static public string nameLang120 = "ハルハ語";
        static public string nameLang121 = "パレスチナ語";
        static public string nameLang122 = "ハワイ語";
        static public string nameLang123 = "ハンガリー語";
        static public string nameLang124 = "バングラデシュ語";
        static public string nameLang125 = "パンジャビ語";
        static public string nameLang126 = "バンバラ語";
        static public string nameLang127 = "ビサヤ語";
        static public string nameLang128 = "ヒンディー語";
        static public string nameLang129 = "フィジー語";
        static public string nameLang130 = "フィンランド語";
        static public string nameLang131 = "フモング語";
        static public string nameLang132 = "フラマン語";
        static public string nameLang133 = "フランス語";
        static public string nameLang134 = "フランス語(カナダ)";
        static public string nameLang135 = "フリースランド語";
        static public string nameLang136 = "ブルガリア語";
        static public string nameLang137 = "ブルトン語";
        static public string nameLang138 = "ベトナム語";
        static public string nameLang139 = "ヘブライ語";
        static public string nameLang140 = "べラルーシ語";
        static public string nameLang141 = "ペルシア語";
        static public string nameLang142 = "ベルベル語";
        static public string nameLang143 = "ベンガル語";
        static public string nameLang144 = "ポーランド語";
        static public string nameLang145 = "ボジュプリー語";
        static public string nameLang146 = "ボバンギ語";
        static public string nameLang147 = "ボラン語";
        static public string nameLang148 = "ポルトガル語";
        static public string nameLang149 = "ポルトガル語(ブラジル)";
        static public string nameLang150 = "マオリ語";
        static public string nameLang151 = "マケドニア語";
        static public string nameLang152 = "マジャル語";
        static public string nameLang153 = "マヤ語";
        static public string nameLang154 = "マラーティー語";
        static public string nameLang155 = "マラガシ語";
        static public string nameLang156 = "マラティー語";
        static public string nameLang157 = "マラヤーラム語";
        static public string nameLang158 = "マルタ語";
        static public string nameLang159 = "マレー語";
        static public string nameLang160 = "マンディンカ語";
        static public string nameLang161 = "ミャンマー語";
        static public string nameLang162 = "モルドバ語";
        static public string nameLang163 = "モンゴル語";
        static public string nameLang164 = "ヨルダン語";
        static public string nameLang165 = "ヨルバ語";
        static public string nameLang166 = "ラオ語";
        static public string nameLang167 = "ラテン語";
        static public string nameLang168 = "ラトビア語";
        static public string nameLang169 = "リトアニア語";
        static public string nameLang170 = "ルーマニア語";
        static public string nameLang171 = "ルオ語";
        static public string nameLang172 = "ルガンダ語";
        static public string nameLang173 = "ルワンダ語";
        static public string nameLang174 = "ルンミ語";
        static public string nameLang175 = "ロシア語";
        static public string nameLang176 = "ワロン語";
        static public string nameLang177 = "アジャンテ語";

        // 言語値
        static public string codeLangE000 = "000";
        static public string codeLangE001 = "001";
        static public string codeLangE002 = "002";
        static public string codeLangE003 = "003";
        static public string codeLangE004 = "004";
        static public string codeLangE005 = "005";
        static public string codeLangE006 = "006";
        static public string codeLangE007 = "007";
        static public string codeLangE008 = "008";
        static public string codeLangE009 = "009";
        static public string codeLangE010 = "010";
        static public string codeLangE011 = "011";
        static public string codeLangE012 = "012";
        static public string codeLangE013 = "013";
        static public string codeLangE014 = "014";
        static public string codeLangE015 = "015";
        static public string codeLangE016 = "016";
        static public string codeLangE017 = "017";
        static public string codeLangE020 = "020";
        static public string codeLangE021 = "021";
        static public string codeLangE022 = "022";
        static public string codeLangE023 = "023";
        static public string codeLangE024 = "024";
        static public string codeLangE025 = "025";
        static public string codeLangE026 = "026";
        static public string codeLangE027 = "027";
        static public string codeLangE028 = "028";
        static public string codeLangE029 = "029";
        static public string codeLangE030 = "030";
        static public string codeLangE031 = "031";
        static public string codeLangE032 = "032";
        static public string codeLangE033 = "033";
        static public string codeLangE034 = "034";
        static public string codeLangE035 = "035";
        static public string codeLangE036 = "036";
        static public string codeLangE037 = "037";
        static public string codeLangE038 = "038";
        static public string codeLangE039 = "039";
        static public string codeLangE040 = "040";
        static public string codeLangE041 = "041";
        static public string codeLangE042 = "042";
        static public string codeLangE043 = "043";
        static public string codeLangE044 = "044";
        static public string codeLangE045 = "045";
        static public string codeLangE046 = "046";
        static public string codeLangE047 = "047";
        static public string codeLangE048 = "048";
        static public string codeLangE049 = "049";
        static public string codeLangE051 = "051";
        static public string codeLangE052 = "052";
        static public string codeLangE053 = "053";
        static public string codeLangE054 = "054";
        static public string codeLangE055 = "055";
        static public string codeLangE056 = "056";
        static public string codeLangE057 = "057";
        static public string codeLangE058 = "058";
        static public string codeLangE059 = "059";
        static public string codeLangE060 = "060";
        static public string codeLangE061 = "061";
        static public string codeLangE062 = "062";
        static public string codeLangE063 = "063";
        static public string codeLangE064 = "064";
        static public string codeLangE065 = "065";
        static public string codeLangE066 = "066";
        static public string codeLangE067 = "067";
        static public string codeLangE068 = "068";
        static public string codeLangE069 = "069";
        static public string codeLangE070 = "070";
        static public string codeLangE071 = "071";
        static public string codeLangE072 = "072";
        static public string codeLangE073 = "073";
        static public string codeLangE074 = "074";
        static public string codeLangE075 = "075";
        static public string codeLangE076 = "076";
        static public string codeLangE077 = "077";
        static public string codeLangE078 = "078";
        static public string codeLangE079 = "079";
        static public string codeLangE080 = "080";
        static public string codeLangE081 = "081";
        static public string codeLangE082 = "082";
        static public string codeLangE083 = "083";
        static public string codeLangE084 = "084";
        static public string codeLangE085 = "085";
        static public string codeLangE086 = "086";
        static public string codeLangE087 = "087";
        static public string codeLangE088 = "088";
        static public string codeLangE089 = "089";
        static public string codeLangE090 = "090";
        static public string codeLangE091 = "091";
        static public string codeLangE092 = "092";
        static public string codeLangE093 = "093";
        static public string codeLangE094 = "094";
        static public string codeLangE095 = "095";
        static public string codeLangE096 = "096";
        static public string codeLangE097 = "097";
        static public string codeLangE098 = "098";
        static public string codeLangE099 = "099";
        static public string codeLangE100 = "100";
        static public string codeLangE101 = "101";
        static public string codeLangE102 = "102";
        static public string codeLangE103 = "103";
        static public string codeLangE104 = "104";
        static public string codeLangE105 = "105";
        static public string codeLangE106 = "106";
        static public string codeLangE107 = "107";
        static public string codeLangE108 = "108";
        static public string codeLangE109 = "109";
        static public string codeLangE110 = "110";
        static public string codeLangE111 = "111";
        static public string codeLangE112 = "112";
        static public string codeLangE113 = "113";
        static public string codeLangE114 = "114";
        static public string codeLangE115 = "115";
        static public string codeLangE116 = "116";
        static public string codeLangE117 = "117";
        static public string codeLangE118 = "118";
        static public string codeLangE119 = "119";
        static public string codeLangE120 = "120";
        static public string codeLangE121 = "121";
        static public string codeLangE122 = "122";
        static public string codeLangE123 = "123";
        static public string codeLangE124 = "124";
        static public string codeLangE125 = "125";
        static public string codeLangE126 = "126";
        static public string codeLangE127 = "127";
        static public string codeLangE128 = "128";
        static public string codeLangE129 = "129";
        static public string codeLangE130 = "130";
        static public string codeLangE131 = "131";
        static public string codeLangE132 = "132";
        static public string codeLangE133 = "133";
        static public string codeLangE134 = "134";
        static public string codeLangE135 = "135";
        static public string codeLangE136 = "136";
        static public string codeLangE137 = "137";
        static public string codeLangE138 = "138";
        static public string codeLangE139 = "139";
        static public string codeLangE140 = "140";
        static public string codeLangE141 = "141";
        static public string codeLangE142 = "142";
        static public string codeLangE143 = "143";
        static public string codeLangE144 = "144";
        static public string codeLangE145 = "145";
        static public string codeLangE146 = "146";
        static public string codeLangE147 = "147";
        static public string codeLangE148 = "148";
        static public string codeLangE149 = "149";
        static public string codeLangE150 = "150";
        static public string codeLangE151 = "151";
        static public string codeLangE152 = "152";
        static public string codeLangE153 = "153";
        static public string codeLangE154 = "154";
        static public string codeLangE155 = "155";
        static public string codeLangE156 = "156";
        static public string codeLangE157 = "157";
        static public string codeLangE158 = "158";
        static public string codeLangE159 = "159";
        static public string codeLangE160 = "160";
        static public string codeLangE161 = "161";
        static public string codeLangE162 = "162";
        static public string codeLangE163 = "163";
        static public string codeLangE164 = "164";
        static public string codeLangE165 = "165";
        static public string codeLangE166 = "166";
        static public string codeLangE167 = "167";
        static public string codeLangE168 = "168";
        static public string codeLangE169 = "169";
        static public string codeLangE170 = "170";
        static public string codeLangE171 = "171";
        static public string codeLangE172 = "172";
        static public string codeLangE173 = "173";
        static public string codeLangE174 = "174";
        static public string codeLangE175 = "175";
        static public string codeLangE176 = "176";
        static public string codeLangE177 = "177";

        public static string[] nameLangList = new string[] {
    
            Mothertongue.nameLang000,
            Mothertongue.nameLang001,
            Mothertongue.nameLang002,
            Mothertongue.nameLang003,
            Mothertongue.nameLang004,
            Mothertongue.nameLang005,
            Mothertongue.nameLang006,
            Mothertongue.nameLang007,
            Mothertongue.nameLang008,
            Mothertongue.nameLang009,
            Mothertongue.nameLang010,
            Mothertongue.nameLang011,
            Mothertongue.nameLang012,
            Mothertongue.nameLang013,
            Mothertongue.nameLang014,
            Mothertongue.nameLang015,
            Mothertongue.nameLang016,
            Mothertongue.nameLang017,
            Mothertongue.nameLang020,
            Mothertongue.nameLang021,
            Mothertongue.nameLang022,
            Mothertongue.nameLang023,
            Mothertongue.nameLang024,
            Mothertongue.nameLang025,
            Mothertongue.nameLang026,
            Mothertongue.nameLang027,
            Mothertongue.nameLang028,
            Mothertongue.nameLang029,
            Mothertongue.nameLang030,
            Mothertongue.nameLang031,
            Mothertongue.nameLang032,
            Mothertongue.nameLang033,
            Mothertongue.nameLang034,
            Mothertongue.nameLang035,
            Mothertongue.nameLang036,
            Mothertongue.nameLang037,
            Mothertongue.nameLang038,
            Mothertongue.nameLang039,
            Mothertongue.nameLang040,
            Mothertongue.nameLang041,
            Mothertongue.nameLang042,
            Mothertongue.nameLang043,
            Mothertongue.nameLang044,
            Mothertongue.nameLang045,
            Mothertongue.nameLang046,
            Mothertongue.nameLang047,
            Mothertongue.nameLang048,
            Mothertongue.nameLang049,
            Mothertongue.nameLang051,
            Mothertongue.nameLang052,
            Mothertongue.nameLang053,
            Mothertongue.nameLang054,
            Mothertongue.nameLang055,
            Mothertongue.nameLang056,
            Mothertongue.nameLang057,
            Mothertongue.nameLang058,
            Mothertongue.nameLang059,
            Mothertongue.nameLang060,
            Mothertongue.nameLang061,
            Mothertongue.nameLang062,
            Mothertongue.nameLang063,
            Mothertongue.nameLang064,
            Mothertongue.nameLang065,
            Mothertongue.nameLang066,
            Mothertongue.nameLang067,
            Mothertongue.nameLang068,
            Mothertongue.nameLang069,
            Mothertongue.nameLang070,
            Mothertongue.nameLang071,
            Mothertongue.nameLang072,
            Mothertongue.nameLang073,
            Mothertongue.nameLang074,
            Mothertongue.nameLang075,
            Mothertongue.nameLang076,
            Mothertongue.nameLang077,
            Mothertongue.nameLang078,
            Mothertongue.nameLang079,
            Mothertongue.nameLang080,
            Mothertongue.nameLang081,
            Mothertongue.nameLang082,
            Mothertongue.nameLang083,
            Mothertongue.nameLang084,
            Mothertongue.nameLang085,
            Mothertongue.nameLang086,
            Mothertongue.nameLang087,
            Mothertongue.nameLang088,
            Mothertongue.nameLang089,
            Mothertongue.nameLang090,
            Mothertongue.nameLang091,
            Mothertongue.nameLang092,
            Mothertongue.nameLang093,
            Mothertongue.nameLang094,
            Mothertongue.nameLang095,
            Mothertongue.nameLang096,
            Mothertongue.nameLang097,
            Mothertongue.nameLang098,
            Mothertongue.nameLang099,
            Mothertongue.nameLang100,
            Mothertongue.nameLang101,
            Mothertongue.nameLang102,
            Mothertongue.nameLang103,
            Mothertongue.nameLang104,
            Mothertongue.nameLang105,
            Mothertongue.nameLang106,
            Mothertongue.nameLang107,
            Mothertongue.nameLang108,
            Mothertongue.nameLang109,
            Mothertongue.nameLang110,
            Mothertongue.nameLang111,
            Mothertongue.nameLang112,
            Mothertongue.nameLang113,
            Mothertongue.nameLang114,
            Mothertongue.nameLang115,
            Mothertongue.nameLang116,
            Mothertongue.nameLang117,
            Mothertongue.nameLang118,
            Mothertongue.nameLang119,
            Mothertongue.nameLang120,
            Mothertongue.nameLang121,
            Mothertongue.nameLang122,
            Mothertongue.nameLang123,
            Mothertongue.nameLang124,
            Mothertongue.nameLang125,
            Mothertongue.nameLang126,
            Mothertongue.nameLang127,
            Mothertongue.nameLang128,
            Mothertongue.nameLang129,
            Mothertongue.nameLang130,
            Mothertongue.nameLang131,
            Mothertongue.nameLang132,
            Mothertongue.nameLang133,
            Mothertongue.nameLang134,
            Mothertongue.nameLang135,
            Mothertongue.nameLang136,
            Mothertongue.nameLang137,
            Mothertongue.nameLang138,
            Mothertongue.nameLang139,
            Mothertongue.nameLang140,
            Mothertongue.nameLang141,
            Mothertongue.nameLang142,
            Mothertongue.nameLang143,
            Mothertongue.nameLang144,
            Mothertongue.nameLang145,
            Mothertongue.nameLang146,
            Mothertongue.nameLang147,
            Mothertongue.nameLang148,
            Mothertongue.nameLang149,
            Mothertongue.nameLang150,
            Mothertongue.nameLang151,
            Mothertongue.nameLang152,
            Mothertongue.nameLang153,
            Mothertongue.nameLang154,
            Mothertongue.nameLang155,
            Mothertongue.nameLang156,
            Mothertongue.nameLang157,
            Mothertongue.nameLang158,
            Mothertongue.nameLang159,
            Mothertongue.nameLang160,
            Mothertongue.nameLang161,
            Mothertongue.nameLang162,
            Mothertongue.nameLang163,
            Mothertongue.nameLang164,
            Mothertongue.nameLang165,
            Mothertongue.nameLang166,
            Mothertongue.nameLang167,
            Mothertongue.nameLang168,
            Mothertongue.nameLang169,
            Mothertongue.nameLang170,
            Mothertongue.nameLang171,
            Mothertongue.nameLang172,
            Mothertongue.nameLang173,
            Mothertongue.nameLang174,
            Mothertongue.nameLang175,
            Mothertongue.nameLang176,
            Mothertongue.nameLang177
    };

        public static string[] codeLangList = new string[] {
            Mothertongue.codeLangE000,
            Mothertongue.codeLangE001,
            Mothertongue.codeLangE002,
            Mothertongue.codeLangE003,
            Mothertongue.codeLangE004,
            Mothertongue.codeLangE005,
            Mothertongue.codeLangE006,
            Mothertongue.codeLangE007,
            Mothertongue.codeLangE008,
            Mothertongue.codeLangE009,
            Mothertongue.codeLangE010,
            Mothertongue.codeLangE011,
            Mothertongue.codeLangE012,
            Mothertongue.codeLangE013,
            Mothertongue.codeLangE014,
            Mothertongue.codeLangE015,
            Mothertongue.codeLangE016,
            Mothertongue.codeLangE017,
            Mothertongue.codeLangE020,
            Mothertongue.codeLangE021,
            Mothertongue.codeLangE022,
            Mothertongue.codeLangE023,
            Mothertongue.codeLangE024,
            Mothertongue.codeLangE025,
            Mothertongue.codeLangE026,
            Mothertongue.codeLangE027,
            Mothertongue.codeLangE028,
            Mothertongue.codeLangE029,
            Mothertongue.codeLangE030,
            Mothertongue.codeLangE031,
            Mothertongue.codeLangE032,
            Mothertongue.codeLangE033,
            Mothertongue.codeLangE034,
            Mothertongue.codeLangE035,
            Mothertongue.codeLangE036,
            Mothertongue.codeLangE037,
            Mothertongue.codeLangE038,
            Mothertongue.codeLangE039,
            Mothertongue.codeLangE040,
            Mothertongue.codeLangE041,
            Mothertongue.codeLangE042,
            Mothertongue.codeLangE043,
            Mothertongue.codeLangE044,
            Mothertongue.codeLangE045,
            Mothertongue.codeLangE046,
            Mothertongue.codeLangE047,
            Mothertongue.codeLangE048,
            Mothertongue.codeLangE049,
            Mothertongue.codeLangE051,
            Mothertongue.codeLangE052,
            Mothertongue.codeLangE053,
            Mothertongue.codeLangE054,
            Mothertongue.codeLangE055,
            Mothertongue.codeLangE056,
            Mothertongue.codeLangE057,
            Mothertongue.codeLangE058,
            Mothertongue.codeLangE059,
            Mothertongue.codeLangE060,
            Mothertongue.codeLangE061,
            Mothertongue.codeLangE062,
            Mothertongue.codeLangE063,
            Mothertongue.codeLangE064,
            Mothertongue.codeLangE065,
            Mothertongue.codeLangE066,
            Mothertongue.codeLangE067,
            Mothertongue.codeLangE068,
            Mothertongue.codeLangE069,
            Mothertongue.codeLangE070,
            Mothertongue.codeLangE071,
            Mothertongue.codeLangE072,
            Mothertongue.codeLangE073,
            Mothertongue.codeLangE074,
            Mothertongue.codeLangE075,
            Mothertongue.codeLangE076,
            Mothertongue.codeLangE077,
            Mothertongue.codeLangE078,
            Mothertongue.codeLangE079,
            Mothertongue.codeLangE080,
            Mothertongue.codeLangE081,
            Mothertongue.codeLangE082,
            Mothertongue.codeLangE083,
            Mothertongue.codeLangE084,
            Mothertongue.codeLangE085,
            Mothertongue.codeLangE086,
            Mothertongue.codeLangE087,
            Mothertongue.codeLangE088,
            Mothertongue.codeLangE089,
            Mothertongue.codeLangE090,
            Mothertongue.codeLangE091,
            Mothertongue.codeLangE092,
            Mothertongue.codeLangE093,
            Mothertongue.codeLangE094,
            Mothertongue.codeLangE095,
            Mothertongue.codeLangE096,
            Mothertongue.codeLangE097,
            Mothertongue.codeLangE098,
            Mothertongue.codeLangE099,
            Mothertongue.codeLangE100,
            Mothertongue.codeLangE101,
            Mothertongue.codeLangE102,
            Mothertongue.codeLangE103,
            Mothertongue.codeLangE104,
            Mothertongue.codeLangE105,
            Mothertongue.codeLangE106,
            Mothertongue.codeLangE107,
            Mothertongue.codeLangE108,
            Mothertongue.codeLangE109,
            Mothertongue.codeLangE110,
            Mothertongue.codeLangE111,
            Mothertongue.codeLangE112,
            Mothertongue.codeLangE113,
            Mothertongue.codeLangE114,
            Mothertongue.codeLangE115,
            Mothertongue.codeLangE116,
            Mothertongue.codeLangE117,
            Mothertongue.codeLangE118,
            Mothertongue.codeLangE119,
            Mothertongue.codeLangE120,
            Mothertongue.codeLangE121,
            Mothertongue.codeLangE122,
            Mothertongue.codeLangE123,
            Mothertongue.codeLangE124,
            Mothertongue.codeLangE125,
            Mothertongue.codeLangE126,
            Mothertongue.codeLangE127,
            Mothertongue.codeLangE128,
            Mothertongue.codeLangE129,
            Mothertongue.codeLangE130,
            Mothertongue.codeLangE131,
            Mothertongue.codeLangE132,
            Mothertongue.codeLangE133,
            Mothertongue.codeLangE134,
            Mothertongue.codeLangE135,
            Mothertongue.codeLangE136,
            Mothertongue.codeLangE137,
            Mothertongue.codeLangE138,
            Mothertongue.codeLangE139,
            Mothertongue.codeLangE140,
            Mothertongue.codeLangE141,
            Mothertongue.codeLangE142,
            Mothertongue.codeLangE143,
            Mothertongue.codeLangE144,
            Mothertongue.codeLangE145,
            Mothertongue.codeLangE146,
            Mothertongue.codeLangE147,
            Mothertongue.codeLangE148,
            Mothertongue.codeLangE149,
            Mothertongue.codeLangE150,
            Mothertongue.codeLangE151,
            Mothertongue.codeLangE152,
            Mothertongue.codeLangE153,
            Mothertongue.codeLangE154,
            Mothertongue.codeLangE155,
            Mothertongue.codeLangE156,
            Mothertongue.codeLangE157,
            Mothertongue.codeLangE158,
            Mothertongue.codeLangE159,
            Mothertongue.codeLangE160,
            Mothertongue.codeLangE161,
            Mothertongue.codeLangE162,
            Mothertongue.codeLangE163,
            Mothertongue.codeLangE164,
            Mothertongue.codeLangE165,
            Mothertongue.codeLangE166,
            Mothertongue.codeLangE167,
            Mothertongue.codeLangE168,
            Mothertongue.codeLangE169,
            Mothertongue.codeLangE170,
            Mothertongue.codeLangE171,
            Mothertongue.codeLangE172,
            Mothertongue.codeLangE173,
            Mothertongue.codeLangE174,
            Mothertongue.codeLangE175,
            Mothertongue.codeLangE176,
            Mothertongue.codeLangE177

    };
    }
}
