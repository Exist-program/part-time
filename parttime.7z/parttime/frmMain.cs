﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using parttime.common;
using System.Collections;
using parttime.common;
using parttime.kanri;
using parttime.staff;
using parttime.job;


namespace parttime
{

    public partial class frmMain : Form
    {

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmMain());
        }

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            Form login = new login();

            if(login.ShowDialog(this).ToString() == "OK") {

                this.IsMdiContainer = true;

                Hashtable loginInfo = (Hashtable)Common.ADMININFO;

                AdminInfoBean adminInfo = (AdminInfoBean)loginInfo[CodeMaster.LoginInfo];

                if (adminInfo.getAdminLevel().Trim().Equals(CodeMaster.Level_Limited) ||
                    adminInfo.getAdminFlg().Trim().Equals("0"))
                {

                    MenuItem1000.Visible = false;
                    MenuItem2000.Visible = false;
                    MenuItem3000.Visible = false;
                    MenuItem4000.Visible = false;
                    MenuItem5000.Visible = false;
                    MenuItem6000.Visible = false;

                    MessageBox.Show(MessageConst.LimitedLv);

                } else {

                    if (!adminInfo.getAdminLevel().Trim().Equals(CodeMaster.Level_Master))
                    {

                        MenuItem1000.Visible = false;
                    }
                }


            }
        }

        private void fnSetFrom(Form newForm)
        {
            newForm.MdiParent = this;
            ShowForm(newForm);
            newForm.WindowState = FormWindowState.Maximized;
        }

        private void ShowForm(Form XForm)
        {
            bool chkForm = true;

            if (CodeMaster.FormArray.Count == 0)
            {
                XForm.Show();
                CodeMaster.FormArray.Add(XForm);
            }
            else
            {
                for (int i = 0; i < CodeMaster.FormArray.Count; i++)
                {
                    Form TempForm = (Form)CodeMaster.FormArray[i];
                    if (TempForm.Name == XForm.Name)
                    {
                        TempForm.WindowState = FormWindowState.Maximized;
                        TempForm.Activate();
                        chkForm = false;
                        break;
                    }
                }
                if (chkForm)
                {
                    XForm.Show();
                    CodeMaster.FormArray.Add(XForm);
                }
            }
        }

        // 社員登録
        private void MenuItem1000_Click(object sender, EventArgs e)
        {
            Form newForm = new kanri.frmRegKanri();
            fnSetFrom(newForm);
        }

        // 企業管理
        private void MenuItem2000_Click_1(object sender, EventArgs e)
        {
            Form newForm = new company.frmCompanyList();
            fnSetFrom(newForm);
        }

        // スタッフ管理
        private void MenuItem3000_Click(object sender, EventArgs e)
        {
            Form newForm = new staff.frmStaffList();
            fnSetFrom(newForm);
        }

        // 求人管理
        private void MenuItem4000_Click(object sender, EventArgs e)
        {
            Form newForm = new job.frmJobList();
            fnSetFrom(newForm);
        }

        // Hiwork未登録企業
        private void MenuItem5000_Click(object sender, EventArgs e)
        {
            Form newForm = new tasys.frmNotHiworkKigyouList();
            fnSetFrom(newForm);
        }

        // Hiwork未登録スタッフ
        private void MenuItem6000_Click(object sender, EventArgs e)
        {
            Form newForm = new tasys.frmNotHiworkStaffList();
            fnSetFrom(newForm);
        }

    }
}