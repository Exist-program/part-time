﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using parttime.common;
using System.Collections;
using System.Web;
using System.Net;
using System.IO;

namespace parttime.company
{
    public partial class frmCompanyDetail : Form
    {
        public frmCompanyDetail()
        {
            InitializeComponent();
        }

        private void frmCompanyDetail_Load(object sender, EventArgs e)
        {
            setPage();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            frmClose();
        }

        private void frmClose()
        {

            frmCompanyDetail_FormClosing(null, null);
            this.Close();
        }

        private void frmCompanyDetail_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmMain pForm = (frmMain)this.MdiParent;
            CodeMaster.FormArray.Remove(this);
        }

        private void setPage()
        {
            Common.setComboBox(4, comboTodo);

            getCompanyInfo();
        }

        private void getCompanyInfo() {

            ArrayList colList = new ArrayList();
            ArrayList valList = new ArrayList();

            colList.Add("@company_no");
            valList.Add(CodeMaster.COMPANYNO);

            DataSet ds = DbCon.selectInfo(colList, valList, Sql.SEL_11);

            if (ds.Tables[0].Rows.Count > 0)
            {

                txtMail.Text = ds.Tables[0].Rows[0]["COMPANY_ID"].ToString();
                txtNm.Text = ds.Tables[0].Rows[0]["COMPANY_NAME"].ToString();
                txtPart.Text = ds.Tables[0].Rows[0]["COMPANY_PART"].ToString();
                txtTanto.Text = ds.Tables[0].Rows[0]["COMPANY_TANTO"].ToString();

                txtPostNo.Text =
                    new StringBuilder().Append(ds.Tables[0].Rows[0]["COMPANY_POST_NO1"].ToString())
                                       .Append("-")
                                       .Append(ds.Tables[0].Rows[0]["COMPANY_POST_NO2"].ToString())
                                       .ToString();

                comboTodo.SelectedValue = ds.Tables[0].Rows[0]["COMPANY_TODO"].ToString();
                txtAddr1.Text = ds.Tables[0].Rows[0]["COMPANY_ADDR1"].ToString();
                txtAddr2.Text = ds.Tables[0].Rows[0]["COMPANY_ADDR2"].ToString();
                txtTel.Text = ds.Tables[0].Rows[0]["COMPANY_TEL"].ToString();
                string picture = ds.Tables[0].Rows[0]["COMPANY_PHO"].ToString();

                if (picture != null && picture != string.Empty)
                {
                    WebClient wc = new WebClient();

                    string url ="http://www.parttime-jp.info/"+ picture.Substring(picture.IndexOf("img"));

                    Stream stream = wc.OpenRead(url);

                    Image image = Image.FromStream(stream);

                    picBox.Image = image;
                }
                else {

                    picBox.Image = null;
                }


                // -----------------------------------------------------

                checkSell1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_1"].ToString());
                checkSell2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_2"].ToString());
                checkSell3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_3"].ToString());
                checkSell4.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_4"].ToString());
                checkSell5.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_5"].ToString());
                checkSell6.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_6"].ToString());
                checkSell7.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_7"].ToString());
                checkSell8.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_8"].ToString());
                checkSell9.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SELL_9"].ToString());

                checkFood1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_1"].ToString());
                checkFood2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_2"].ToString());
                checkFood3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_3"].ToString());
                checkFood4.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_4"].ToString());
                checkFood5.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_5"].ToString());
                checkFood6.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_6"].ToString());
                checkFood7.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_7"].ToString());
                checkFood8.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_8"].ToString());
                checkFood9.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_9"].ToString());
                checkFood10.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FOOD_10"].ToString());

                checkService1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_1"].ToString());
                checkService2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_2"].ToString());
                checkService3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_3"].ToString());
                checkService4.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_4"].ToString());
                checkService5.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_5"].ToString());
                checkService6.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_6"].ToString());
                checkService7.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_SERVICE_7"].ToString());

                checkOffice1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_OFFICE_1"].ToString());
                checkOffice2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_OFFICE_2"].ToString());
                checkOffice3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_OFFICE_3"].ToString());
                checkOffice4.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_OFFICE_4"].ToString());
                checkOffice5.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_OFFICE_5"].ToString());

                checkAmuse1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AMUSE_1"].ToString());
                checkAmuse2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AMUSE_2"].ToString());
                checkAmuse3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AMUSE_3"].ToString());
                checkAmuse4.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AMUSE_4"].ToString());
                checkAmuse5.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AMUSE_5"].ToString());

                checkAffare1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AFFAIRS_1"].ToString());
                checkAffare2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AFFAIRS_2"].ToString());
                checkAffare3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AFFAIRS_3"].ToString());
                checkAffare4.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AFFAIRS_4"].ToString());
                checkAffare5.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_AFFAIRS_5"].ToString());

                checkIt1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_IT_1"].ToString());
                checkIt2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_IT_2"].ToString());
                checkIt3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_IT_3"].ToString());

                checkLan1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_LANGUAGE_1"].ToString());
                checkLan2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_LANGUAGE_2"].ToString());

                checkEvent.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_EVENT_1"].ToString());

                checkFacion.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_FASION_1"].ToString());

                checkBeauty.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_BEAUTY_1"].ToString());

                checkMedical.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_MEDICAL_1"].ToString());

                checkRest.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["JOB_REST_1"].ToString());

            }
        }
    }
}