﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using parttime.common;
using System.Collections;
using System.Net;
using System.Diagnostics;
using System.Threading;

namespace parttime
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void login_Load(object sender, EventArgs e)
        {
            if (!chkVersion())
            {

                MessageBox.Show("新しいバージョンに更新します。");

                lblVersion.Visible = true;

                ProcessStartInfo ps = new ProcessStartInfo();

                ps.FileName = @"http://www.parttime-jp.info/exe/parttime.exe";

                // ps.Verb = "DOWNLOAD";

                ps.WindowStyle = ProcessWindowStyle.Minimized;

                Process.Start(ps);

                this.Hide();

                Application.Exit();

            }
            else {
                txtID.Focus();
            }

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            if (chk())
            {

                this.DialogResult = DialogResult.OK;
            }
        }

        private void btnSyuryou_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtPass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin_Click(null, null);
            }

            if (e.KeyCode == Keys.Tab && e.Shift)
            {
                txtID.Focus();
                txtID.SelectAll();
            }
        }

        private void txtPass_Enter(object sender, EventArgs e)
        {
            txtPass.SelectAll();
        }

        private bool chkVersion() {

            bool ret = true;

            DataSet ds = DbCon.selectInfoNoneCondition(Sql.SEL_14);

            string version = ds.Tables[0].Rows[0]["VERSIONINFO"].ToString().Trim();

            if (!lblVersion.Text.ToString().Equals(version))
            {
                ret = false;
            }

            return ret;
        }

        private bool chk() {

            bool ret = true;

            if (!chkMustEnter() || !chkExistId() || !getAdminInfo())
            {

                ret = false;
            }

            return ret;
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Common.ADMININFO == null)
            {

                Application.Exit();
            }
        }

        // 必須チェック
        private Boolean chkMustEnter()
        {

            Boolean chkRet = true;

            // ID
            if (txtID.Text == null || txtID.Text == string.Empty)
            {

                MessageBox.Show(MessageConst.IdMustEnterErr);
                txtID.Focus();
                chkRet = false;
            }

            // PW
            if (chkRet && (txtPass.Text == null || txtPass.Text == string.Empty))
            {

                MessageBox.Show(MessageConst.PwMustEnterErr);
                txtPass.Focus();
                chkRet = false;
            }

            return chkRet;
        }

        /*
        // Mail形式チェック
        private Boolean chkMailPattern()
        {

            Boolean chkRet = true;

            if (!new Regex(CodeMaster.MatchEmailPattern).IsMatch(txtID.Text))
            {

                MessageBox.Show(MessageConst.MailPatternChkErr);
                txtID.Focus();

                chkRet = false;
            }

            return chkRet;
        }
         * */

        /*
        // Pw形式チェック
        private Boolean chkPwPattern()
        {

            Boolean chkRet = true;

            if (textAdminPw.Text.Length < 6 || textAdminPw.Text.Length >= 16)
            {
                showMessage("error", Common.setScriptMsgBox(MessageConst.PwPatterChkErr));
                textAdminPw.Focus();

                chkRet = false;
            }

            if (chkRet && !new Regex(CodeMaster.MatchPwPatter).IsMatch(textAdminPw.Text))
            {

                showMessage("error", Common.setScriptMsgBox(MessageConst.PwPatterChkErr));
                textAdminPw.Focus();

                chkRet = false;

            }

            return chkRet;
        } */

        private Boolean chkExistId()
        {

            Boolean isExist = true;

            ArrayList listColumn = new ArrayList();
            ArrayList listValue = new ArrayList();

            listColumn.Add("@shain_code");

            listValue.Add(txtID.Text.ToString());

            DataSet ds = DbCon.selectInfo2(listColumn, listValue, Sql.SEL_01);

            String cnt = ds.Tables[0].Rows[0][0].ToString();

            if (CodeMaster.IdNotExist.Equals(cnt))
            {
                MessageBox.Show(MessageConst.NotExistIdEnterErr);
                isExist = false;

            }

            return isExist;
        }

        private Boolean getAdminInfo()
        {

            Boolean chk = true;

            ArrayList listColumn = new ArrayList();
            ArrayList listValue = new ArrayList();

            listColumn.Add("@shain_code");
            listColumn.Add("@shain_password");

            listValue.Add(txtID.Text.ToString());
            listValue.Add(txtPass.Text.ToString());

            DataSet ds = DbCon.selectInfo2(listColumn, listValue, Sql.SEL_02);

            if (ds.Tables[0].Rows.Count == 0)
            {

                MessageBox.Show(MessageConst.NotExistPWEnterErr);
                txtPass.Text = string.Empty;
                txtPass.Focus();
                chk = false;

            }

            else
            {

                listColumn.Clear();
                listValue.Clear();
                
                listColumn.Add("@admin_id");
                listValue.Add(ds.Tables[0].Rows[0]["SHAIN_CODE"]);

                DataSet ds2 = DbCon.selectInfo(listColumn, listValue, Sql.SEL_15);

                if(ds2.Tables[0].Rows[0][0].ToString().Equals("0")) 
                {

                    // insert 処理
                    registerWorker(ds);
                }

                listColumn.Clear();
                listValue.Clear();
                ds2.Clear();

                listColumn.Add("@admin_id");
                listColumn.Add("@admin_pw");
                listValue.Add(ds.Tables[0].Rows[0]["SHAIN_CODE"]);
                listValue.Add(ds.Tables[0].Rows[0]["SHAIN_PASSWORD"]);

                ds2 = DbCon.selectInfo(listColumn, listValue, Sql.SEL_16);

                AdminInfoBean adminInfo = new AdminInfoBean();

                adminInfo.setAdminNo(ds2.Tables[0].Rows[0]["ADMIN_NO"].ToString());
                adminInfo.setAdminId(ds2.Tables[0].Rows[0]["ADMIN_ID"].ToString());
                adminInfo.setAdminPw(ds2.Tables[0].Rows[0]["ADMIN_PW"].ToString());
                adminInfo.setAdminName(ds2.Tables[0].Rows[0]["ADMIN_NAME"].ToString());
                adminInfo.setAdminLevel(ds2.Tables[0].Rows[0]["ADMIN_LEVEL"].ToString());
                adminInfo.setAdminFlg(ds2.Tables[0].Rows[0]["ADMIN_FLG"].ToString());

                Hashtable info = new Hashtable();

                info.Add(CodeMaster.LoginInfo, adminInfo);

                Common.ADMININFO = info;

            }

            return chk;
        }

        private void registerWorker(DataSet ds)
        {

            ArrayList colList = new ArrayList();
            ArrayList valList = new ArrayList();

            colList.Add("@admin_id");
            colList.Add("@admin_name");
            colList.Add("@admin_pw");
            colList.Add("@admin_level");
            
            valList.Add(ds.Tables[0].Rows[0]["SHAIN_CODE"].ToString());
            valList.Add(ds.Tables[0].Rows[0]["SHAIN_NAME"].ToString());
            valList.Add(ds.Tables[0].Rows[0]["SHAIN_PASSWORD"].ToString());
            valList.Add(CodeMaster.Level_Public);

            DbCon.insertInfo(colList, valList, Sql.INS_01);
        }

    }
}