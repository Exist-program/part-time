﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using parttime.common;
using System.Collections;
using System.Web.UI.WebControls;
using System.Net;
using System.IO;
using System.Web;

namespace parttime.job
{
    public partial class frmJobDetail : Form
    {
        public frmJobDetail()
        {
            InitializeComponent();
        }

        private void frmJobDetail_Load(object sender, EventArgs e)
        {
            setPage();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            frmClose();
        }

        private void frmClose()
        {

            frmJobDetail_FormClosing(null, null);
            this.Close();
        }

        private void frmJobDetail_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmMain pForm = (frmMain)this.MdiParent;
            CodeMaster.FormArray.Remove(this);
        }

        private void setPage()
        {
            Common.setComboBox(4, comboTodo);
            Common.setComboBox(10, comboJobType);
            Common.setComboBox(12, comboSalType);

            getJobInfo();
        }

        private void getJobInfo() {

            ArrayList colList = new ArrayList();
            ArrayList valList = new ArrayList();

            colList.Add("@job_no");
            valList.Add(CodeMaster.JOBNO);

            DataSet ds = DbCon.selectInfo(colList, valList, Sql.SEL_09);

            if (ds.Tables[0].Rows.Count > 0)
            {

                comboJobType.SelectedValue = ds.Tables[0].Rows[0]["job_kind"].ToString();

                txtJobIntro.Text = ds.Tables[0].Rows[0]["job_intro"].ToString();

                txtJobContents.Text = ds.Tables[0].Rows[0]["job_contents"].ToString();

                comboSalType.SelectedValue = ds.Tables[0].Rows[0]["job_sal_type"].ToString();

                getSalTani(ds.Tables[0].Rows[0]["job_sal_tani"].ToString());

                comboTodo.SelectedValue = ds.Tables[0].Rows[0]["job_todo"].ToString();

                txtArea.Text = ds.Tables[0].Rows[0]["job_area"].ToString();

                txtStation.Text = ds.Tables[0].Rows[0]["job_traffic_1"].ToString()+" "+
                                  ds.Tables[0].Rows[0]["job_traffic_2"].ToString();

                if (ds.Tables[0].Rows[0]["JOB_TRA_MONEY_UMU"].ToString().Trim().Equals(CodeMaster.ChkBoxAri))
                {

                    radioAri.Checked = true;
                    radioNashi.Checked = false;
                    txtTranMoney.Text = Common.getMoneyType(ds.Tables[0].Rows[0]["job_tra_money"].ToString());
                } else {

                    radioAri.Checked = false;
                    radioNashi.Checked = true;
                }

                txtCloseYmd.Text = Common.getDateType(ds.Tables[0].Rows[0]["job_closing_ymd"].ToString());

                string picture = ds.Tables[0].Rows[0]["job_pho"].ToString();

                if (picture != null && picture != string.Empty)
                {
                    WebClient wc = new WebClient();

                    string url = "http://www.parttime-jp.info/" + picture.Substring(picture.IndexOf("img"));

                    Stream stream = wc.OpenRead(url);

                    System.Drawing.Image image = System.Drawing.Image.FromStream(stream);

                    picBox.Image = image;
                }
                else
                {

                    picBox.Image = null;
                }

                txtAppeal.Text = ds.Tables[0].Rows[0]["job_appeal"].ToString();

                // -----------------------------------------------------

                checkAsagata.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time1"].ToString());
                checkAsa.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time2"].ToString());
                checkHiru.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time3"].ToString());
                checkYugata.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time4"].ToString());
                checkSinya.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time5"].ToString());
                checkWeek1.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time6"].ToString());
                checkWeek2.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time7"].ToString());
                checkWeek3.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_time8"].ToString());

                checkSheeft.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_condition1"].ToString());
                checkWeekDay.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_condition2"].ToString());
                checkWeekEnd.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_condition3"].ToString());
                checkTanki.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_condition4"].ToString());
                checkConsul.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_condition5"].ToString());
                checkAtHome.Checked = Common.getChkBox(ds.Tables[0].Rows[0]["job_condition6"].ToString());

            }

        }

        private void getSalTani(string tani)
        {
            ArrayList list = new ArrayList();

            // time
            if (comboSalType.SelectedValue.ToString() == SalType.codeSalType1)
            {
                for (int i = 0; i < SalTani.nameSalTaniTimeList.Length; i++)
                {

                    list.Add(new ListItem(SalTani.nameSalTaniTimeList[i], SalTani.codeSalTaniTimeList[i]));
                }
            }

            // date
            if (comboSalType.SelectedValue.ToString() == SalType.codeSalType2)
            {
                for (int i = 0; i < SalTani.nameSalTaniDateList.Length; i++)
                {

                    list.Add(new ListItem(SalTani.nameSalTaniDateList[i], SalTani.codeSalTaniDateList[i]));
                }
            }

            // month
            if (comboSalType.SelectedValue.ToString() == SalType.codeSalType3)
            {
                for (int i = 0; i < SalTani.nameSalTaniMonthList.Length; i++)
                {

                    list.Add(new ListItem(SalTani.nameSalTaniMonthList[i], SalTani.codeSalTaniMonthList[i]));
                }
            }

            comboSalTani.DataSource = list;
            comboSalTani.DisplayMember = "TEXT";
            comboSalTani.ValueMember = "VALUE";

            comboSalTani.SelectedValue = tani;
        }
    }
}