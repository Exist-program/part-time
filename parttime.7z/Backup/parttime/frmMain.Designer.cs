﻿namespace parttime
{
    partial class frmMain
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MenuItem1000 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem2000 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem3000 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem4000 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem5000 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem6000 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem1000,
            this.MenuItem2000,
            this.MenuItem3000,
            this.MenuItem4000,
            this.MenuItem5000,
            this.MenuItem6000});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1188, 26);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MenuItem1000
            // 
            this.MenuItem1000.Name = "MenuItem1000";
            this.MenuItem1000.Size = new System.Drawing.Size(68, 22);
            this.MenuItem1000.Text = "社員登録";
            this.MenuItem1000.Click += new System.EventHandler(this.MenuItem1000_Click);
            // 
            // MenuItem2000
            // 
            this.MenuItem2000.Name = "MenuItem2000";
            this.MenuItem2000.Size = new System.Drawing.Size(68, 22);
            this.MenuItem2000.Text = "企業管理";
            this.MenuItem2000.Click += new System.EventHandler(this.MenuItem2000_Click_1);
            // 
            // MenuItem3000
            // 
            this.MenuItem3000.Name = "MenuItem3000";
            this.MenuItem3000.Size = new System.Drawing.Size(92, 22);
            this.MenuItem3000.Text = "スタッフ管理";
            this.MenuItem3000.Click += new System.EventHandler(this.MenuItem3000_Click);
            // 
            // MenuItem4000
            // 
            this.MenuItem4000.Name = "MenuItem4000";
            this.MenuItem4000.Size = new System.Drawing.Size(68, 22);
            this.MenuItem4000.Text = "求人管理";
            this.MenuItem4000.Click += new System.EventHandler(this.MenuItem4000_Click);
            // 
            // MenuItem5000
            // 
            this.MenuItem5000.Name = "MenuItem5000";
            this.MenuItem5000.Size = new System.Drawing.Size(121, 22);
            this.MenuItem5000.Text = "Hiwork未登録企業";
            this.MenuItem5000.Click += new System.EventHandler(this.MenuItem5000_Click);
            // 
            // MenuItem6000
            // 
            this.MenuItem6000.Name = "MenuItem6000";
            this.MenuItem6000.Size = new System.Drawing.Size(145, 22);
            this.MenuItem6000.Text = "Hiwork未登録スタッフ";
            this.MenuItem6000.Click += new System.EventHandler(this.MenuItem6000_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1188, 759);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "parttime";
            this.TransparencyKey = System.Drawing.Color.Gainsboro;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MenuItem1000;
        private System.Windows.Forms.ToolStripMenuItem MenuItem2000;
        private System.Windows.Forms.ToolStripMenuItem MenuItem3000;
        private System.Windows.Forms.ToolStripMenuItem MenuItem4000;
        private System.Windows.Forms.ToolStripMenuItem MenuItem5000;
        private System.Windows.Forms.ToolStripMenuItem MenuItem6000;
    }
}